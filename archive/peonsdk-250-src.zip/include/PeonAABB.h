
#ifndef __PEONAABB_H_
#define __PEONAABB_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "Peonstdafx.h"

#include "PeonVector3.h"

namespace peon
{
	/**
	* This is a small object meant for axis aligned bounding boxes. The goal of which is to 
	* create a loose "box" around an object in space and test collisions against that box.
	* 
	*/
	class PEONMAIN_API AABB
	{

    public:
		/** our minimum Vector3 */
		Vector3 m_vecMin;
		
		/** our maximum Vector3 */
		Vector3 m_vecMax;

	    


	public:
		/**
		* Constructor
		*/
		AABB();

		/**
		* Destructor
		*/
		~AABB();

		/**
		* This method is necessary to generate the bounding box around
		* @param vec - a Vector3 object
		*/
		void generateBox( const Vector3& vec);

		/**
		* This method is responsible for doing the brute-force collision
		* detection between these two AABB objects. We just check the 
		* min/max boundaries of each object and then return a true or
		* false if we've got a hit or not.
		* @param obj1 - an AABB to test against
		* @return bool - true or false if there's a hit or not
		*/
		bool doCollision( const AABB* obj1 );


	};
}

#endif

