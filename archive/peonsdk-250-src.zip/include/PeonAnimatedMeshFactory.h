
#ifndef __PEONANIMATEDMESHFACTORY_H_
#define __PEONANIMATEDMESHFACTORY_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISingleton.h"

#include "PeonVector2.h"
#include "PeonVector3.h"

#include "PeonSceneTexture.h"

#include "PeonMeshCommon.h"


namespace peon
{
	/**
	* This structure contains our header information and is filled during 
	* the initial read of our model
	*/
	struct PEONMAIN_API sMd3Header
	{ 
		char    fileID[4];                  // This stores the file ID - Must be "IDP3"
		int     version;                    // This stores the file version - Must be 15
		char    strFile[68];                // This stores the name of the file
		int     numFrames;                  // This stores the number of animation frames
		int     numTags;                    // This stores the tag count
		int     numMeshes;                  // This stores the number of sub-objects in the mesh
		int     numMaxSkins;                // This stores the number of skins for the mesh
		int     headerSize;                 // This stores the mesh header size
		int     tagStart;                   // This stores the offset into the file for tags
		int     tagEnd;                     // This stores the end offset into the file for tags
		int     fileSize;                   // This stores the file size
	};

	/**
	* This structure contains the mesh data for our MD3 model
	*/
	struct PEONMAIN_API sMd3MeshInfo
	{
		char    meshID[4];                  // This stores the mesh ID (We don't care)
		char    strName[68];                // This stores the mesh name (We do care)
		int     numMeshFrames;              // This stores the mesh aniamtion frame count
		int     numSkins;                   // This stores the mesh skin count
		int     numVertices;                // This stores the mesh vertex count
		int     numTriangles;               // This stores the mesh face count
		int     triStart;                   // This stores the starting offset for the triangles
		int     headerSize;                 // This stores the header size for the mesh
		int     uvStart;                    // This stores the starting offset for the UV coordinates
		int     vertexStart;                // This stores the starting offset for the vertex indices
		int     meshSize;                   // This stores the total mesh size
	};

	// This is our tag structure for the .MD3 file format.  These are used link other
	// models to and the rotate and transate the child models of that model.
	struct PEONMAIN_API sMd3Tag
	{
		char        strName[64];            // This stores the name of the tag (I.E. "tag_torso")
		Vector3    vPosition;              // This stores the translation that should be performed
		float       rotation[3][3];         // This stores the 3x3 rotation matrix for this frame
	};

	/**
	* This struct stores some of the bone information obtained from the model
	*/
	struct PEONMAIN_API sMd3Bone
	{
		float   mins[3];                    // This is the min (x, y, z) value for the bone
		float   maxs[3];                    // This is the max (x, y, z) value for the bone
		float   position[3];                // This supposedly stores the bone position???
		float   scale;                      // This stores the scale of the bone
		char    creator[16];                // The modeler used to create the model (I.E. "3DS Max")
	};


	/**
	* This struct stores the normals and vertex information 
	*/
	struct PEONMAIN_API sMd3Triangle
	{
	   signed short  vertex[3];             // The vertex for this face (scale down by 64.0f)
	   unsigned char normal[2];             
	};


	/**
	* This stores the indices into the vertex and texture coordinate arrays
	*/
	struct PEONMAIN_API sMd3Face
	{
	   int vertexIndices[3];                
	};


	/**
	* This struct stores U,V texture coordinates
	*/
	struct PEONMAIN_API sMd3TexCoord
	{
		/** our u,v texture coordinates */
	   float textureCoord[2];
	};


	/**
	* This structure stores the name of our skin
	*/
	struct PEONMAIN_API sMd3Skin 
	{
		/** the skin name of this model */
		char strName[68];
	};

	/**
	* This is our model container which encapsulates our model data read in from the 
	* MD3 file. 
	*/
	struct PEONMAIN_API s3DAnimModel 
	{
		int numOfObjects;                   // The number of objects in the model
		int numOfMaterials;                 // The number of materials for the model
		std::vector<sMaterialInfo> pMaterials;   // The list of material information (Textures and colors)
		std::vector<s3DObject> pObject;          // The object list for our model
    
		int numOfTags;                      // This stores the number of tags in the model
		s3DAnimModel    **pLinks;           // This stores a list of pointers that are linked to this model
		struct sMd3Tag  *pTags;         // This stores all the tags for the model animations
	
	public:
		/**
		* Constructor
		*/
		s3DAnimModel()
		{
			numOfObjects = 0;
			numOfMaterials = 0;
			numOfTags = 0;
		}

		/**
		* Destructor
		*/
		~s3DAnimModel()
		{

		}
	};


	/**
	* This object represents our loading mechanism for getting MD3 model data into our
	* game world. It functions similarly in nature to our MeshFactory, in that we
	* use the factory to return an object that we can manipulate and position within
	* our scene.
	*
	* As with the MeshFactory, hopefully this is an easy interface to extend should
	* we want the engine to support more animation model formats (like the new MD5 that
	* comes with Doom3, or perhaps you still want to use the MD2 format).
	*/
	class PEONMAIN_API AnimatedMeshFactory : public ISingleton< AnimatedMeshFactory >
	{

	public:
		/** our file pointer */
		FILE *m_pFile;

		/** header data */
		sMd3Header              m_Header;           

		/** the skin data */
		sMd3Skin                *m_pSkins;          
		
		/** texture coordinates */
		sMd3TexCoord            *m_pTexCoords;      
		
		/** face and triangle information */
		sMd3Face                *m_pTriangles;      
		
		/** vertex and U,V indices for rendering */
		sMd3Triangle            *m_pVertices;       
		
		/** bone information */
		sMd3Bone                *m_pBones;          



	public:
		/**
		* Constructor
		*/
		AnimatedMeshFactory();
		
		/**
		* Destructor
		*/
		~AnimatedMeshFactory();								

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static AnimatedMeshFactory& getSingleton(void);

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static AnimatedMeshFactory* getSingletonPtr(void);

		// This is the function that you call to load the MD3 model
		s3DAnimModel* loadMeshFromMD3( const String& strFileName );

		// This loads a model's .skin file
		bool loadSkin(s3DAnimModel *pModel, const String& strSkin );

		// This loads a weapon's .shader file
		bool loadShader(s3DAnimModel *pModel, const String& strShader );


	private:
		
		// This reads in the data from the MD3 file and stores it in the member variables,
		// later to be converted to our cool structures so we don't depend on Quake3 stuff.
		void readMD3Data(s3DAnimModel *pModel);

		// This converts the member variables to our pModel structure, and takes the model
		// to be loaded and the mesh header to get the mesh info.
		void convertDataStructures(s3DAnimModel *pModel, sMd3MeshInfo meshHeader);

		// This frees memory and closes the file
		void unloadData();

		

	};

	/**
	* This object is generated from our AnimatedMesh factory, and is responsible for
	* encapsulating the MD3 animation model format created by ID. ID has stated that
	* it's totally fine and acceptable to use the model format royalty free, however
	* you obviously can't use copyrighted MD3 models in your game without the necessary
	* permission
	*/
	class PEONMAIN_API AnimatedMD3Mesh
	{

	public:
		/**
		* Constructor
		*/
		AnimatedMD3Mesh();

		/**
		* Destructor
		*/
		~AnimatedMD3Mesh();
    
		// This loads the model from a path and name prefix.   It takes the path and
		// model name prefix to be added to _upper.md3, _lower.md3 or _head.md3.
		bool loadModel(const String& strPath, const String& strModel);

		// This loads the weapon and takes the same path and model name to be added to .md3
		bool loadWeapon(const String& strPath, const String& strModel);

		// This links a model to another model (pLink) so that it's the parent of that child.
		// The strTagName is the tag, or joint, that they will be linked at (I.E. "tag_torso").
		void linkModel(s3DAnimModel *pModel, s3DAnimModel *pLink, const String& strTagName);

		// This renders the character to the screen
		void renderModel();

		// This frees the character's data
		void unloadModel(s3DAnimModel *pModel);

		/** 
		* This is an internal method to set the appropriate texture during the rendering
		* process
		* @param key - our key value into the hashtable of our texture data
		*/
		void setTexture( int key );
    
	private:

		/**
		* This loads the models textures with a given path.
		* @param pModel - a pointer to our s3DAnimModel structure
		* @param sPath - our path to the data 
		*/
		void loadModelTextures(s3DAnimModel *pModel, const String& strPath);

		// This recursively draws the character models, starting with the lower.md3 model
		void renderLink(s3DAnimModel *pModel);

		// This a md3 model to the screen (not the whole character)
		void renderModel(s3DAnimModel *pModel);

		// Member Variables

		// This stores the texture array for each of the textures assigned to this model
		//unsigned int m_Textures[MAX_TEXTURES];  

		// This stores a list of all the names of the textures that have been loaded.  
		// This was created so that we could check to see if a texture that is assigned
		// to a mesh has already been loaded.  If so, then we don't need to load it again
		// and we can assign the textureID to the same textureID as the first loaded texture.
		// You could get rid of this variable by doing something tricky in the texture loading
		// function, but I didn't want to make it too confusing to load the textures.
		//std::vector<String> strTextures;

		/** hashtable of texture information related to this model */
		std::map<int, SceneTexture*> m_oTextures;

		/** head model */
		s3DAnimModel* m_pHead;

		/** upper body model */
		s3DAnimModel* m_pUpper;

		/** lower body model */
		s3DAnimModel* m_pLower;

		/** the player's weapon (completely optional) */
		s3DAnimModel* m_pWeapon;
	};

}

#endif

