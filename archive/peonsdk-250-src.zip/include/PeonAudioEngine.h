
#ifndef __PEONAUDIOENGINE_H_
#define __PEONAUDIOENGINE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonISingleton.h"


#define OGG_BUFFER_SIZE 4096

namespace peon
{
	
#if defined( PEON_USE_OPENAL_ )

	/**
	* This structure is responsible for encapsulating a 3D sound
	* within our game world. Hopefully it's fairly generic enough
	* to handle most situations. These nodes are really only meant
	* for OGG and WAV files (pretty much anything supported by OpenAL).
	* For MIDI audio, you should be looking at the loadMidi method
	* of the AudioEngine object.
	*
	* I'm using the OpenAL 1.1 SDK available from the OpenAL site
	* http://www.openal.org/downloads.html
	*
	* The ogg and vorbis libraries are available here:
	* http://www.xiph.org/downloads/
	* Using libogg - 1.1.3
	* Using libvorbis - 1.1.2
	*
	* Gotcha: Make sure the libogg and libvorbis files are built
	* using the same compiler IDE as the Peon library. I was running
	* into problems using ov_open until I rebuilt the ogg and vorbis libraries
	* to link with the Debug Multithreaded DLL runtime (the same as Peon's). 
	* After that it seems to work fine.
	* 
	*/
	struct PEONMAIN_API AudioNode
	{
		/** the source buffer */
		ALuint wav_sound_buffer;

		ALuint ogg_sound_buffer;

		ALuint sound_source;

		/** is this sound resource an OGG? */
		bool sound_ogg; 

		/** loop the sound? */
		bool sound_loop;

		/** sound's position in 3D space */
		ALfloat sound_position[3];

		/** sound's velocity within the game world */
		ALfloat sound_velocity[3];

		/** the physical data is stored into a std::vector */
		std::vector<char> ogg_sound_data;

		ALfloat sound_gain;

		ALfloat sound_pitch;


	public:
		/**
		* Constructor
		*/
		AudioNode()
		{
			sound_source = -1;
			//sound_buffer = -1;
			sound_loop = false;
			sound_position[0] = 0.0f;
			sound_position[1] = 0.0f;
			sound_position[2] = 0.0f;

			sound_velocity[0] = 0.0f;
			sound_velocity[1] = 0.0f;
			sound_velocity[2] = 0.0f;

			sound_gain = 1.0f;
			sound_pitch = 1.0f;

			wav_sound_buffer = -1;
			ogg_sound_buffer = -1;
		}

		/**
		* Destructor
		*/
		~AudioNode()
		{
			
			if(sound_ogg){
				alDeleteBuffers(1, &ogg_sound_buffer);
			}else{
				alDeleteBuffers(1, &wav_sound_buffer);
			}

			alDeleteSources(1, &sound_source);
			
		}
		
		
	};
#endif

	class PEONMAIN_API SoundFxNode
	{
	public:
		int m_key;

		Mix_Chunk* m_pData;

		int m_channel;

	public:
		SoundFxNode();
		~SoundFxNode();
	};

	class PEONMAIN_API MusicNode
	{
	public:
		int m_key;

		Mix_Music* m_pData;

	public:
		MusicNode();
		~MusicNode();
	};

	/**
	* This object is used to encapsulate our audio hardware. It should
	* be able to play both MIDI tunes (yes people still use 'em) and 
	* OGG/WAV files.
	*
	*/ 
	class PEONMAIN_API AudioEngine : public ISingleton<AudioEngine>
	{

	protected:

#if defined( PEON_USE_OPENAL_ )
		/** The OpenAL context */
		ALCcontext *m_pALContext;
		
		/** The OpenAL device */
		ALCdevice  *m_pALDevice;

#endif

		/** do we enable/disable sound? Note this only affects OGG and WAV playback */
		bool		m_bEnableSound;
		
		/** do we enable/disable music? Note this only affects MIDI playback */
		bool		m_bEnableMusic;

		/** is our audio hardware even supported? */
		bool		m_bAudioSupported;

		/** Just a boolean value if EAX is supported or not by the audio layer */
		bool		m_bIsEAXSupported;

		/** a list of our MIDI / MP3 / OGG data */
		boost::ptr_list<MusicNode> m_oMusicList;

		/** a list of our WAV sound effect data */
		boost::ptr_list<SoundFxNode> m_oSoundFxList;
		

	public:
		/**
		* Constructor
		*/
		AudioEngine();

		/**
		* Destructor
		*/
		~AudioEngine();

		/** Override standard Singleton retrieval.
		*/
		static AudioEngine& getSingleton(void);
		
		/** Override standard Singleton retrieval.
		*/
		static AudioEngine* getSingletonPtr(void);


		/**
		* This method loads and instantiates the subsystems necessary in
		* SDL_Mixer and OpenAL to get a device working for each. If the
		* initialization fails, then you can decide if you want to just
		* disable all sound, or quit the app entirely.
		* @param pConfig - The INI information
		* @return bool - true if audio loaded properly
		*/
		bool loadEngine( IniConfigReader* pConfig );

		/**
		* This method frees up our allocated audio resources
		*/
		void unloadEngine();

		/**
		* This method makes the necessary calls to load up a 
		* Mix_Music instance which is used for playback of
		* MIDI / OGG / MP3 files
		* @param int - key to store this music data as
		* @param strFilename - path to the MIDI file
		* @return int - result of the load...-1 if an error
		*/
		int loadMusic( int key, const String& strFilename );

		/**
		* This method makes the necessary calls to load up a 
		* Mix_Chunk instance which is used for playback of
		* MIDI files
		* @param int key - key to store this sound data as
		* @param strFilename - path to the WAV file
		* @return int - result of the load...-1 if an error
		*/
		int loadSoundFx( int key, const String& strFilename );

		int startSoundFx( int key, bool loop = false );

		int startMusic( int key, bool loop = true );

		int stopSoundFx( int key );

		int stopMusic( int key );

#if defined( PEON_USE_OPENAL_ )
		/**
		* This method internally loads the audio resource
		* into some OpenAL compatible buffers. When you wish
		* to work with a resource, you need to reference it by
		* the slot you stored it in.
		* @param strFilename - path to WAV file
		* @param slot - slot to store resource
		* @return bool - true if sound loaded properly
		*/
		bool loadAudioNode( const String& strWAVFile, AudioNode* pNode );

		/**
		* This method is responsible for setting the current
		* AudioNode
		* @param pNode - pointer to valid AudioNode
		*/
		void setAudioNode( AudioNode* pNode );

		/**
		* This method is responsible for playing the currently
		* set AudioNode
		* @param pNode - pointer to a valid AudioNode
		*/
		void playAudioNode( AudioNode* pNode );

		/**
		* This method is responsible for stopping the playback
		* of the AudioNode
		* @param pNode - pointer to AudioNode to stop
		*/
		void stopAudioNode( AudioNode* pNode );
#endif

		/**
		* This method just enables the global audio mask
		*/
		void enableSound(){ m_bEnableSound = true; }

		/**
		* This method disables the global audio mask
		*/
		void disableSound(){ m_bEnableSound = false; }

		/**
		* This method enables the global music mask
		*/
		void enableMusic(){ m_bEnableMusic = true; }

		/**
		* This method disables the global music mask
		*/
		void disableMusic(){ m_bEnableMusic = false; }

	};
}

#endif
