
#ifndef __PEONBILLBOARD_H_
#define __PEONBILLBOARD_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISceneObject.h"

namespace peon
{
	/**
	* This object represents a billboarded quad within our 
	* scene. It's meant to be a rough starting point to create
	* other effects, and/or to just slap into your scene.
	*/
	class PEONMAIN_API Billboard : public ISceneObject
	{
	public:
		/**
		* Constructor
		*/
		Billboard();

		/**
		* Destructor
		*/
		virtual ~Billboard();
	};
}

#endif

