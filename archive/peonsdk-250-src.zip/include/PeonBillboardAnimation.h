
#ifndef __PEONBILLBOARDANIMATION_H_
#define __PEONBILLBOARDANIMATION_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "peonstdafx.h"
#include "PeonVector3.h"
#include "PeonSceneTexture.h"

namespace peon
{

	class PEONMAIN_API AnimatedFrame
	{

	public:
		AnimatedFrame();

		~AnimatedFrame();

	public:

		peon::SceneTexture* m_pTexture;
		float m_fTime;


	};

	class PEONMAIN_API BillboardAnimation {

	public:
		bool m_bIsRunning;
		std::vector<AnimatedFrame *> m_oFrames;
		float m_fTotalTime;

		Vector3 m_vecPos;
		
		
	public:
		BillboardAnimation();

		~BillboardAnimation();

		bool loadFrame(const peon::String& strFilename, float fTime);

		void unloadFrames();

		void updateAnim(float elapsed_time);

		void startAnim();

		void stopAnim();
		
		int getCurrentFrame();

		void renderAnim();
		

	};

}

#endif
