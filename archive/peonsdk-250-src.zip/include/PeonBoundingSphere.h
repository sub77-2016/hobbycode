
#ifndef __PEONBOUNDINGSPHERE_H_
#define __PEONBOUNDINGSPHERE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "Peonstdafx.h"

#include "PeonVector3.h"

namespace peon
{
	/**
	* This is a bare bones implementation of an object used for 
	* calculating spheres in our engine. Mostly it's used to surround
	* an object to be used for collision detection.
	*/
	class PEONMAIN_API BoundingSphere
	{
	public:
		/** the center of the sphere */
		Vector3 m_vecCenter;

		/** the radius of the sphere */
		float   m_fRadius;
		
	public:
		/**
		* Constructor
		*/
		BoundingSphere();

		/**
		* Destructor
		*/
		~BoundingSphere();

		bool doCollision( BoundingSphere& obj1 ) const;
	};

}

#endif
