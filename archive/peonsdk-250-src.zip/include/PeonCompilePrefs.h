
#ifndef __PEONCOMPILEPREFS_H_
#define __PEONCOMPILEPREFS_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


/**
* Just a marker to help with any kind of porting to other IDE's
* or platforms. The goal is to eventually get this library into
* a DevCPP compatible (GCC) format as well, so we'd make some
* changes here
*/
#if defined(WIN32) || defined(WIN64)
#define PEON_WINDOWS_
#endif

#if defined( _MSC_VER )
/**
* enable some memory leak detection as defined in the MSDN article:
* http://msdn.microsoft.com/library/default.asp?url=/library/en-us/vsdebug/html/vxconenablingmemoryleakdetection.asp
*
* along with some great tips here:
* http://www.litwindow.com/Knowhow/wxHowto/wxhowto.html#debug_alloc
*/
#if defined(DEBUG) | defined(_DEBUG)
  #define CRTDBG_MAP_ALLOC
  #include <stdlib.h>
  #include <crtdbg.h>
  #define DEBUG_NEW new(_NORMAL_BLOCK ,__FILE__, __LINE__)
#else
  #define DEBUG_NEW new
#endif

#endif

/**
* if we want to work with UNICODE strings and other wide character
* handling...perhaps for multi-language/international support, then UNcomment
* the following
*/
//#define PEON_UNICODE_


/**
* These following blocks of preproccessor statements are used to 
* wrap around statements for cleaning up either pointers or
* arrays of allocated elements.
*/
#define PEON_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define PEON_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


/**
* The following block of preprocessor statements give us a bit of a hand
* when we want to do some radian to degree (or vice versa) conversions. Nothing
* fancy here.
*/
#define PEON_PI	3.141592654f
#define PEON_DEGTORAD(degree) ((degree) * (PEON_PI / 180.0f))
#define PEON_RADTODEG(radian) ((radian) * (180.0f / PEON_PI))



#endif
