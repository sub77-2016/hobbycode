
#ifndef __PEONDLLHEADER_H_
#define __PEONDLLHEADER_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/



// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PEONMAIN_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PEONMAIN_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
//
// In practical terms you just put the PEONMAIN_EXPORTS declaration on any object
// that you want to be able to call from your application.
//
#ifdef PEONMAIN_EXPORTS
#define PEONMAIN_API __declspec(dllexport)
#else
#define PEONMAIN_API __declspec(dllimport)
#endif



#endif









