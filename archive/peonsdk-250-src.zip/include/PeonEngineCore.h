
#ifndef __PEONENGINECORE_H_
#define __PEONENGINECORE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISingleton.h"
#include "PeonTimer.h"
#include "PeonSceneRenderer.h"
#include "PeonAudioEngine.h"
#include "PeonInputEngine.h"
#include "PeonIApplication.h"
#include "PeonSceneRoot.h"
#include "PeonMathUnit.h"
#include "PeonScriptEngine.h"

namespace peon
{
	/**
	* This is our main entry object for the Peon library
	*
	* This object is responsible for kicking off a main window
	* that we can draw to, along with a lot of the core subsystems
	* involved in the engine.
	*/
	class PEONMAIN_API EngineCore : ISingleton<EngineCore>
	{
	public:
		/** Handle to our IniConfigReader instance  */
		IniConfigReader*	m_pConfig;

		/** Handle to our IApplication instance */
		IApplication*       m_pApplication;

		/** Handle to our Renderer instance for rendering scene geometry */
		SceneRenderer*		m_pVideoDevice;

		/** Our Timer object which encapsulates some system time calls */
		Timer				m_oTimer;

		/** The frames per second of our rendering loop */
		float				m_fps;

		

	protected:
		/**
		* This method is responsible for updating the frame rate counter
		*/
		void updateFPS();

	public:
		/**
		* Constructor
		*/
		EngineCore();

		/**
		* Destructor
		*/
		~EngineCore();

		/** Override standard Singleton retrieval.
		*/
		static EngineCore& getSingleton(void);

		/** Override standard Singleton retrieval.
		*/
		static EngineCore* getSingletonPtr(void);

		/**
		* This method loads and initializes the subsystems of the 
		* Peon library...audio, video, input and network
		* @param strWindowTitle - our window title
		* @param strIniConfig - path to the INI Configuration information
		* @param strIgnore - This string defines our version of the SDK in
		*                    case there's any object or whatever that is only
		*                    created in a specific version of this SDK. 
		*                    NOTE NEVER EVER PASS ANYTHING for this variable. Let
		*                    the library do it itself!
		* @return bool - false if anything failed
		*/
		bool loadEngine( const String& strWindowTitle, const String& strIniConfig, const String strIgnore = PEON_SDK_VERSION );

		/**
		* This method unloads and frees up every allocated subsystem
		*/
		void unloadEngine();

		/**
		* This puts the Peon engine into an endless cycle. Our "main loop"
		* for the game.
		* @return int - negative value if anything went wrong
		*/
		int runEngine();

		/**
		* This method is just a quick setter for assigning our internal
		* IApplication varible to this one.
		* @return bool - false if anything failed to initialize
		*/
		bool setApplication( IApplication* pApplication );

		/**
		* This method is a getter for our SceneRenderer instance
		* @return SceneRenderer* - our renderer
		*/
		SceneRenderer* getRenderer(){ return m_pVideoDevice; }

		/**
		* This method is a getter to grab the IApplication instance
		* IApplication* - our IApplication instance
		*/
		IApplication* getApplication(){ return m_pApplication; }

		/**
		* This method is a way of sending a QUIT message into the
		* message pipeline to shutdown the engine.
		*/
		void sendQuitMsg();


	};
}

#endif

