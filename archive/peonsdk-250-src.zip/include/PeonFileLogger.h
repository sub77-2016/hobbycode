
#ifndef __PEONFILELOGGER_H_
#define __PEONFILELOGGER_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "peonstdafx.h"

#include "PeonISingleton.h"


/**
* The following are logging levels supported by the FileLogger.
* The attempt is to use a mask approach to file logging. Let's say
* you release the game using Peon to a customer. Since it's the 
* "production" (or "retail") version of your game, you should only really
* capture critical errors (in order to not affect performance). Then you
* can always get your customer to submit the log file should they experience
* repeated problems.
*/
#define PEON_LOG_INFO          0x0001
#define PEON_LOG_DEBUG		   0x0002
#define PEON_LOG_ERROR         0x0004
#define PEON_LOG_FATAL         0x0008


namespace peon {

	/**
	*
	* This object is just used to output any needed log messages to 
	* a file. We COULD make this fancier (like a primitive Log4J 
	* solution) by perhaps creating a LogInterface superclass, which
	* we can then derive FileLogger from. This would then allow us
	* to also create an SMTPLogger or HTMLLogger for example (to output
	* our log messages over SMTP or into a nice and purty HTML document).
	*
	* I made derived it from the ISingleton object in order to be 
	* accessible pretty much everywhere in our game and/or Peon.
	*
	* I've made some of the reporting similar in nature to the log file
    * output produced from the CEGUI toolkit, just to provide a bit of
    * logging consistency.
	*/
	class PEONMAIN_API FileLogger : public ISingleton<FileLogger>
	{

	protected:
		
		/** the file handle */
		std::ofstream	m_log_file;

		/** name of the file */
		String			m_strLogName;
	
	
	protected:

		/**
		* This method is responsible for writing out text to our
		* logfile. It should not be called directly, so it's
		* declared as protected.
		* @param String - our desired text to append
		* @return void
		*/
		void writeToLogStream(const String& strText);

		
	public:

		/**
		* Constructor
		* @param log_flag - the logging filter level
		*/
		FileLogger( int log_flag );


		/**
		* Default Constructor - the preferred method 
		*/
		FileLogger();


		/**
		* Destructor
		*/
		~FileLogger();

		/** Override standard Singleton retrieval.
        */
        static FileLogger& getSingleton(void);

        /** Override standard Singleton retrieval.
        */
        static FileLogger* getSingletonPtr(void);

		/**
		* This method simply opens the file handle and prepares the
		* log file for writing
		* @param strName - our desired filename
		* @return bool - true if we succeeded, error code otherwise
		*/
		bool openLogStream(const String& strName);

		/**
		* This method is responsible for shutting down our logging
		* and closing any file handles
		* @param void
		* @return void
		*/
		void closeLogStream(void);

		/**
		* This method logs a string setting it to "Info" mode. It then
		* compares it with the internal log setting to see if it should
		* be recorded or not.
		* @param strObject - object making logging call
		* @param strText - text to output
		*/
		void logInfo ( const String& strObject, const String& strText);

		/**
		* This method logs a string setting it to "Debug" mode. It then
		* compares it with the internal log setting to see if it should
		* be recorded or not.
		* @param strObject - object making logging call
		* @param strText - text to output
		*/
		void logDebug(const String& strObject, const String& strText);

		/**
		* This method logs a string setting it to "Error" mode. It then
		* compares it with the internal log setting to see if it should
		* be recorded or not.
		* @param strObject - object making logging call
		* @param strText - text to output
		*/
		void logError(const String& strObject, const String& strText);

		/**
		* This method logs a string setting it to "Fatal" mode. It then
		* compares it with the internal log setting to see if it should
		* be recorded or not.
		* @param strObject - object making logging call
		* @param strText - text to output
		*/
		void logFatal( const String& strObject, const String& strText);

	
		
	};
}

#endif
