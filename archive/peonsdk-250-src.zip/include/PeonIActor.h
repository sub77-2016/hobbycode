
#ifndef __PEONIACTOR_H_
#define __PEONIACTOR_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISceneObject.h"

namespace peon
{
	/**
	* This "Actor" object is meant to be the root object
	* of entities in our game world which can move
	* and interact with others. 
	*
	* Think of IActors as real "actors" in a literal
	* sense. They are part of the play/stage which 
	* is the game world
	*/
	class PEONMAIN_API IActor : public ISceneObject
	{
	public:
		/**
		* Constructor
		*/
		IActor();

		/**
		* Destructor
		*/
		virtual ~IActor();
	};
}

#endif
