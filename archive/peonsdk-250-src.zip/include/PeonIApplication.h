
#ifndef __PEONIAPPLICATION_H_
#define __PEONIAPPLICATION_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonIApplicationState.h"

namespace peon
{
	/**
	* This object is responsible for containing any "application global" 
	* structures or handles. You should stick state-specific objects
	* into an @see IApplicationState instance, but any object that needs to be
	* referenced by all the internal states should be thrown into here
	*/
	class PEONMAIN_API IApplication 
	{
	protected:
		/** an STL hash map container of our IApplicationState pointers */
		std::map<int, IApplicationState*> m_oStates;

		/** a handle to our current IApplicationState instance */
		IApplicationState*	m_pCurrentState;

	public:
		/**
		* Constructor
		*/
		IApplication();

		/**
		* Destructor
		*/
		virtual ~IApplication();

		/**
		* This method is called when loading the game world. In here
		* we should be loading all of the internal IApplicationState instances
		* along with any "global level" objects
		* @return bool - true if successful
		*/
		virtual bool onLoadWorld() = 0;

		/**
		* This method is called when unloading the game world. Basically
		* any object that we created at a global level should be cleaned
		* up here.
		* Note that the IApplicationState instances are cleanup automatically,
		* so you do not need to worry about them.
		*/
		virtual void onUnloadWorld() = 0;

		/**
		* This method is called when it's time to pass any rendering command
		* to the engine
		*/
		virtual void onRenderWorld(){}

		/**
		* This method is called when it's time to update the objects in
		* the game world. 
		* @param fElapsedTime - the time differential used for object position
		* calculations
		*/
		virtual void onUpdateWorld( float fElapsedTime ) = 0;

		/**
		* This method is responsible for loading the 
		* given IApplicationState along with registering it 
		* into our hash table
		* @param key - key id for the local hash map
		* @param pState - a new @IApplicationState
		* @return bool - TRUE if everything initialized
		*/
		bool loadState( int key, IApplicationState* pState );

		/**
		* This is an internal method to clean up all the states
		*/
		void unloadStates();
	
		/**
		* This just returns the current IApplicationState that the engine
		* is working with.
		* @return IApplicationState*  - a handle to the current IApplicationState
		*/
		IApplicationState* getCurrentState(){ return m_pCurrentState; }

		/**
		* This just returns the current IApplicationState ID that the
		* engine is working with.
		* @return int key
		*/
		int getCurrentStateID();
	
		/**
		* Set the current state to the one specified by the key identifier
		* param key - key to set current state to
		*/
		void setCurrentState(int key);

		/**
		* This method provides quick keyboard access to the
		* current state
		* @param pEvent - a generated SDL_KeyboardEvent handle
		*/
		virtual void onKeyEvent( SDL_KeyboardEvent* pEvent ){}

		/**
		* This method provides quick mouse access to the 
		* current state
		* @param pEvent - a generated SDL_Event message
		*/
		virtual void onMouseEvent( SDL_Event* pEvent ){}

	};
}

#endif

