
#ifndef __PEONIAPPLICATIONSTATE_H_
#define __PEONIAPPLICATIONSTATE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonIUnknown.h"

namespace peon
{
	/**
	* This base object is responsible for containing everything and anything
	* that belongs in its own state during the lifetime of the game.
	*/
	class PEONMAIN_API IApplicationState : public IUnknown
	{
	public:
		/**
		* Constructor
		*/
		IApplicationState(){}

		/**
		* Destructor
		*/
		virtual ~IApplicationState(){}

		/**
		* This method is launched when we want to load up and create everything
		* within this state.
		* @return bool - true if ok
		*/
		virtual bool onLoad() = 0;

		/**
		* This method is launched when its time to cleanup and free any
		* allocated memory for this state
		*/
		virtual void onUnload() = 0;

		/**
		* This method is launched when the engine signals the chance to
		* update this state 
		* @param fElapsedTime - the delta used for calculating object movement
		*/
		virtual void onUpdate( float fElapsedTime ) = 0;

		/**
		* This method is responsible for processing any rendering commands
		* for this state
		*/
		virtual void onRender(){}
	};
}

#endif
