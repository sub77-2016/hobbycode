
#ifndef __PEONISCENEOBJECT_H_
#define __PEONISCENEOBJECT_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonIUnknown.h"
#include "PeonVector3.h"
#include "PeonAABB.h"

namespace peon
{
	/**
	* This base object for our scene display list found in the @see SceneRoot
	* object. We can choose to derive any display list from this base object
	* or the @see IActor object. 
	*
	* This is currently a primitive way of creating a scene display manager. 
	* The reader should be able to work with this to add some advanced features
	* such as frustum culling, physics, etc. 
	*/
	class PEONMAIN_API ISceneObject : public IUnknown
	{
	public:
		/** our x,y,z position orientation */
		Vector3		m_vecPos;

		/** our x,y,z rotation orientation */
		Vector3     m_vecRot;

		/** our x,y,z velocity values */
		Vector3     m_vecVel;

		/** our x,y,z scale values */
		Vector3     m_vecScale;


		/** an unsigned integer value that we can use to store the display list id */
		UINT        m_uDisplayID;

		/** is this object currently active? */
		bool		m_bActive;

		/** our Axis Aligned Bounding Box */
		AABB        m_oBoundingBox;

	public:
		/**
		* Constructor
		*/
		ISceneObject()
		{
			m_uDisplayID = -1;

		}

		/**
		* Destructor
		*/
		virtual ~ISceneObject(){}


		/**
		* This method is signaled when we first load this object
		* @return bool - false if failed
		*/
		virtual bool onLoad(){ return true; }

		/**
		* This method is signaled when we are going through the
		* garbage collection process for this object
		*/
		virtual void onUnload(){}

		/**
		* This method is used to update this particular node.
		* Every object inherited from ISceneObject should try
		* to override this method, as it allows it to be
		* processed by any scene manager.
		* @param fElapsedTime - elapsed time between frames
		* @return void
		*/
		virtual void onUpdate(float fElapsedTime){}

		/**
		* This method can be used as a overrideable for
		* rendering
		* @return void
		*/
		virtual void onRender(){}

		/**
		* This method just sets our object's position
		* @param newPos - Vector3 of the game world
		* @return void
		*/
		void setPos( Vector3 newPos ){ m_vecPos = newPos; }

		/**
		* This method just gets our object's position
		* @return a Vector3 containing our object's world position
		*/
		Vector3 getPos(){ return m_vecPos; }

		/**
		* This method just sets our object's rotation
		* @param newRot - Vector3 of the rotation
		* @return void
		*/
		void setRot( Vector3 newRot ){ m_vecRot = newRot; }

		/**
		* This method just gets our object's rotation
		* @return a Vector3 containing our object's rotation
		*/
		Vector3 getRot(){ return m_vecRot; }

		/**
		* This method just sets our object's velocity
		* @param newVel - Vector3 of the velocity
		* @return void
		*/
		void setVel( Vector3 newVel ){ m_vecVel = newVel; }

		/**
		* This method just gets our object's velocity vector
		* @return a Vector3 containing our object's velocity
		*/
		Vector3 getVel(){ return m_vecVel; }

		/**
		* This method just sets our object's scale
		* @param newScale - Vector3 of the scaling factor
		* @return void
		*/
		void setScale( Vector3 newScale ){ m_vecScale = newScale; }

		/**
		* This method just gets our object's scale vector
		* @return a Vector3 containing our object's scaling factors
		*/
		Vector3 getScale(){ return m_vecScale; }
		
		/**
		* This method just sets our display list id, if we decide to use
		* one for rendering this object.
		* @param uDisplayID - UINT value containing the display list ID, -1 if none exists
		*/
		void setDisplayID( UINT uDisplayID ){ m_uDisplayID = uDisplayID; }

		/**
		* This method is meant to retrieve the display list id for this
		* ISceneObject.
		* @return UINT - the unsigned integer representing our display list ID
		*/
		UINT getDisplayID(){ return m_uDisplayID; }

		/** 
		* Is this object active? (Could be active but not dead)
		* @param bool - true or false for active or not
		*/
		bool getActive(){ return m_bActive; }

		/**
		* Set whether this object is active or not.
		* @param nActive - true or false if this object should be active
		*/
		void setActive( bool nActive ){ m_bActive = nActive; }

	};
}

#endif