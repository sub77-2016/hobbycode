
#ifndef __PEONISINGLETON_H__
#define __PEONISINGLETON_H__
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

/* Original version Copyright (C) Scott Bilas, 2000.
 * All rights reserved worldwide.
 *
 * This software is provided "as is" without express or implied
 * warranties. You may freely copy and compile this source into
 * applications you distribute provided that the copyright text
 * below is included in the resulting source code, for example:
 * "Portions Copyright (C) Scott Bilas, 2000"
 */

#include "Peonstdafx.h"

namespace peon 
{

    /** 
	* Template class for creating single-instance global classes.
	* The code in this file is taken from article 1.3 in the the book:
	* Game Programming Gems from Charles River Media with the 
	* copyright notice going to Scott Bilas.
    */
    template <typename T> class PEONMAIN_API ISingleton
    {
    protected:

		/** The static member object */
        static T* ms_Singleton;

    public:
		/**
		* Constructor
		*/
        ISingleton( void )
        {
            assert( !ms_Singleton );
			ms_Singleton = static_cast< T* >( this );
        }

		/**
		* Destructor
		*/
        ~ISingleton( void )
            {  assert( ms_Singleton );  ms_Singleton = 0;  }
        
		/**
		* This method just returns the internal member by 
		* reference
		* @return T& - reference to internal abstract Type
		*/
		static T& getSingleton( void )
		{	assert( ms_Singleton );  return ( *ms_Singleton ); }
        
		/**
		* This method just returns the internal member by 
		* a pointer
		* @return T* - pointer to the internal abstract Type
		*/
		static T* getSingletonPtr( void )
		{ return ms_Singleton; }
    };
}

#endif
