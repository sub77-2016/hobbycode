
#ifndef __PEONIUNKNOWN_H_
#define __PEONIUNKNOWN_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"

namespace peon
{
	/**
	* This object represents a base level object that we can derive other
	* objects from in the Peon library. It mainly works around a primitive
	* and crude form of reference counting. As you copy interfaces around
	* the engine, you increase the reference count of the object. As you
	* delete/free them, you decrease the reference count. If the engine
	* exits with some reference counts still above 0, then you know you're
	* not freeing something properly.
	*
	* For those not happy with this implementation, you might want to take
	* a look at the smart pointer object which comes with some of the
	* boost libraries. http://www.boost.org. It's a handy collection of
	* some C++ objects.
	*/
	class PEONMAIN_API IUnknown
	{
	protected:
		/** the "id" of our object...can be anything we want */
		int		m_id;

		/** the internal reference count of this object */
		int		m_refCount;

	public:
		/**
		* Constructor
		*/
		IUnknown() : m_refCount(1), m_id(0)
		{
		}

		/**
		* Destructor
		*/
		virtual ~IUnknown()
		{
		
		}

		/**
		* This method just returns our id "tag" of the object.
		* @return int - our object's id
		*/
		int getID(){ return m_id; }

		/**
		* This method just sets our id "tag" of the object.
		* @param new_id - the new id we want to set our object to
		*/
		void setID( int new_id ){ m_id = new_id; }

		/**
		* This method increases our object's reference count. 
		* 
		* A simple example is when we pass around our SceneRenderer
		* interface around through the engine. If another object
		* uses an internal handle to it, then we've just copied
		* a reference to the SceneRenderer!
		*
		* Instead just add a ref count when you assign it to 
		* another object.
		*
		*/
		void addRefCount() { ++m_refCount; }

		/**
		* This method decreases our object's internal reference
		* count. 
		* The idea is to track how many instances of this object
		* are left in the system. If we hit some memory leaking
		* problems in our game code, then using this reference
		* counting is a way of tracking down objects which are not
		* properly being destroyed.
		* @return bool - have we cleaned up every instance of this object?
		*/
		bool dropRefCount()
		{
			//decrement the reference counter variable. If we drop
			//below zero, then we can automatically clean this up
			//with a delete call.
			//
			--m_refCount;
			if (!m_refCount)
			{
				delete this;
				return true;
			}

			return false;
		}

	};
}

#endif
