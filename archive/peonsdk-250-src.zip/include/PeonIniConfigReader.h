
#ifndef __PEONINICONFIGREADER_H_
#define __PEONINICONFIGREADER_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


// Precompiler options
#include "peonstdafx.h"



namespace peon
{
	/**
	* This object is useful for loading and storing any information
	* we might need for our game contained in an .INI file. We can
	* store anything from our wanted renderer, to our application window
	* size, to even some basic scripting elements.
	*
	* Note that this object is completely Win32-specific. It is using
	* the GetPrivateProfile* family of API functions which I think are
	* only available on Windows.
	*/
	class PEONMAIN_API IniConfigReader
	{

	protected:
		/** our INI filename */
		String	m_strFileName;     

	public:

		/**
		* Constructor
		* @param String - path to INI file
		*/
		IniConfigReader(const String& strFile);

		/**
		* Destructor
		*/
		~IniConfigReader();

		/**
		* This method is responsible for grabbing any string data from our
		* INI file
		* @param String - our INI section
		* @param String - our key name
		* @param String - our default key value
		* @param String& - a string object to contain our resulting data
		* @return DWORD - the size of our data string
		*/
		DWORD getString(const String sSection, const String sKey, const String sDefault, String& sReturn);

		/**
		* This method is just responsible for grabbing the UINT value
		* from our INI file
		* @param String - section name
		* @param String - key name
		* @param int         - default key value
		* @return UINT       - our returned key value
		*/
		UINT getInt(const String sSection, const String sKeyName, int);

		/**
		* This method is responsible for grabbing any boolean information
		* stored in our INI file
		* @param String - section name
		* @param String - key name
		* @param String - default key value "TRUE" or "FALSE"
		* @return bool      - our actual key value
		*/
		bool getBool(const String sSection, const String sKeyName, const String sDefault);
		
		/**
		* This method is responsible for grabbing any float information stored
		* in our INI file
		* @param String sSection - section name
		* @param String sKeyName - key name
		* @param String sDefault - default value of float (ie. "1.0f")
		* @return float - our determined float value
		*/
		float getFloat(const String sSection, const String sKeyName, const String sDefault);

	};

}

#endif 