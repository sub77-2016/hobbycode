
#ifndef __PEONINPUTENGINE_H_
#define __PEONINPUTENGINE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonISingleton.h"


#define JOYSTICK_DEAD_ZONE 32768.0f


namespace peon
{
	/**
	* This object keeps an eye on the input received by SDL
	*
	* This singleton object is a manager "of sorts" for the input 
	* devices available on the system. 
	*/
	class PEONMAIN_API InputEngine : public ISingleton<InputEngine>
	{
	protected:
		/** handle to the joystick */
		SDL_Joystick*		m_pJoystick;

		/** is there a joystick connected? */
		bool			    m_bJoystickConnected;

	public:
		/**
		* Constructor
		*/
		InputEngine();

		/**
		* Destructor
		*/
		~InputEngine();

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static InputEngine& getSingleton(void);

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static InputEngine* getSingletonPtr(void);


		/**
		* This method loads up and configures our input devices. SDL 
		* will automagically create our handles to the keyboard and
		* mouse device, so we're really only talking about initializing
		* a handle to the joystick.
		*
		* I always return true, as I feel the game should not bail just
		* because the joystick was not found/inited properly. Feel free
		* to modify depending upon your game's needs.
		*
		* @param pConfig - a valid IniConfigReader instance
		* @return bool - always true
		*/
		bool loadEngine( IniConfigReader* pConfig );

		/**
		* This method just unloads and frees any allocated input devices
		*/
		void unloadEngine();

		/**
		* This method returns the current X axis of the joystick
		* @return Sint16 - value of our x axis
		*/
		Sint16 getJoyXAxis();

		/**
		* This method returns the current Y axis of the joystick
		* @return Sint16 - value of our y axis
		*/
		Sint16 getJoyYAxis();

	};
}

#endif
