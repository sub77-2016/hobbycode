
#ifndef __PEONMAIN_H_
#define __PEONMAIN_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

/**
* \mainpage Peon Engine
*
* \section intro_sec Introduction
*
* The Peon collection of objects is meant to help the beginner learn and
* understand the fundamentals of game programming. The goal of the engine
* is to help you do things.<strong>It is not meant to be a heavy framework</strong>.
*
* I'm not against other frameworks (don't get me wrong), but sometimes they
* become so laden and burdened that it becomes difficult for the newbie
* to simply pick up the codebase and run with it quickly.
*
* \section dll_sec DLL
* 
* Why is this a Dynamically Linked Library? 
* Although SDL is a platform independent library, the Win32 version of the Peon
* library compiles as a DLL. I chose this route, simply because it can make
* the support of this library easier in terms of upgrades for any customer
* buying/using your game built with Peon. Because the code links with the
* DLL during the runtime of your game, you are free to update/upgrade any
* code within so long as you don't change how the functions/classes are 
* interfaced with your modules.
*
* For example, the SceneRenderer object (so far) handles some primitive
* rendering commands. If you were to discover a bug within the object, or
* wish to change it's functionality, then you could just re-ship the DLL to
* the customer, <b>so long as you don't change any function names themselves</b>.
*
* This library also compiles as a DLL, since it depends upon a few other projects
* which are themselves packaged as DLL's. You don't want to end up violating any
* licenses, but still have the freedom to create/distribute the project you want.
*
* \section dependencies_sec Dependencies
*
* The Peon library/collection of objects is built upon some existing popular
* libraries that are already being used by professional game developers.
*
* <i>Note: The license that comes with Peon only covers the Peon library itself.
* Each dependency has its own licensing terms that you are responsible for.</i>
*
* For the most part these are all successfull open source projects which 
* are released under the LGPL (the same as Peon). Provided you retain the 
* copyright headers of each project you can still release commercial
* software using them and retain all the bling.
*
* Here is a list of links to each of the license information pages
* for any dependent sub-projects the Peon library includes/uses.
*
* <ul>
* <li>SDL - <a href="http://www.libsdl.org/license.php">SDL v1.2.9</a>.</li>
* <li>OpenAL - <a href="http://www.openal.org">OpenAL</a>.</li>
* <li>Lua - <a href="http://www.lua.org/license.html">LUA</a>.</li>
* <li>CEGUI - <a href="http://www.cegui.org.uk/">Crazy Eddie's GUI Toolkit</a></li>
* </ul>
*
* \section install_sec Installation
*
* Check Appendix A in the book <b><i>"Game Programming in C++: Start To Finish"</i></b> for
* some instructions on getting this setup.
* 
* Generally just make sure you let your IDE know where to find the /Peon/PeonMain/include
* and /Peon/PeonMain/lib folder. The /Peon/redist folder contains the compiled
* version of this library, along with the DLL's that you need to distribute with
* any application using Peon. 
*
* Having your installer copy them to the customer's windows\system32 folder is
* an option, or you can leave them all in the same folder as your binary executable.
* The choice is yours and just depends on how you want to support your own product.
* ie. your installer should "be nice" and remove them during an uninstall of
* your game, etc.
* 
* \section building_sec Building the Library
*
* There should be the necessary project files for building the Peon library
* in:
* Visual Studio 6.0
* Visual Studio .NET 2002/2003
* Visual Studio .NET 2005
*
* Note #1: The library is built to link with the debug/release multithreaded
* DLL runtime(s). There's a few dependency projects (such as the Ogg-Vorbis libraries)
* which need to be in this format as well, in order to keep us from seg. faulting.
*
* Note #2: When compiling the library, check out the CompileConfig.h file for any
* "special" flags you may need to set/unset for compiling the project for your
* needs (ie. to add UNICODE support, etc).
*
* \section usage_sec General Usage
*
*
* The general usage for this library is meant to be (hopefully) very simple as
* I mentioned above. The basic practice is:
* <ol>
* <li>Derive a new application instance from IApplication</li>
* <li>Derive any needed states from IApplicationState</li>
* <li>Throw everything into the EngineCore instance</li>
* <li>Enjoy game programming!</li>
* </ol>
*
* Note: Always check <a href="http://www.wazooinc.com">http://www.wazooinc.com</a> for 
* the latest version of this library and any updates.
*
* \section further_sec Further Resources
* 
* For additional resources into 3D engines, feel free to download and inspect
* the source code to these awesome engines.
* 
* <i>Note that this list is not ranked in any order</i>
* 
* <ul>
* <li><a href="http://www.ogre3d.com">Ogre3D - a rendering engine capable of OpenGL/D3D support</a></li>
* <li><a href="http://irrlicht.sourceforge.net/">Irrlicht</a></li>
* <li><a href="http://www.genesis3d.com/">Genesis3D</a></li>
* <li><a href="http://www.crystalspace3d.org/tikiwiki/tiki-view_articles.php">Crystal Space 3D</a></li>
* <li><a href="http://www.geometrictools.com">Wild Magic Software</a> - A fantastic collection of 
* helpful open source math objects, and some additional rendering and pipeline design code.</li>
* </ul>
*
* For a further list of 3D engines and their specifications, be sure
* to also visit the 3D engines database maintained at <a href="http://www.devmaster.net/engines">Devmaster.net</a>.
* 
*/



#include "Peonstdafx.h"

#include "PeonAABB.h"
#include "PeonAnimatedMeshFactory.h"
#include "PeonAudioEngine.h"
#include "PeonBillboard.h"
#include "PeonBillboardAnimation.h"
#include "PeonBoundingSphere.h"
#include "PeonIApplication.h"
#include "PeonIActor.h"
#include "PeonEngineCore.h"
#include "PeonIniConfigReader.h"
#include "PeonIUnknown.h"
#include "PeonFileLogger.h"
#include "PeonSceneCamera.h"
#include "PeonSceneFont.h"
#include "PeonSceneRenderer.h"
#include "PeonSceneTexture.h"
#include "PeonQuaternion.h"
#include "PeonMathUnit.h"
#include "PeonMatrix44.h"
#include "PeonMeshFactory.h"
#include "PeonScriptEngine.h"
#include "PeonShockwave.h"
#include "PeonSkybox.h"
#include "PeonVector2.h"
#include "PeonVector3.h"
#include "PeonVector4.h"
#include "PeonPrimTypes.h"

/*
// This class is exported from the PeonMain.dll
class PEONMAIN_API CPeonMain {
public:
	CPeonMain(void);
	// TODO: add your methods here.
};

extern PEONMAIN_API int nPeonMain;

PEONMAIN_API int fnPeonMain(void);
*/

#endif

