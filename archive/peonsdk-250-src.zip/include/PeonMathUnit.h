
#ifndef __PEONMATHUNIT_H_
#define __PEONMATHUNIT_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonISingleton.h"
#include "PeonVector3.h"

namespace peon
{
	/**
	* The whole purpose of this class/object is to create a centralized
	* work horse type object for doing some standard number crunching.
	* This object is meant as a "catch-all" for various math tasks such
	* as random number generation, etc.
	*/
	class PEONMAIN_API MathUnit : public ISingleton<MathUnit>
	{
	public:
		/**
		* Constructor
		*/
		MathUnit();

		/**
		* Destructor
		*/
		~MathUnit();

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static MathUnit& getSingleton(void);

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static MathUnit* getSingletonPtr(void);


		/**
		* This utility method just generates a random float
		* value given the range.
		* @param min - the minimum float value
		* @param max - the maximum float value
		* @return float - a value in the min-max range
		*/
		float randFloat(const float& min, const float& max); 
		
		/**
		* This utility method just generates a random int
		* value given the range.
		* @param min - the minimum int value
		* @param max - the maximum int value
		* @return int - a value in the min-max range
		*/
		int randInt(const int &min, const int &max);
		



	};
}

#endif

