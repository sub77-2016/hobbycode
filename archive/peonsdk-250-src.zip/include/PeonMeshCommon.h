
#ifndef __PEONMESHCOMMON_H_
#define __PEONMESHCOMMON_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


namespace peon
{
	/**
	* This struct just contains face information for our model
	*/
	struct PEONMAIN_API sFace
	{
		int vertIndex[3];							
		int coordIndex[3];							
	};

	/**
	* This structure just contains material information about
	* our model data
	*/
	struct PEONMAIN_API sMaterialInfo
	{
		char  strName[255];							
		char  strFile[255];							
		BYTE  color[3];								
		int   textureId;								
		float uTile;								
		float vTile;								
		float uOffset;								
		float vOffset;
		
	public:
		sMaterialInfo()
		{
			textureId = -1;
			uTile = 0.0f;
			vTile = 0.0f;
			uOffset = 0.0f;
			vOffset = 0.0f;
		}

		~sMaterialInfo()
		{
		}
	};

	/**
	* This structure contains object data of our
	* model data
	*/
	struct PEONMAIN_API s3DObject 
	{
		int  numOfVerts;			
		int  numOfFaces;			
		int  numTexVertex;			
		int  materialID;			
		bool bHasTexture;			
		char strName[255];			
		UINT      *pIndices;		
		Vector3  *pVerts;			
		Vector3  *pNormals;		
		Vector2  *pTexVerts;		
		sFace *pFaces;	
		
	public:
		s3DObject()
		{
			numOfVerts = 0;
			numOfFaces = 0;
			numTexVertex = 0;
			materialID = -1;
			bHasTexture = false;
		}
		
		~s3DObject()
		{

		}				
	};


}



#endif
