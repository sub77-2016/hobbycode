
#ifndef __PEONMESHFACTORY_H_
#define __PEONMESHFACTORY_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonISingleton.h"

#include "PeonVector2.h"
#include "PeonVector3.h"

#include "PeonSceneTexture.h"

#include "PeonMeshCommon.h"

// Primary Chunk, at the beginning of each file
#define PRIMARY       0x4D4D

// Main Chunks
#define OBJECTINFO    0x3D3D				 
#define VERSION       0x0002				
#define EDITKEYFRAME  0xB000				

// Sub defines of OBJECTINFO
#define MATERIAL	  0xAFFF				
#define OBJECT		  0x4000				

// Sub defines of MATERIAL
#define MATNAME       0xA000				
#define MATDIFFUSE    0xA020				
#define MATMAP        0xA200				
#define MATMAPFILE    0xA300				

#define OBJECT_MESH   0x4100				

// Sub defines of OBJECT_MESH
#define OBJECT_VERTICES     0x4110			
#define OBJECT_FACES		0x4120			
#define OBJECT_MATERIAL		0x4130			
#define OBJECT_UV			0x4140	




		
namespace peon
{

	/**
	* This is our 3DS generated object that we can use throughout our
	* game world / peon library. We should be able to just load the 
	* data from a 3DS file, position it where we want to in our game
	* world and render it! Zap!
	*
	* Loading in 3DS data is easy ONCE YOU KNOW HOW. It takes a bit of
	* digging around the internet to find help on this.
	*/
	struct PEONMAIN_API s3DModel 
	{
		/** number of objects in our model */
		int numOfObjects;
			
		/** number of materials in our model */						
		int numOfMaterials;
		
		/** a vector containing material data for our model */							
		std::vector<sMaterialInfo> pMaterials;	
				
		/** a vector containing object data for our model */
		std::vector<s3DObject> pObject;
		
		/** a hashtable of our textures for the model */
		std::map<int, SceneTexture*> m_oTextures;	
		
	protected:
		/**
		* This method is used by our rendering method and just sets the appropriate
		* texture in the pipeline.
		* @param ID - int key value of our texture
		*/
		void setTexture( int ID );

	public:
		/**
		* Constructor
		*/
		s3DModel();

		/**
		* Destructor
		*/
		~s3DModel();

		/**
		* This method just loads our internal structures and data.
		* @return true - if ok
		*/
		bool onLoad();
		
		/**
		* This method just renders our model to the screen
		*/
		void onRender();
		
		/**
		* This method unloads any stored/allocated memory
		*/
		void onUnload();
		
						
	};




	/**
	* This structure contains our indices into the 3DS model
	*/
	struct PEONMAIN_API sIndices {							

		unsigned short a, b, c, bVisible;		
	};

	/**
	* This structure holds the chunk information, which is just a block of data
	*/
	struct PEONMAIN_API sChunk
	{
		unsigned short int ID;					
		unsigned int length;					
		unsigned int bytesRead;	
		
	public:
		/**
		* Constructor
		*/
		sChunk()
		{
			ID = 0;
			length = 0;
			bytesRead = 0;
	
		}

		/**
		* Destructor
		*/
		~sChunk()
		{
		}
	};

	/**
	* This Singleton object in our Peon library allows us to load 3DS data
	* into some Peon-friendly objects. We want a simple way for users
	* to quickly use 3DS modeldata without too much mucking around.
	* 
	* This is a small class for now, but in the future you might want to look
	* at using this interface to support multiple model formats. :)
	*/
	class PEONMAIN_API MeshFactory : public ISingleton< MeshFactory >
	{

	protected:
		/** The stored location of our texture data */
		String m_strTexturePath;

	
	public:
		/**
		* Constructor
		*/
		MeshFactory();
		
		/**
		* Destructor
		*/
		~MeshFactory();								

		/**
		* This method is used as a loading mechanism to create a
		* s3DModel structure from a given 3DS datafile
		* @param strFileName - String of our 3DS filename
		* @return s3DModel - our generated s3DModel struct
		*/
		s3DModel* loadMeshFrom3DS( const String& strFileName, const String& strTexturePath );

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static MeshFactory& getSingleton(void);

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static MeshFactory* getSingletonPtr(void);

		/**
		* This is a small helper method for grabbing the stored
		* path of our texture data.
		* @return StringPtr - our path to the texture data
		*/
		StringPtr getTexturePath(){ return m_strTexturePath.c_str(); }


	private:
		int getString(char *);

		void readChunk(sChunk *);

		void processNextChunk(s3DModel *pModel, sChunk *);

		void processNextObjectChunk(s3DModel *pModel, s3DObject *pObject, sChunk *);

		void processNextMaterialChunk(s3DModel *pModel, sChunk *);

		void readColorChunk(sMaterialInfo *pMaterial, sChunk *pChunk);

		void readVertices(s3DObject *pObject, sChunk *);

		void readVertexIndices(s3DObject *pObject, sChunk *);

		void readUVCoordinates(s3DObject *pObject, sChunk *);

		void readObjectMaterial(s3DModel *pModel, s3DObject *pObject, sChunk *pPreviousChunk);
		
		void computeNormals(s3DModel *pModel);

		void unloadData();

		
		
		/** FILE pointer */
		FILE *m_pFile;
		
		/** our current chunk of data */
		sChunk *m_pCurrentChunk;

		/** our temporary chunk of data */
		sChunk *m_pTempChunk;
	};

}

#endif


