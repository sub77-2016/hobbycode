
#ifndef __PEONPLANE_H_
#define __PEONPLANE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"
#include "PeonVector3.h"


namespace peon
{
	/**
	* This object is used for managing plane information in our game
	* world. It can be used for detecting collisions with the boundaries
	* of our world, but Plane calculations are most often used when calculating
	* collisions with the borders of the camera; known as frustum culling.
	*
	*/
	class PEONMAIN_API Plane
	{
	public:
		/** the normal vector of this plane */
		Vector3   normal;

		/** distance of the plane from the origin */
		float	  d;

		/** 
		* Constructor
		*/
		Plane(float _x = 0.0f, float _y = 0.0f, float _z = 0.0f, float _d = 0.0f);

		/**
		* Destructor
		*/
		~Plane();

		/**
		* This method just normalizes our Plane in the same way that we normalize
		* a Vector.
		*/
        void normalize();

                



	};

}

#endif

