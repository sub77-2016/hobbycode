
#ifndef __PEONPRIMTYPES_H_
#define __PEONPRIMTYPES_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"

namespace peon
{

	/**
	* This scene primitive type is our basic starting point for getting
	* geometry rendered to our screen. 
	*/
	struct PEONMAIN_API DiffusePrim
	{
		/** x, y, z position of this vertex */
		float x, y, z;

		/** diffuse color of this vertex */
		float r, g, b, a;
	};

	/**
	* This scene primitive is a starting point for displaying geometry
	* that can contain texture coordinates.
	*/
	struct PEONMAIN_API DiffuseTexPrim
	{
		/** x, y and z position of this vertex */
		float x, y, z;

		/** diffuse color component of this vertex */
		float r, g, b, a;

		/** texture coordinates of this vertex */
		float tu, tv;
	};

	/**
	* This scene primitive is a starting point for displaying any type
	* of geometry in our game world. It contains enough information to
	* properly help lighting, blending and texture mapping calculations.
	*/
	struct PEONMAIN_API NormalDiffuseTexPrim
	{
		/** x, y and z position of this vertex */
		float x, y, z;

		/** x, y and z components of the vector normal */
		float nx, ny, nz;

		/** diffuse color component of this vertex */
		float r, g, b, a;

		/** texture coordinates of this vertex */
		float tu, tv;

	};
}

#endif

