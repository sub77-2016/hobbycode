
#ifndef __PEONQUATERNION_H_
#define __PEONQUATERNION_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"

namespace peon
{
	/**
	* This object is responsible for wrapping up Quaternion
	*/
	class PEONMAIN_API Quaternion
	{
	public:
		
		/** x component */
		float x;

		/** y component */
		float y;

		/** z component */
		float z;

		/** z component */
		float w;

		/**
		* Constructor
		*/
		Quaternion(float _x = 0.0f, float _y = 0.0f, float _z = 0.0f, float _w = 1.0f);

		/**
		* Destructor
		*/
		~Quaternion();

		/**
		* This method converts an axis and rotation angle to a Quaternion
		* @param _x - x position
		* @param _y - y position
		* @param _z - z position
		* @param degree - rotation angle around axis. (In degrees )
		*/
		void createFromAxisAngle(float _x, float _y, float _z, float degree);

		/**
		* This method takes our current Quaternion and converts it to
		* a nice and friendly Matrix44 object..(a 4x4 homogenous matrix)
		* @param pMatrix - reference to a Matrix44 object
		*/
		void createMatrix(Matrix44* pMatrix);
	};

}

#endif

