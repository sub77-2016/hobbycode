
#ifndef __PEONRAY_H_
#define __PEONRAY_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"
#include "PeonVector3.h"

namespace peon
{
	/**
	* This object is used to represent a Ray in our gameworld. All we need
	* is a @see Vector3 position and a direction for the Ray to calculate other
	* goodness within our game world.
	*/
	class PEONMAIN_API Ray
	{

	public:
		/** origin of our ray */
		Vector3 m_vecOrigin;

		/** direction of our ray */
		Vector3 m_vecDirection;

	public:
		/**
		* Constructor
		*/
		Ray();

		/**
		* Destructor
		*/
		~Ray();

	};

}

#endif
