
#ifndef __PEONSCENEFONT_H_
#define __PEONSCENEFONT_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonIUnknown.h"

namespace peon
{
	/**
	* This object of the Peon library is meant to encapsulate a textured
	* font object for your game. You provide it with a bitmap image
	* of the alphabet you want to use (in ASCII format), then just notify
	* this object of the dimensions of the bitmap. ie. how many rows
	* and columns of characters there are, along with the pixel width 
	* and height of a single character.
	*
	* This object is based off of the GLFont object made available by Jeff
	* Molofee (aka. Nehe) at http://nehe.gamedev.net, an excellent 
	* repository of OpenGL tutorials.
	*/
	class PEONMAIN_API SceneFont : public IUnknown
	{

	protected:
		/** display list to contain alphabet */
		GLuint m_display_list;

		/** width of a single character */
		int m_char_width;

		/** height of a single character */
		int m_char_height;

		/** spacing between characters */
		int m_char_spacing;

		/** how many characters in a line/row */
		int m_fxCount;

		/** how many characters in a column */
		int m_fyCount;

		/** the current red color when rendering our text*/
		float m_r;

		/** the current green color when rendering our text*/
		float m_g;

		/** the current blue color when rendering our text*/
		float m_b;

		/** the current alpha color when rendering our text*/
		float m_a;

		/** are we current batching text? */
		bool m_font_batching; 


	public:
		/**
		* Constructor
		*/
		SceneFont();

		/**
		* Destructor
		*/
		~SceneFont();

		/**
		* This method is responsible for loading up our SceneFont
		* instance.
		* @param width - 
		* @param height -
		* @param spacing -
		* @return bool - true if everything loaded properly
		*/
		bool loadFont(int width = 16, int height = 16, int spacing = 14);

		/**
		* This method is just used to unload our SceneFont instance
		*/
		void unloadFont();

		/**
		* This method is the "workhorse" which renders our text. We
		* specify the x and y position of the text and that's where
		* the SceneFont will render it!
		* @param xpos - x position of text
		* @param ypos - y position of text 
		* @param strText - our text to render
		* @return void
		*/
		void renderText(float xpos, float ypos, const String& strText);

		/**
		* This method just sets our color components in case we want
		* to apply any color to the text we're about to render.
		* @param r - red component
		* @param g - green component
		* @param b - blue component 
		* @param a - alpha component
		* @return void
		*/
		void setColor( float r = 1.0f, float g = 1.0f, float b = 1.0f, float a = 1.0f);

		/**
		* Sometimes we want to render batches of text to the screen...say like a 
		* story, dialog text or whatever. To minimize the state changes, let's
		* create a way for the the program to batch all the font rendering 
		* commands THEN re-enable our original state/stacks..
		* @return bool - are we ready to batch text?
		*/
		bool beginBatchFont();

		/**
		* We need to ensure we pair a beginBatchFont with an endBatchFont
		*/
		void endBatchFont();
		

	};

}

#endif

