
#ifndef __PEONSCENELIGHT_H_
#define __PEONSCENELIGHT_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonISceneObject.h"
#include "PeonVector4.h"

namespace peon
{
	/**
	* This object acts as a crude container for our lighting modes we wish
	* to inject into the graphics pipeline. We just need to set a few properties,
	* and feed it into the @see SceneRenderer to take effect.
	*/
	class PEONMAIN_API SceneLight : public ISceneObject
	{
	public:
		/** our ambient light setting */
		Vector4 m_vecAmbient;

		/** our diffuse light setting */
		Vector4 m_vecDiffuse;

		/** our light position..most often also the direction of the light*/
		Vector4 m_vecDirection;

	public:
		/**
		* Constructor
		*/
		SceneLight();

		/**
		* Destructor
		*/
		~SceneLight();
	};
}

#endif
