
#ifndef __PEONSCENERENDERER_H_
#define __PEONSCENERENDERER_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonIUnknown.h"
#include "PeonPrimTypes.h"
#include "PeonSceneCamera.h"
#include "PeonSceneLight.h"
#include "PeonSceneTexture.h"
#include "PeonSceneFont.h"
#include "PeonMatrix44.h"


/** our maximum lights allowed at one time in our engine. OpenGL allows
* 7 if I remember right, and Direct3D allows something similar. New hardware
* might blow these boundaries away through shader mechanisms, but let's pretend you 
* can only use 7
*/
#define MAX_LIGHTS 7

namespace peon
{
	/**
	* This object is responsible for processing our rendering commands
	* to the underlying video hardware. Rather than spread a whole bunch
	* of API specific code in our actual game, it'd be nice to just command
	* this object to do the work for us.
	*/
	class PEONMAIN_API SceneRenderer : public IUnknown
	{
	protected:
		/** OpenGL rendering surface */
		SDL_Surface*		m_pOGLSurface;

		/** surface width */
		int					m_iDeviceWidth;

		/** surface height */
		int					m_iDeviceHeight;

		/** surface bits-per-pixel */
		int					m_iBitsPerPixel;

		/** windowed or fullscreen? */
		bool				m_bWindowed;

		/** our current SceneCamera object */
		SceneCamera*			m_pActiveCamera;

		/** an array of SceneLight objects. */
		SceneLight				m_oLights[MAX_LIGHTS];

		boost::ptr_list<SceneTexture> m_oTextureList;


	public:
		/**
		* Constructor
		*/
		SceneRenderer();

		/**
		* Destructor
		*/
		~SceneRenderer();

		/**
		* This method loads our configuration settings in order to prepare
		* our rendering context
		* @param pConfig - IniConfigReader object
		* @return bool - true or false
		*/
		bool loadDevice( IniConfigReader* pConfig );

		/**
		* This method deallocated and cleans up our surfaces 
		*/
		void unloadDevice();
		
		/**
		* This method clears the back buffer and prepares it for us
		* to send rendering commands to
		* @return bool - always true
		*/
		bool clearDevice();

		/**
		* This method is responsible for swapping our back buffer with
		* the front one...thereby rendering a new screen
		*/
		void flipDevice();

		/**
		* This method is called when our window is resized, hence
		* our aspect ratio may need to be updated...
		* @param int - width of our window
		* @param int - height of our window
		*/
		void resizeDevice(int width, int height);

		/**
		* This method takes in an array of vertices and renders them to
		* our context
		* @param pVertices - array of DiffusePrim objects
		* @param count     - count of DiffusePrim objects in array
		*/
		void drawPrim( DiffusePrim* pVertices, int count );

		/**
		* This method takes in an array of vertices and renders them to
		* our context
		* @param pVertices - array of DiffuseTexPrim objects
		* @param count     - count of DiffuseTexPrim objects in array
		*/
		void drawPrim( DiffuseTexPrim* pVertices, int count );

		/**
		* This method takes in an array of vertices and renders them to
		* our context
		* @param pVertices - array of NormalDiffuseTexPrim objects
		* @param count     - count of NormalDiffuseTexPrim objects in array
		*/
		void drawPrim( NormalDiffuseTexPrim* pVertices, int count );

		/**
		* This method takes in an array of vertices and renders them to
		* our context
		* @param pVertices - array of NormalDiffuseTexPrim objects
		* @param count     - count of NormalDiffuseTexPrim objects in array
		*/
		void drawQuads( NormalDiffuseTexPrim* pVertices, int count );

		/**
		* This method simply sets a set of lighting states within our
		* scene depending upon the parameters 
		* @param light_slot - which slot we wish to affect
		* @param oLight     - our SceneLight object
		*/
		void setLight(int light_slot, const SceneLight& oLight);

		/**
		* @deprecated - should use other loadTexture()
		* This method is responsible for loading an image into
		* the texture memory of your device
		* @param strFilename - the path to the image file
		* @param bAlpha - do we have an alpha channel?
		* @param bMipMaps - do we create mipmaps?
		* @param bRepeat - do we repeat the texture?
		* @return SceneTexture* - pointer to the created SceneTexture object
		*/
		SceneTexture* loadTexture( const String& strFilename, bool bAlpha = true,
			bool bMipMaps = true, bool bRepeat = false);


		bool loadTexture( int key, const String& strFilename, bool bAlpha = true, bool bMipMaps = true, bool bRepeat = false);

		int setTexture(int key);


		/**
		* This method is responsible for loading a font object into a 
		* SceneFont handle
		* @param char_width - pixel width of each character
		* @param char_height - pixel height of each character
		* @param char_spacing - spacing in pixels between character
		* @return SceneFont* - handle to our created SceneFont
		*/
		SceneFont* loadFont( int char_width = 16, int char_height = 16, int char_spacing = 10 );

		/**
		* This method just returns our active camera
		* @return SceneCamera* - handle to our SceneCamera
		*/
		SceneCamera* getActiveCamera(){ return m_pActiveCamera; }

		/**
		* Gets the width of our device
		* @return int - device width 
		*/
		int getWidth(){ return m_iDeviceWidth; }

		/**
		* Gets the height of our device
		* @return int - device height
		*/
		int getHeight(){ return m_iDeviceHeight; }

		/**
		* Check to see if an extension is supported
		* @param strExtension - string object containing extension name
		* @return bool - true if it does, false otherwise
		*/
		bool isExtensionSupported( const String& strExtension );

		/**
		* This method is responsible for taking screen captures
		*/
		void getScreenCapture();

		/**
		* This method simply fills a Matrix44 object with the current
		* projection matrix
		* @param pMat - handle to our Matrix44 object
		*/
		void getProjectionMatrix( Matrix44& pMat );
		
		/**
		* This method simply fills a Matrix44 object with the current
		* modelview matrix
		* @param pMat - handle to our Matrix44 object
		*/
		void getModelViewMatrix( Matrix44& pMat );

		/**
		* Just sets a new color to clear the device with
		* @param r - red component
		* @param g - green component 
		* @param b - blue component
		* @param a - alpha component
		*/
		void setClearColor(float r, float g, float b, float a);



	};
}

#endif
