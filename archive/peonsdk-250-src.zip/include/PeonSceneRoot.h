
#ifndef __PEONSCENEROOT_H_
#define __PEONSCENEROOT_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/



#include "PeonISingleton.h"
#include "PeonSceneRenderer.h"
#include "PeonISceneObject.h"

namespace peon
{
	/**
	* This object represents the "Base node" of a scene graph for
	* you to play with. Right now this is little more than a display
	* list, but it gives you an idea of what's possible. To create
	* a true Octree or QuadTree structure is left as your own
	* exercise.
	*/
	class PEONMAIN_API SceneRoot : public ISceneObject, ISingleton<SceneRoot>
	{
	protected:
		/** our SceneRenderer handle */
		SceneRenderer*	m_pRenderer;

		/** our linked list of ISceneObjects */
		std::list<ISceneObject*> m_oDisplayList;


	public:

		/**
		* Constructor
		*/
		SceneRoot( SceneRenderer* pRenderer );

		/**
		* Destructor
		*/
		~SceneRoot();

		/** Override standard Singleton retrieval.
		*/
		static SceneRoot& getSingleton(void);

		/** Override standard Singleton retrieval.
		*/
		static SceneRoot* getSingletonPtr(void);

		/**
		* This method is used to load/add new ISceneObjects to our
		* display list. 
		* @param pObj - the ISceneObject-based object to add to the display list
		*/
		bool loadDisplayObject( ISceneObject* pObj );
		
		/**
		* This method is used to unload and clear the ISceneObjects
		* in our display graph
		*/
		void unloadDisplayObjects();


	};
}

#endif
