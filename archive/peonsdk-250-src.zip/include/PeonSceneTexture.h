

#ifndef __PEONSCENETEXTURE_H_
#define __PEONSCENETEXTURE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "PeonIUnknown.h"




namespace peon
{
	/**
	* This object encapsulates the "magic" behind loading and manipulating
	* texture data. Right now, it's a very simplistic container but 
	* to start with, that's all we need. It can handle any image format
	* supported by the SDL_Image helper library. For the most part, I usually
	* try to stick with BMP's, TGA's and PNG's.
	*/
	class PEONMAIN_API SceneTexture : public IUnknown
	{
	public:
		/** OpenGL-specific texture handle */
		GLuint m_tex;

	protected:
		/** 
		* Method to scan the surface at particular coordinates to
		* grab the pixel data
		* @param surface - SDL_Surface object to work with 
		* @param x       - x coordinate 
		* @param y       - y coordinate
		* @return Uint32 - unsigned integer representing pixel info
		*/
		Uint32 getPixel(SDL_Surface *surface, int x, int y);

	public:
		/**
		* Constructor
		*/
		SceneTexture();

		/**
		* Destructor
		*/
		~SceneTexture();

		/**
		* This method loads the image into this object and
		* gets everything correctly configured for use in the
		* pipeline
		* @param strFilename - filename of texture
		* @param bAlpha - do we want the alpha channel?
		* @param bMipMaps - do we want to create mipmaps?
		* @param bRepeat - do we want to repeat this texture?
		* @return bool - true if we're all ok
		*/
		bool loadImage( const String& strFilename, bool bAlpha, bool bMipMaps, bool bRepeat );

		/**
		* This method just returns the handle to our texture data
		* @return GLuint - texture data handle
		*/
		GLuint getTex(){ return m_tex; }
 
	};
}

#endif

