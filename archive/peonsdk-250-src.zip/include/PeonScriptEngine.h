
#ifndef __PEONSCRIPTENGINE_H_
#define __PEONSCRIPTENGINE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISingleton.h"

namespace peon
{

#if defined( PEON_USE_LUA_ )
	/**
	* This Singleton object represents our scripting interface to Lua.
	* We should keep this as clean and tidy as possible, to allow users
	* to implement their own scripting engine as they feel comfortable
	* with.
	*
	* I'm downloading and using the static library
	* files from this Lua area. 
	*
	* http://luaforge.net/frs/?group_id=110
	*/
	class PEONMAIN_API ScriptEngine : public ISingleton<ScriptEngine>
	{

	protected:
		/** our LUA VM handle */
		lua_State*			m_pLuaVM;


	public:

		/**
		* Constructor
		*/
		ScriptEngine();

		/**
		* Destructor
		*/
		~ScriptEngine();

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static ScriptEngine& getSingleton(void);

		/** Override standard Singleton retrieval.
		@remarks
		@par
		*/
		static ScriptEngine* getSingletonPtr(void);

		/**
		* This method loads up and configures our Lua VM subsystem.
		*
		* @param pConfig - a valid IniConfigReader instance
		* @return bool - always true
		*/
		bool loadEngine( IniConfigReader* pConfig );

		/**
		* This method just unloads and frees any allocated input devices
		*/
		void unloadEngine();


	};

#endif

}

#endif
