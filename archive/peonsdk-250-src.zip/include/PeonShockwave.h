
#ifndef __PEONSHOCKWAVE_H_
#define __PEONSHOCKWAVE_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISceneObject.h"
#include "PeonSceneTexture.h"

namespace peon
{
	/**
	* This object is used by the @see Shockwave to 
	*
	*/
	class PEONMAIN_API ParticleVtx
	{

	public:
		/** x position */
		float m_x;
		
		/** y position */
		float m_y;
		
		/** z position */
		float m_z;

		/** x normal */
		float m_nx;
		
		/** y normal */
		float m_ny;
		
		/** z normal */
		float m_nz;

		/** red color value */
		int m_r;
		
		/** green color value */
		int m_g;
		
		/** blue color value */
		int m_b; 
		
		/** alpha color value */
		int m_a;

		/** tu texture coordinate */
		float m_tu;
		
		/** tv texture coordinate */
		float m_tv;

	public:
		/**
		* Constructor
		*/
		ParticleVtx( float x = 0.0f, float y = 0.0f, float z = 0.0f, float nx = 0.0f, float ny = 0.0f, float nz = 0.0f,
					 int r = 255, int g = 255, int b = 255, int a = 255, float tu = 0.0f, float tv = 0.0f)
		{
			m_x = x;
			m_y = y;
			m_z = z;
			m_nx = nx;
			m_ny = ny;
			m_nz = nz;
			m_r = r;
			m_g = g;
			m_b = b;
			m_a = a;
			m_tu = tu;
			m_tv = tv;
		}

		/**
		* Destructor
		*/
		~ParticleVtx(){}
	};


	/**
	* This object creates and renders a shockwave type effect for our scene. Nothing too special,
	* it just takes our shockwave texture and renders a continuously radiating stream of vertices
	* until our maximums have been reached.
	*/
	class PEONMAIN_API Shockwave : public ISceneObject
	{
	public:
		/** is it currently running? */
		bool	      m_bIsRunning;

		/** our position */
		Vector3 m_vecPos;

		/** number of divisions in the shockwave. The more division, the more circular the effect */
		int           m_iNumDivisions;

		/** thickness of the wave */
		float         m_fThickness;

		/** lifetime of the particles */
		float m_fLifetime;

		/** their current age */
		float m_fAge;

		/** the rate at which the particles expand/contract */
		float m_fExpandRate;

		/** size */
		float m_fSize;

		/** scale */
		float m_fScale;

		/** number of vertices */
		int m_iNumVerts;

		/** particle vertices array */
		ParticleVtx* m_pParticles;

		SceneTexture* m_pTexture;


	public:
		/**
		* Constructor
		*/
		Shockwave();

		/**
		* Destructor
		*/
		~Shockwave();
		
		/**
		* This method is responsible for loading the object and setting everything up
		* @param fSize - size of our shockwaves
		* @param fThickness - thickness of them
		* @param iNumDivisions - number of divisions in the wave
		* @param fExpandRate - how quickly the wave expands (use a negative value for contraction)
		* @param fLifetime - how long the wave "lives"
		* @return bool - true if everything loaded ok
		*/
		bool load(float fSize, float fThickness, int iNumDivisions, float fExpandRate, float fLifetime);
		
		/**
		* Unload any allocated memory for this object.
		*/
		void unload();

		/**
		* Start animating and rendering the wave 
		*/
		void start();

		/**
		* Stop animating and rendering the wave
		*/
		void stop();

		/**
		* Update the vertices and their corresponding alpha value
		* @param fElapsedTime - time between cpu frames
		*/
		void update( float fElapsedTime );

		/**
		* Render our shockwave
		*/
		void render();
	
	};



}

#endif


