
#ifndef __PEONSKYBOX_H_
#define __PEONSKYBOX_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "PeonISceneObject.h"


namespace peon
{
	/**
	* This is our Skybox component of the Peon library that just allows us to render a 
	* cube full of sky goodness as a background for our scene. 
	*/
	class PEONMAIN_API Skybox : public ISceneObject
	{
	public:
		/** left texture */
		SceneTexture* m_pLeftTexture;
		
		/** right texture */
		SceneTexture* m_pRightTexture;
		
		/** top texture */
		SceneTexture* m_pTopTexture;
		
		/** bottom texture */
		SceneTexture* m_pBottomTexture;
		
		/** front texture */
		SceneTexture* m_pFrontTexture;
		
		/** back texture */
		SceneTexture* m_pBackTexture;
	
		/** dimension (size) of our skybox */
		Vector3		m_vecDim;
		
		/** position of this skybox in our game world */
		Vector3		m_vecPos;
	
	public:
		/**
		* Constructor
		*/
		Skybox();
	
		/**
		* Destructor
		*/
		~Skybox();

		/**
		* This method is responsible for loading up the desired textures for our
		* skybox. We're basically rendering a giant cube in space centered around
		* our camera position. 
		* @param strTexLeft - the left wall texture
		* @param strTexRight- the right wall texture
		* @param strTexFront- the front wall texture
		* @param strTexBack - the rear wall texture
		* @param strTexTop  - the top wall texture
		* @param strTexBottom- the bottom wall texture
		* @return bool - true if they all loaded ok
		*/
		bool load( const String &strTexLeft, const String& strTexRight,
				   const String &strTexFront, const String& strTexBack,
				   const String &strTexTop,   const String& strTexBottom);
	
		/**
		* This method just unloads any allocated memory for this object
		*/
		void unload();
	
		/**
		* This method is responsible for rendering the skybox with the given x, y, z
		* position in space. 
		* @param x - x position
		* @param y - y position
		* @param z - z position
		*/
		void render(float x, float y, float z);
		
	};	
	
	
	
}

#endif

