
#ifndef __PEONTIMER_H_
#define __PEONTIMER_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "peonstdafx.h"

namespace peon
{
	/**
	* This object as a way to properly control animation and other effects in our
	* scene relying on the "timing" in the game. Every frame of the game, we 
	* update this object with a snapshot of the current clock of the CPU in order
	* to create a delta (differential) with the last clock snapshot. This delta
	* controls the movement of the objects in our gameworld.
	*
	* To make this object more platform independent, feel free to investigate
	* using the SDL timer functions
	*
	* Note that on some newer systems, the QueryPerformanceCounter
	* doesn't always cut the mustard and there are some known limitations.
	* For more information, this support document in the msdn might
	* provide more clarity on the different timer resolutions available
	* on the Windows platform. 
	* <a href="http://support.microsoft.com/default.aspx?kbid=172338">Q172338</a>
	*
	* Depending upon your app, the resolution of timeGetTime() 
	* might be enough for your object animation.
	*
	* It really just takes some experimentation folks..
	*/
	class PEONMAIN_API Timer
	{
	protected:
		/** are we using the high performance timer?*/
		bool m_bUsingQPF;

		/** is the timer stopped? */
		bool m_bTimerStopped;

		/** LONGLONG for ticks/sec */
		LONGLONG m_llQPFTicksPerSec;

		LONGLONG m_llStopTime;
		LONGLONG m_llLastElapsedTime;
		LONGLONG m_llBaseTime;

	public:
		/**
		* Constructor
		*/
		Timer();

		/**
		* Destructor
		*/
		~Timer();

		/**
		* This method resets the timer
		*/
		void reset();

		/**
		* This method starts the timer
		*/
		void start();

		/**
		* This method is used to stop/pause the timer
		*/
		void stop();

		/**
		* This method is used to incrementally advance the
		* timer by 0.1 seconds
		*/
		void advance();
		
		/**
		* This method returns the absolute system time
		* @return float - absolute system time
		*/
		float getAbsoluteTime();

		/**
		* This method returns the current time
		* @return float - the current time
		*/
		float getTime();

		/**
		* This method returns the time that has elapsed between
		* getElapsedTime
		* @return float - the time delta
		*/
		float getElapsedTime();

		/**
		* This method just returns if our timer is active or not
		* @return bool - true if timer is stopped
		*/
		bool isStopped();

	};
}

#endif
