#ifndef __PEONVECTOR2_H_
#define __PEONVECTOR2_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"

namespace peon 
{

	/**
	* This object is used to represent a 3-tuple entity for use mostly during
	* object positioning in a 3D gameworld. It's perfectly acceptable to keep
	* the z-plane variable to 1.0f, if you're only interested in using 2D
	* graphics.
	*/
	class PEONMAIN_API Vector2
	{
	public:

		/** x component */
		float x;

		/** y component */
		float y;

		/**
		* Constructor
		* 
		*/  
		Vector2(float x_ = 0.0f, float y_ = 0.0f);

		/**
		* Destructor
		*/
		~Vector2();

		/**
		* setter method 
		* @param x_ : x component
		* @param y_ : y component
		*/
		void set(float x_, float y_);

		/**
		* calculate the length of this vector
		* @return float 
		*/
		float length(void);

		/**
		* Normalize the vector. Divide each component by 1.0f
		*/
		void normalize(void);

		// Static utility methods
		static float distance(const Vector2 &v1, const Vector2 &v2);
		static float dotProduct(const Vector2 &v1,  const Vector2 &v2 );
	
		// Operators...
		Vector2 operator + (const Vector2 &other);
		Vector2 operator - (const Vector2 &other);
		Vector2 operator * (const Vector2 &other);
		Vector2 operator / (const Vector2 &other);

		Vector2 operator * (const float scalar);
		friend Vector2 operator * (const float scalar, const Vector2 &other);
    
		Vector2& operator = (const Vector2 &other);
		Vector2& operator += (const Vector2 &other);
		Vector2& operator -= (const Vector2 &other);

		Vector2 operator + (void) const;
		Vector2 operator - (void) const;
	};



}

#endif

