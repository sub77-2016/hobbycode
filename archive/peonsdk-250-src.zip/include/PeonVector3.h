#ifndef __PEONVECTOR3_H_
#define __PEONVECTOR3_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/


#include "Peonstdafx.h"

namespace peon 
{

	/**
	* This object is used to represent a 3-tuple entity for use mostly during
	* object positioning in a 3D gameworld. It's perfectly acceptable to keep
	* the z-plane variable to 1.0f, if you're only interested in using 2D
	* graphics.
	*/
	class PEONMAIN_API Vector3
	{
	public:

		/** x component */
		float x;

		/** y component */
		float y;

		/** z component */
		float z;

		/**
		* Constructor
		* 
		*/  
		Vector3(float x_ = 0.0f, float y_ = 0.0f, float z_ = 0.0f);

		/**
		* Destructor
		*/
		~Vector3();

		/**
		* setter method 
		* @param x_ : x component
		* @param y_ : y component
		* @param z_ : z component 
		*/
		void set(float x_, float y_, float z_);

		/**
		* calculate the length of this vector
		* @return float 
		*/
		float length(void);

		/**
		* Normalize the vector. Divide each component by 1.0f
		*/
		void normalize(void);

		// Static utility methods
		static float distance(const Vector3 &v1, const Vector3 &v2);
	
		inline float dotProduct(const Vector3& vec) const
        {
            return x * vec.x + y * vec.y + z * vec.z;
        }

		inline Vector3 crossProduct( const Vector3& vecInput ) const
        {
            Vector3 vecCross;

            vecCross.x = y * vecInput.z - z * vecInput.y;
            vecCross.y = z * vecInput.x - x * vecInput.z;
            vecCross.z = x * vecInput.y - y * vecInput.x;

            return vecCross;
        }

		// Operators...
		Vector3 operator + (const Vector3 &other);
		Vector3 operator - (const Vector3 &other);
		Vector3 operator * (const Vector3 &other);
		Vector3 operator / (const Vector3 &other);

		Vector3 operator / (const float scalar);
		Vector3 operator * (const float scalar);
		friend Vector3 operator * (const float scalar, const Vector3 &other);
    
		Vector3& operator = (const Vector3 &other);
		Vector3& operator += (const Vector3 &other);
		Vector3& operator -= (const Vector3 &other);

		Vector3 operator + (void) const;
		Vector3 operator - (void) const;
	};



}

#endif

