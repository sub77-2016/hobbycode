#ifndef __PEONVECTOR4_H_
#define __PEONVECTOR4_H_
/*
Peon - Win32 Games Programming Library
Copyright (c) 2002-2008, Erik Yuzwa
http://www.wazooinc.com/peon-sdk/
*/

#include "Peonstdafx.h"

namespace peon
{
	/**
	* This object is used as a 4-tuple. So far it's mainly just used for
	* lighting purposes in the @see SceneLight object, but it could also perhaps
	* be used to store RGBA color information...
	*
	*/
	class PEONMAIN_API Vector4
	{
	public:
		/** x component */
		float x;

		/** y component */
		float y;

		/** z component */
		float z;

		/** w component */
		float w;

		/**
		* Constructor
		*/
		Vector4(float x_ = 0.0f, float y_ = 0.0f, float z_ = 0.0f, float w_ = 0.0f);

		/**
		* Destructor
		*/
		~Vector4();

		void set(float x_, float y_, float z_, float w_);
		float length(void);
		void normalize(void);

		// Static utility methods
		static float distance(const Vector4 &v1, const Vector4 &v2);
		static float dotProduct(const Vector4 &v1,  const Vector4 &v2 );
		static Vector4 crossProduct(const Vector4 &v1, const Vector4 &v2);

		// Operators...
		Vector4 operator + (const Vector4 &other);
		Vector4 operator - (const Vector4 &other);
		Vector4 operator * (const Vector4 &other);
		Vector4 operator / (const Vector4 &other);

		Vector4 operator * (const float scalar);
		friend Vector4 operator * (const float scalar, const Vector4 &other);
    
		Vector4& operator = (const Vector4 &other);
		Vector4& operator += (const Vector4 &other);
		Vector4& operator -= (const Vector4 &other);

		Vector4 operator + (void) const;
		Vector4 operator - (void) const;
	};

}

#endif

