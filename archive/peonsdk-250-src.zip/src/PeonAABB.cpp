
#include "PeonAABB.h"

namespace peon
{
	AABB::AABB()
	{
	}

	AABB::~AABB()
	{

	}

	void AABB::generateBox( const Vector3& vec )
	{
		if(vec.x < m_vecMin.x) m_vecMin.x = vec.x;

		if(vec.y < m_vecMin.y) m_vecMin.y = vec.y;

		if(vec.x > m_vecMax.x) m_vecMax.x = vec.x;

		if(vec.y > m_vecMax.y) m_vecMax.y = vec.y;
	}

	bool AABB::doCollision( const AABB* obj1 )
	{
		//early fail for nulls
		//if( obj1 == NULL )
		//{
		//	return false;
		//}

		if( m_vecMax.x < obj1->m_vecMin.x)
			return false;

		if( m_vecMax.y < obj1->m_vecMin.y)
			return false;

		if( m_vecMin.x > obj1->m_vecMax.x)
			return false;

		if( m_vecMin.y > obj1->m_vecMax.y)
			return false;


		return true;

	}
}