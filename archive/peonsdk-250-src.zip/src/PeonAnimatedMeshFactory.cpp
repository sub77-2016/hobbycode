
#include "PeonAnimatedMeshFactory.h"
#include "PeonFileLogger.h"
#include "PeonEngineCore.h"

namespace peon
{

	bool IsInString(const String& strString, const String& strSubString)
	{
		// Make sure both of these strings are valid, return false if any are empty
		if(strString.length() <= 0 || strSubString.length() <= 0) return false;

		// grab the starting index where the sub string is in the original string
		int index = strString.find(strSubString);

		// Make sure the index returned was valid
		if(index >= 0 && index < strString.length())
			return true;

		// The sub string does not exist in strString.
		return false;
	}

	template<> AnimatedMeshFactory* ISingleton<AnimatedMeshFactory>::ms_Singleton = 0;

	AnimatedMeshFactory* AnimatedMeshFactory::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	AnimatedMeshFactory& AnimatedMeshFactory::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	AnimatedMeshFactory::AnimatedMeshFactory()
	{
		// Here we initialize our structures to 0
		memset(&m_Header, 0, sizeof(sMd3Header));

		// Set the pointers to null
		m_pSkins=NULL;
		m_pTexCoords=NULL;
		m_pTriangles=NULL;
		m_pBones=NULL;
	}

	AnimatedMeshFactory::~AnimatedMeshFactory()
	{

	}

	s3DAnimModel* AnimatedMeshFactory::loadMeshFromMD3( const String& strFileName )
	{
		char strMessage[255];

		s3DAnimModel* pModel = new s3DAnimModel();

		// This function handles the entire model loading for the .md3 models.
		// What happens is we load the file header, make sure it's a valid MD3 model,
		// then load the rest of the data, then call our CleanUp() function.

		sprintf(strMessage, "Attempting to load mesh: %s", strFileName.c_str());
		FileLogger::getSingleton().logInfo("AnimatedMeshFactory", strMessage );

		// Open the MD3 file in binary
		m_pFile = fopen(strFileName.c_str(), "rb");

		// Make sure we have a valid file pointer (we found the file)
		if(!m_pFile) 
		{
			// Display an error message and don't load anything if no file was found
			sprintf(strMessage, "Unable to find the file: %s!", strFileName.c_str());
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage );
			return NULL;
		}
    
		// Now that we know the file was found and it's all cool, let's read in
		// the header of the file.  If it has the correct 4 character ID and version number,
		// we can continue to load the rest of the data, otherwise we need to print an error.

		// Read the header data and store it in our m_Header member variable
		fread(&m_Header, 1, sizeof(sMd3Header), m_pFile);

		// Get the 4 character ID
		char *ID = m_Header.fileID;

		// The ID MUST equal "IDP3" and the version MUST be 15, or else it isn't a valid
		// .MD3 file.  This is just the numbers ID Software chose.

		// Make sure the ID == IDP3 and the version is this crazy number '15' or else it's a bad egg
		if((ID[0] != 'I' || ID[1] != 'D' || ID[2] != 'P' || ID[3] != '3') || m_Header.version != 15)
		{
			// Display an error message for bad file format, then stop loading
			sprintf(strMessage, "Invalid file format (Version not 15): %s!", strFileName.c_str());
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage );
			return NULL;
		}
    
		// Read in the model and animation data
		readMD3Data(pModel);

		// Clean up after everything
		unloadData();

		// Return a success
		return( pModel );
	}

	void AnimatedMeshFactory::readMD3Data(s3DAnimModel *pModel)
	{
		int i = 0;

		// This member function is the BEEF of our whole file.  This is where the
		// main data is loaded.  The frustrating part is that once the data is loaded,
		// you need to do a billion little things just to get the model loaded to the screen
		// in a correct manner.

		// Here we allocate memory for the bone information and read the bones in.
		m_pBones = new sMd3Bone [m_Header.numFrames];
		fread(m_pBones, sizeof(sMd3Bone), m_Header.numFrames, m_pFile);

		// Since we don't care about the bone positions, we just free it immediately.
		// It might be cool to display them so you could get a visual of them with the model.

		// Free the unused bones
		delete [] m_pBones;

		// Next, after the bones are read in, we need to read in the tags.  Below we allocate
		// memory for the tags and then read them in.  For every frame of animation there is
		// an array of tags.
		pModel->pTags = new sMd3Tag [m_Header.numFrames * m_Header.numTags];
		fread(pModel->pTags, sizeof(sMd3Tag), m_Header.numFrames * m_Header.numTags, m_pFile);

		// Assign the number of tags to our model
		pModel->numOfTags = m_Header.numTags;
    
		// Now we want to initialize our links.  Links are not read in from the .MD3 file, so
		// we need to create them all ourselves.  We use a double array so that we can have an
		// array of pointers.  We don't want to store any information, just pointers to s3DModels.
		pModel->pLinks = (s3DAnimModel **) malloc(sizeof(s3DAnimModel) * m_Header.numTags);
    
		// Initilialize our link pointers to NULL
		for (i = 0; i < m_Header.numTags; i++)
			pModel->pLinks[i] = NULL;

		// Now comes the loading of the mesh data.  We want to use ftell() to get the current
		// position in the file.  This is then used to seek to the starting position of each of
		// the mesh data arrays.

		// Get the current offset into the file
		long meshOffset = ftell(m_pFile);

		// Create a local meshHeader that stores the info about the mesh
		sMd3MeshInfo meshHeader;

		// Go through all of the sub-objects in this mesh
		for (i = 0; i < m_Header.numMeshes; i++)
		{
			// Seek to the start of this mesh and read in it's header
			fseek(m_pFile, meshOffset, SEEK_SET);
			fread(&meshHeader, sizeof(sMd3MeshInfo), 1, m_pFile);

			// Here we allocate all of our memory from the header's information
			m_pSkins     = new sMd3Skin [meshHeader.numSkins];
			m_pTexCoords = new sMd3TexCoord [meshHeader.numVertices];
			m_pTriangles = new sMd3Face [meshHeader.numTriangles];
			m_pVertices  = new sMd3Triangle [meshHeader.numVertices * meshHeader.numMeshFrames];

			// Read in the skin information
			fread(m_pSkins, sizeof(sMd3Skin), meshHeader.numSkins, m_pFile);
        
			// Seek to the start of the triangle/face data, then read it in
			fseek(m_pFile, meshOffset + meshHeader.triStart, SEEK_SET);
			fread(m_pTriangles, sizeof(sMd3Face), meshHeader.numTriangles, m_pFile);

			// Seek to the start of the UV coordinate data, then read it in
			fseek(m_pFile, meshOffset + meshHeader.uvStart, SEEK_SET);
			fread(m_pTexCoords, sizeof(sMd3TexCoord), meshHeader.numVertices, m_pFile);

			// Seek to the start of the vertex/face index information, then read it in.
			fseek(m_pFile, meshOffset + meshHeader.vertexStart, SEEK_SET);
			fread(m_pVertices, sizeof(sMd3Triangle), meshHeader.numMeshFrames * meshHeader.numVertices, m_pFile);

			// Now that we have the data loaded into the Quake3 structures, let's convert them to
			// our data types like t3DModel and t3DObject.  That way the rest of our model loading
			// code will be mostly the same as the other model loading tutorials.
			convertDataStructures(pModel, meshHeader);

			// Free all the memory for this mesh since we just converted it to our structures
			delete [] m_pSkins;    
			delete [] m_pTexCoords;
			delete [] m_pTriangles;
			delete [] m_pVertices;   

			// Increase the offset into the file
			meshOffset += meshHeader.meshSize;
		}
	}

	void AnimatedMeshFactory::convertDataStructures(s3DAnimModel *pModel, sMd3MeshInfo meshHeader)
	{
		int i = 0;

		// This is function takes care of converting all of the Quake3 structures to our
		// structures that we have been using in all of our mode loading tutorials.  You
		// do not need this function if you are going to be using the Quake3 structures.
		// I just wanted to make it modular with the rest of the tutorials so you (me really) 
		// can make a engine out of them with an abstract base class.  Of course, each model
		// has some different data variables inside of the, depending on each format, but that
		// is perfect for some cool inheritance.  Just like in the .MD2 tutorials, we only
		// need to load in the texture coordinates and face information for one frame
		// of the animation (eventually in the next tutorial).  Where, the vertex information
		// needs to be loaded for every new frame, since it's vertex key frame animation 
		// used in .MD3 models.  Half-life models do NOT do this I believe.  It's just
		// pure bone/skeletal animation.  That will be a cool tutorial if the time ever comes.

		// Increase the number of objects (sub-objects) in our model since we are loading a new one
		pModel->numOfObjects++;
        
		// Create a empty object structure to store the object's info before we add it to our list
		
		//s3DObject currentMesh = {0};
		s3DObject currentMesh;

		// Copy the name of the object to our object structure
		strcpy(currentMesh.strName, meshHeader.strName);

		// Assign the vertex, texture coord and face count to our new structure
		currentMesh.numOfVerts   = meshHeader.numVertices;
		currentMesh.numTexVertex = meshHeader.numVertices;
		currentMesh.numOfFaces   = meshHeader.numTriangles;

		// Allocate memory for the vertices, texture coordinates and face data.
		// Notice that we multiply the number of vertices to be allocated by the
		// number of frames in the mesh.  This is because each frame of animation has a 
		// totally new set of vertices.  This will be used in the next animation tutorial.
		currentMesh.pVerts    = new Vector3 [currentMesh.numOfVerts * meshHeader.numMeshFrames];
		currentMesh.pTexVerts = new Vector2 [currentMesh.numOfVerts];
		currentMesh.pFaces    = new sFace [currentMesh.numOfFaces];

		// Go through all of the vertices and assign them over to our structure
		for (i=0; i < currentMesh.numOfVerts * meshHeader.numMeshFrames; i++)
		{
			// For some reason, the ratio 64 is what we need to divide the vertices by,
			// otherwise the model is gargantuanly huge!  If you use another ratio, it
			// screws up the model's body part position.  I found this out by just
			// testing different numbers, and I came up with 65.  I looked at someone
			// else's code and noticed they had 64, so I changed it to that.  I have never
			// read any documentation on the model format that justifies this number, but
			// I can't get it to work without it.  Who knows....  Maybe it's different for
			// 3D Studio Max files verses other software?  You be the judge.  I just work here.. :)
			currentMesh.pVerts[i].x =  m_pVertices[i].vertex[0] / 64.0f;
			currentMesh.pVerts[i].y =  m_pVertices[i].vertex[1] / 64.0f;
			currentMesh.pVerts[i].z =  m_pVertices[i].vertex[2] / 64.0f;
		}

		// Go through all of the uv coords and assign them over to our structure
		for (i=0; i < currentMesh.numTexVertex; i++)
		{
			// Since I changed the images to bitmaps, we need to negate the V ( or y) value.
			// This is because I believe that TARGA (.tga) files, which were originally used
			// with this model, have the pixels flipped horizontally.  If you use other image
			// files and your texture mapping is crazy looking, try deleting this negative.
			currentMesh.pTexVerts[i].x =  m_pTexCoords[i].textureCoord[0];
			currentMesh.pTexVerts[i].y = -m_pTexCoords[i].textureCoord[1];
		}

		// Go through all of the face data and assign it over to OUR structure
		for(i=0; i < currentMesh.numOfFaces; i++)
		{
			// Assign the vertex indices to our face data
			currentMesh.pFaces[i].vertIndex[0] = m_pTriangles[i].vertexIndices[0];
			currentMesh.pFaces[i].vertIndex[1] = m_pTriangles[i].vertexIndices[1];
			currentMesh.pFaces[i].vertIndex[2] = m_pTriangles[i].vertexIndices[2];

			// Assign the texture coord indices to our face data (same as the vertex indices)
			currentMesh.pFaces[i].coordIndex[0] = m_pTriangles[i].vertexIndices[0];
			currentMesh.pFaces[i].coordIndex[1] = m_pTriangles[i].vertexIndices[1];
			currentMesh.pFaces[i].coordIndex[2] = m_pTriangles[i].vertexIndices[2];
		}

		// Here we add the current object to our list object list
		pModel->pObject.push_back(currentMesh);
	}

	bool AnimatedMeshFactory::loadSkin(s3DAnimModel *pModel, const String& strSkin)
	{
		// Make sure valid data was passed in
		if(!pModel) return false;

		// This function is used to load a .skin file for the .md3 model associated
		// with it.  The .skin file stores the textures that need to go with each
		// object and subject in the .md3 files.  For instance, in our Lara Croft model,
		// her upper body model links to 2 texture; one for her body and the other for
		// her face/head.  The .skin file for the lara_upper.md3 model has 2 textures:
		//
		// u_torso,models/players/laracroft/default.bmp
		// u_head,models/players/laracroft/default_h.bmp
		//
		// Notice the first word, then a comma.  This word is the name of the object
		// in the .md3 file.  Remember, each .md3 file can have many sub-objects.
		// The next bit of text is the Quake3 path into the .pk3 file where the 
		// texture for that model is stored  Since we don't use the Quake3 path
		// because we aren't making Quake, I just grab the texture name at the
		// end of the string and disregard the rest.  of course, later this is
		// concatenated to the original MODEL_PATH that we passed into load our character.
		// So, for the torso object it's clear that default.bmp is assigned to it, where
		// as the head model with the pony tail, is assigned to default_h.bmp.  Simple enough.
		// What this function does is go through all the lines of the .skin file, and then
		// goes through all of the sub-objects in the .md3 file to see if their name is
		// in that line as a sub string.  We use our cool IsInString() function for that.
		// If it IS in that line, then we know that we need to grab it's texture file at
		// the end of the line.  I just parse backwards until I find the last '/' character,
		// then copy all the characters from that index + 1 on (I.E. "default.bmp").
		// Remember, it's important to note that I changed the texture files from .tga
		// files to .bmp files because that is what all of our tutorials use.  That way
		// you don't have to sift through tons of image loading code.  You can write or
		// get your own if you really want to use the .tga format.

		TCHAR strMessage[512];

		sprintf(strMessage, "Attempting to load skin: %s", strSkin.c_str() );
		FileLogger::getSingleton().logInfo("AnimatedMeshFactory", strMessage );

		// Open the skin file
		std::ifstream fin(strSkin.c_str() );

		// Make sure the file was opened
		if(fin.fail())
		{
			// Display the error message and return false
			//cerr << "Unable to load skin" << endl;
			//Quit(1);
			sprintf(strMessage, "Unable to load skin: %s", strSkin.c_str());
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
		}

		// These 2 variables are for reading in each line from the file, then storing
		// the index of where the bitmap name starts after the last '/' character.
		String strLine = "";
		int textureNameStart = 0;

		// Go through every line in the .skin file
		while(std::getline(fin, strLine))
		{
			// Loop through all of our objects to test if their name is in this line
			for(int i = 0; i < pModel->numOfObjects; i++)
			{
				// Check if the name of this object appears in this line from the skin file
				if( IsInString(strLine, pModel->pObject[i].strName) )           
				{           
					// To abstract the texture name, we loop through the string, starting
					// at the end of it until we find a '/' character, then save that index + 1.
					for(int j = strLine.length() - 1; j > 0; j--)
					{
						// If this character is a '/', save the index + 1
						if(strLine[j] == '/')
						{
							// Save the index + 1 (the start of the texture name) and break
							textureNameStart = j + 1;
							break;
						}   
					}

					// Create a local material info structure
					sMaterialInfo texture;

					// Copy the name of the file into our texture file name variable.
					// Notice that with string we can pass in the address of an index
					// and it will only pass in the characters from that point on. Cool huh?
					// So now the strFile name should hold something like ("bitmap_name.bmp")
					int size = strlen(strLine.c_str())-textureNameStart;
					strncpy(texture.strFile, &strLine[textureNameStart],size);
					texture.strFile[size] = '\0';

					sprintf(strMessage, "Logging texture: %s", texture.strFile);
					peon::FileLogger::getSingleton().logDebug("AnimatedMeshFactory", strMessage);
                
					// The tile or scale for the UV's is 1 to 1 
					texture.uTile = texture.vTile = 1;

					// Store the material ID for this object and set the texture boolean to true
					pModel->pObject[i].materialID = pModel->numOfMaterials;
					pModel->pObject[i].bHasTexture = true;

					// Here we increase the number of materials for the model
					pModel->numOfMaterials++;

					// Add the local material info structure to our model's material list
					pModel->pMaterials.push_back(texture);
				}
			}
		}

		// Close the file and return a success
		fin.close();
		return true;
	}

	bool AnimatedMeshFactory::loadShader(s3DAnimModel *pModel, const String& strShader)
	{
		// Make sure valid data was passed in
		if(!pModel) return false;

		// This function is used to load the .shader file that is associated with
		// the weapon model.  Instead of having a .skin file, weapons use a .shader file
		// because it has it's own scripting language to describe the behavior of the
		// weapon.  There is also many other factors like environment map and sphere map
		// textures, among other things.  Since I am not trying to replicate Quake, I
		// just care about the weapon's texture.  I went through each of the blocks
		// in the shader file and deleted everything except the texture name (of course
		// I changed the .tga files to .bmp for our purposes).  All this file now includes
		// is a texture name on each line.  No parsing needs to be done.  It is important
		// to keep in mind that the order of which these texture are stored in the file
		// is in the same order each sub-object is loaded in the .md3 file.  For instance,
		// the first texture name on the first line of the shader is the texture for
		// the main gun object that is loaded, the second texture is for the second sub-object
		// loaded, and so on. I just want to make sure that you understand that I hacked
		// up the .shader file so I didn't have to parse through a whole language.  This is
		// not a normal .shader file that we are loading.  I only kept the relevant parts.

		// Open the shader file
		std::ifstream fin(strShader.c_str());

		TCHAR strMessage[512];

		sprintf(strMessage, "Attempting to load shader: %s", strShader.c_str() );
		FileLogger::getSingleton().logInfo("AnimatedMeshFactory", strMessage );


		// Make sure the file was opened
		if(fin.fail())
		{
			// Display the error message and return false
			//cerr << "Unable to load shader" << endl;
			//Quit(1);
			sprintf(strMessage, "Unable to load shader: %s", strShader);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage );
			return false;

		}

		// These variables are used to read in a line at a time from the file, and also
		// to store the current line being read so that we can use that as an index for the 
		// textures, in relation to the index of the sub-object loaded in from the weapon model.
		String strLine = "";
		int currentIndex = 0;
    
		// Go through and read in every line of text from the file
		while(std::getline(fin, strLine))
		{
			// Create a local material info structure
			sMaterialInfo texture;

			// Copy the name of the file into our texture file name variable
			strcpy(texture.strFile, strLine.c_str());
                
			// The tile or scale for the UV's is 1 to 1 
			texture.uTile = texture.uTile = 1;

			// Store the material ID for this object and set the texture boolean to true
			pModel->pObject[currentIndex].materialID = pModel->numOfMaterials;
			pModel->pObject[currentIndex].bHasTexture = true;

			// Here we increase the number of materials for the model
			pModel->numOfMaterials++;

			// Add the local material info structure to our model's material list
			pModel->pMaterials.push_back(texture);

			// Here we increase the material index for the next texture (if any)
			currentIndex++;
		}

		// Close the file and return a success
		fin.close();
		return true;
	}


	void AnimatedMeshFactory::unloadData()
	{
		// Since we free all of the member variable arrays in the same function as
		// we allocate them, we don't need to do any other clean up other than
		// closing the file pointer, which could probably also be done in the same
		// function.  I left it here so you can add more of your cleanup if you add
		// to this class. 

		// Close the current file pointer
		fclose(m_pFile);                      
	}


	////////////////////////////////////////////////////////////////////////////////

	AnimatedMD3Mesh::AnimatedMD3Mesh()
	{
		// Here we initialize all our mesh structures for the character
		m_pHead = NULL;
		m_pUpper = NULL;
		m_pLower = NULL;
		m_pWeapon = NULL;
	}

	AnimatedMD3Mesh::~AnimatedMD3Mesh()
	{
		// Here we free all of the meshes in our model
		unloadModel(m_pHead);
		unloadModel(m_pUpper);
		unloadModel(m_pLower);
		unloadModel(m_pWeapon);

		SceneTexture* pObj;
		for(std::map<int, SceneTexture*>::iterator it = m_oTextures.begin();
			it != m_oTextures.end();
			it++)
		{
			pObj = (peon::SceneTexture*)it->second;
			
			PEON_DELETE( pObj );

		}

		m_oTextures.clear();

	}   

	void AnimatedMD3Mesh::unloadModel(s3DAnimModel *pModel)
	{
		// To free a model, we need to go through every sub-object and delete
		// their model data.  Since there is only one array of tags and links stored
		// for the model and all of it's objects, we need to only free the model's 
		// tags and links once.

		// Go through all the objects in the model
		for(int i = 0; i < pModel->numOfObjects; i++)
		{
			// Free the faces, normals, vertices, and texture coordinates.
			if(pModel->pObject[i].pFaces)       delete [] pModel->pObject[i].pFaces;
			if(pModel->pObject[i].pNormals)     delete [] pModel->pObject[i].pNormals;
			if(pModel->pObject[i].pVerts)       delete [] pModel->pObject[i].pVerts;
			if(pModel->pObject[i].pTexVerts)    delete [] pModel->pObject[i].pTexVerts;
		}

		// Free the tags associated with this model
		if(pModel->pTags)       delete [] pModel->pTags;

		// Free the links associated with this model (We use free because we used malloc())
		if(pModel->pLinks)      free(pModel->pLinks);


		pModel->pMaterials.clear();
	}
    
	bool AnimatedMD3Mesh::loadModel(const String& strPath, const String& strModel)
	{
		char strLowerModel[255];  // This stores the file name for the lower.md3 model
		char strUpperModel[255];  // This stores the file name for the upper.md3 model
		char strHeadModel[255];  // This stores the file name for the head.md3 model
		char strLowerSkin[255];  // This stores the file name for the lower.md3 skin
		char strUpperSkin[255];  // This stores the file name for the upper.md3 skin
		char strHeadSkin[255];  // This stores the file name for the head.md3 skin

		TCHAR strMessage[512];
		
		// This function is where all the character loading is taken care of.  We use
		// our CLoadMD3 class to load the 3 mesh and skins for the character. Since we
		// just have 1 name for the model, we add that to _lower.md3, _upper.md3 and _head.md3
		// to load the correct mesh files.

	
		// Store the correct files names for the .md3 and .skin file for each body part.
		// We concatinate this on top of the path name to be loaded from.
		sprintf(strLowerModel, "%s/%s_lower.md3", strPath.c_str(), strModel.c_str());
		sprintf(strUpperModel, "%s/%s_upper.md3", strPath.c_str(), strModel.c_str());
		sprintf(strHeadModel,  "%s/%s_head.md3",  strPath.c_str(), strModel.c_str());
    
		// Get the skin file names with their path
		sprintf(strLowerSkin, "%s/%s_lower.skin", strPath.c_str(), strModel.c_str());
		sprintf(strUpperSkin, "%s/%s_upper.skin", strPath.c_str(), strModel.c_str());
		sprintf(strHeadSkin,  "%s/%s_head.skin",  strPath.c_str(), strModel.c_str());
    
		// Next we want to load the character meshes.  The AnimatedMD3Mesh class has member
		// variables for the head, upper and lower body parts.  These are of type t3DModel.
		// Depending on which model we are loading, we pass in those structures to ImportMD3.
		// This returns a true of false to let us know that the file was loaded okay.  The
		// appropriate file name to load is passed in for the last parameter.

		// Load the head mesh (*_head.md3) and make sure it loaded properly
		m_pHead = AnimatedMeshFactory::getSingleton().loadMeshFromMD3(strHeadModel);
		if( NULL == m_pHead )
		{
			sprintf(strMessage, "Unable to load the HEAD model: %s", strHeadModel);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
		}

		// Load the upper mesh (*_head.md3) and make sure it loaded properly
		m_pUpper = AnimatedMeshFactory::getSingleton().loadMeshFromMD3(strUpperModel);
		if(NULL == m_pUpper)    
		{
			sprintf(strMessage, "Unable to load the UPPER model: %s", strUpperModel);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
	
		}

		// Load the lower mesh (*_lower.md3) and make sure it loaded properly
		m_pLower = AnimatedMeshFactory::getSingleton().loadMeshFromMD3(strLowerModel);
		if(NULL == m_pLower)
		{
			sprintf(strMessage, "Unable to load the LOWER model: %s", strLowerModel);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
	
		}

		// Load the lower skin (*_upper.skin) and make sure it loaded properly
		if(!AnimatedMeshFactory::getSingleton().loadSkin(m_pLower, strLowerSkin))
		{
			sprintf(strMessage, "Unable to load the LOWER skin: %s", strLowerSkin);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
	
		}

		// Load the upper skin (*_upper.skin) and make sure it loaded properly
		if(!AnimatedMeshFactory::getSingleton().loadSkin(m_pUpper, strUpperSkin))
		{
			sprintf(strMessage, "Unable to load the UPPER skin: %s", strUpperSkin);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
	
		}

		// Load the head skin (*_head.skin) and make sure it loaded properly
		if(!AnimatedMeshFactory::getSingleton().loadSkin(m_pHead, strHeadSkin))
		{
			sprintf(strMessage, "Unable to load the HEAD skin: %s", strHeadSkin);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage);
			return false;
	
		}

		// Now that the model data is loaded, load the texture data.
		loadModelTextures(m_pLower, strPath);
		loadModelTextures(m_pUpper, strPath);
		loadModelTextures(m_pHead,  strPath);

		//With the MD3 format, the 3 model pieces are linked together in a tree fashion. The 
		//lower body is the top of the tree, with the upper and head models children. That
		//way, no matter where our feet go, the upper and head follow along 

		// Link the lower body to the upper body using the tag "tag_torso"
		linkModel(m_pLower, m_pUpper, "tag_torso");

		// Link the upper body to the head using the tag "tag_head"
		linkModel(m_pUpper, m_pHead, "tag_head");

		return true;
	}

	bool AnimatedMD3Mesh::loadWeapon(const String& strPath, const String& strModel)
	{
		char strWeaponModel[255]  = {0};    // This stores the file name for the weapon model
		char strWeaponShader[255] = {0};    // This stores the file name for the weapon shader.
	
	
		TCHAR strMessage[512];

		// Concatenate the path and model name together
		sprintf(strWeaponModel, "%s/%s.md3", strPath.c_str(), strModel.c_str());
    
		// Next we want to load the weapon mesh.  The AnimatedMD3Mesh class has member
		// variables for the weapon model and all it's sub-objects.  This is of type t3DModel.
		// We pass in a reference to this model in to ImportMD3 to save the data read.
		// This returns a true of false to let us know that the weapon was loaded okay.  The
		// appropriate file name to load is passed in for the last parameter.

		// Load the weapon mesh (*.md3) and make sure it loaded properly
		m_pWeapon = AnimatedMeshFactory::getSingleton().loadMeshFromMD3(strWeaponModel);
		if( NULL == m_pWeapon )
		{
			sprintf(strMessage, "Unable to load the weapon mesh: %s", strWeaponModel);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage );
			return false;

		}

		// create the path to get the .shader extension 
		sprintf(strWeaponShader, "%s/%s.shader", strPath.c_str(), strModel.c_str());

		// Load our textures associated with the gun from the weapon shader file
		if(!AnimatedMeshFactory::getSingleton().loadShader(m_pWeapon, strWeaponShader))
		{
			sprintf(strMessage, "Unable to load the SHADER file: %s", strWeaponShader);
			FileLogger::getSingleton().logError("AnimatedMeshFactory", strMessage );
			return false;
		}

		// We should have the textures needed for each weapon part loaded from the weapon's
		// shader, so let's load them in the given path.
		loadModelTextures(m_pWeapon, strPath.c_str());

		//create another link in the model, however this time we link the weapon to the
		//model's hand. That way, wherever the hand goes, so does el-weapon.

		// Link the weapon to the model's hand that has the weapon tag
		linkModel(m_pUpper, m_pWeapon, "tag_weapon");
        
		
		return true;
	}

	void AnimatedMD3Mesh::loadModelTextures(s3DAnimModel *pModel, const String& strPath)
	{
		TCHAR strMessage[512];

		sprintf(strMessage, "loadModelTextures from %s, with %d number of mats", strPath.c_str(), pModel->numOfMaterials);
		FileLogger::getSingleton().logInfo( "AnimatedMesh", strMessage );

		// Go through all the materials that are assigned to this model
		for(int i = 0; i < pModel->numOfMaterials; i++)
		{
			// Check to see if there is a file name to load in this material
			sprintf( strMessage, "Attempting to load texture for material: %s", pModel->pMaterials[i].strFile );
			FileLogger::getSingleton().logInfo( "Animated3DMesh", strMessage );
			if(strlen(pModel->pMaterials[i].strFile) > 0)
			{
            
				char strFullPath[255];

				// Add the file name and path together so we can load the texture
				sprintf(strFullPath, "%s\\%s", strPath.c_str(), pModel->pMaterials[i].strFile);

		
				SceneTexture* pTex = new SceneTexture();

				sprintf(strMessage, "Attempting to load texture: %s", strFullPath);
				FileLogger::getSingleton().logDebug( "AnimatedMeshFactory", strMessage );
				
				pTex = EngineCore::getSingleton().getRenderer()->loadTexture(strFullPath, true, true, false );
				if(NULL == pTex)
				{
					sprintf(strMessage, "Error loading texture: %s", strFullPath);
					FileLogger::getSingleton().logError( "AnimatedMeshFactory", strMessage );
					return;
				} 

				int key = m_oTextures.size();
				
				m_oTextures.insert(std::make_pair(key, pTex));                           

				// Set the texture ID for this material by getting the current loaded texture count
				pModel->pMaterials[i].textureId = key;

				// Now we increase the loaded texture count by adding the texture name to our
				// list of texture names.  Remember, this is used so we can check if a texture
				// is already loaded before we load 2 of the same textures.  Make sure you
				// understand what an STL vector list is.  We have a tutorial on it if you don't.
				//strTextures.push_back(pModel->pMaterials[i].strFile);
			}
		}
	}

	void  AnimatedMD3Mesh::linkModel(s3DAnimModel *pModel, s3DAnimModel *pLink, const String& strTagName)
	{
		// Make sure we have a valid model, link and tag name, otherwise quit this function
		if(!pModel || !pLink) return;

		// Go through all of our tags and find which tag contains the strTagName, and
		// provide a link where necessary
		for(int i = 0; i < pModel->numOfTags; i++)
		{
			//did we find the desired tag?
			if( !strcmp(pModel->pTags[i].strName, strTagName.c_str()) )
			{
				// Link the model's link index to the link (or model/mesh) and return
				pModel->pLinks[i] = pLink;
				return;
			}
		}
	}

	void AnimatedMD3Mesh::renderModel()
	{
		//the model needs to be rotated to compensate for the z direction
		glRotatef(-90, 1, 0, 0);

		// render the first link, which is the lower body.  Internally, this will then go
		// through the models attached to this model and drawn them.
		renderLink(m_pLower);
	}

	void AnimatedMD3Mesh::renderLink(s3DAnimModel *pModel)
	{
		
		renderModel(pModel);

		// Now we need to go through all of this models tags and draw them.
		for(int i = 0; i < pModel->numOfTags; i++)
		{
			// Get the current link from the models array of links
			s3DAnimModel *pLink = pModel->pLinks[i];

			// If this link has a valid address, render
			if(pLink)
			{           
				//get the translation
				Vector3 vPosition = pModel->pTags[i].vPosition;

				// Start a new matrix scope
				glPushMatrix();
            
					// Translate the new model to be drawn to it's position
					glTranslatef(vPosition.x, vPosition.y, vPosition.z);

					renderLink(pLink);

				// End the current matrix scope
				glPopMatrix();
			}
		}

	}

	void AnimatedMD3Mesh::renderModel(s3DAnimModel *pModel)
	{
		// This function actually does the rendering to OpenGL.  If you have checked out
		// our other file loading tutorials, it looks pretty much the same as those.  I
		// left out the normals though.  You can go to any other loading and copy the code
		// from those.  Usually the Quake models creating the lighting effect in their textures
		// anyway.  

		// Make sure we have valid objects just in case. (size() is in the STL vector class)
		if(pModel->pObject.size() <= 0) return;

		// Go through all of the objects stored in this model
		for(int i = 0; i < pModel->numOfObjects; i++)
		{
			// Get the current object that we are displaying
			s3DObject *pObj = &pModel->pObject[i];

			// If the object has a texture assigned to it, let's bind it to the model.
			// This isn't really necessary since all models have textures, but I left this
			// in here to keep to the same standard as the rest of the model loaders.
			if(pObj->bHasTexture)
			{
				// Turn on texture mapping
				glEnable(GL_TEXTURE_2D);

				// Grab the texture index from the materialID index into our material list
				int textureID = pModel->pMaterials[pObj->materialID].textureId;

				// Bind the texture index that we got from the material textureID
				setTexture( textureID );

			}
			else
			{
				// Turn off texture mapping
				glDisable(GL_TEXTURE_2D);
			}

			// Start drawing our model triangles
			glBegin(GL_TRIANGLES);

				// Go through all of the faces (polygons) of the object and draw them
				for(int j = 0; j < pObj->numOfFaces; j++)
				{
					// Go through each vertex of the triangle and draw it.
					for(int whichVertex = 0; whichVertex < 3; whichVertex++)
					{
						// Get the index for the current point in the face list
						int index = pObj->pFaces[j].vertIndex[whichVertex];
                                
						// Make sure there is texture coordinates for this (%99.9 likelyhood)
						if(pObj->pTexVerts) 
						{
							// Assign the texture coordinate to this vertex
							glTexCoord2f(pObj->pTexVerts[ index ].x, 
										 pObj->pTexVerts[ index ].y);
						}
                    
						// Get the vertex that we are dealing with.  This code will change
						// a bunch when we doing our key frame animation in the next .MD3 tutorial.
						Vector3 vPoint1 = pObj->pVerts[ index ];

						// Render the current vertex
						glVertex3f(vPoint1.x, vPoint1.y, vPoint1.z);
					}
				}

			// Stop drawing polygons
			glEnd();
		}
	}

	void AnimatedMD3Mesh::setTexture( int key )
	{
		SceneTexture* pTex = NULL;

		std::map<int, SceneTexture*>::iterator it;
		it = m_oTextures.find(key);
		if (it == m_oTextures.end())
		{
			FileLogger::getSingleton().logError("AnimatedMD3Mesh", "Couldn't find texture handle");
			return;
		}
		else
		{
			//m_pCurrentState = it->second;
			pTex = (SceneTexture*)it->second;

			glBindTexture(GL_TEXTURE_2D, pTex->getTex() );
		}


	}



}

