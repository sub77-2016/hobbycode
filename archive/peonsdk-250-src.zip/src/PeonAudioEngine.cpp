
#include "PeonFileLogger.h"
#include "PeonIniConfigReader.h"
#include "PeonAudioEngine.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{

	SoundFxNode::SoundFxNode()
	{
		m_key = 0;
		m_pData = NULL;
		m_channel = -1;
	}

	SoundFxNode::~SoundFxNode()
	{

	}

	MusicNode::MusicNode()
	{
		m_key = 0;
		m_pData = NULL;
	}

	MusicNode::~MusicNode()
	{

	}


	template<> AudioEngine* ISingleton<AudioEngine>::ms_Singleton = 0;

	AudioEngine* AudioEngine::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	AudioEngine& AudioEngine::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	AudioEngine::AudioEngine()
	{

#if defined( PEON_USE_OPENAL_ )
		m_pALDevice = NULL;
		m_pALContext = NULL;
#endif

		m_bEnableSound = true;
		m_bEnableMusic = true;

		m_bAudioSupported = true;
		m_bIsEAXSupported = false;
		

	}

	AudioEngine::~AudioEngine()
	{
		unloadEngine();
	}

	bool AudioEngine::loadEngine( IniConfigReader* pConfig )
	{
		int audio_rate = 22050;
		Uint16 audio_format = AUDIO_S16; /* 16-bit stereo */
		int audio_channels = 2;
		int audio_buffers = 4096;


		
		// This is where we open up our audio device.
		// Note that this section is for loading up SDL_Mixer for
		// MIDI support
		if(Mix_OpenAudio(audio_rate, audio_format, audio_channels, audio_buffers))
		{
			FileLogger::getSingleton().logError("AudioEngine", "Error loading SDL_Mixer audio device");
			m_bAudioSupported = false;
			return false;
		}

#if defined( PEON_USE_OPENAL_ )

		//alutInit(NULL, 0);
		alGetError(); //clear error code
	
		//old syntax from OpenAL 1.0
		//m_pALDevice = alcOpenDevice((ALubyte*)"DirectSound3D");
		//using new syntax for OpenAL 1.1
		m_pALDevice = alcOpenDevice(NULL);
		if(m_pALDevice == NULL)
		{
			FileLogger::getSingleton().logError("AudioEngine", "Error initializing OpenAL : DirectSound3D Context");
			m_bAudioSupported = false;
			return false;
		}

		//Create a valid context
		m_pALContext = alcCreateContext(m_pALDevice,NULL);

		//make it the current active context
		alcMakeContextCurrent(m_pALContext);

		//m_bIsEAXSupported = alIsExtensionPresent("EAX2.0");


		//position of the listener
		ALfloat ListenerPos[] = { 0.0f, 0.0f, 0.0f };

		// Velocity of the listener.
		ALfloat ListenerVel[] = { 0.0f, 0.0f, 0.0f };

		//Orientation of the listener. (first 3 elements are "at", second 3 are "up")
		ALfloat ListenerOri[] = { 0.0f, 0.0f, -1.0f,  0.0f, 1.0f, 0.0f };

		alListenerfv(AL_POSITION,    ListenerPos);
		alListenerfv(AL_VELOCITY,    ListenerVel);
		alListenerfv(AL_ORIENTATION, ListenerOri);
#endif


		return true;
	}

	void AudioEngine::unloadEngine()
	{
		m_oSoundFxList.clear();

		m_oMusicList.clear();

		Mix_HaltMusic();

		Mix_CloseAudio();

#if defined( PEON_USE_OPENAL_ )

		//Get active context
		m_pALContext = alcGetCurrentContext();

		//Get device for active context
		m_pALDevice=alcGetContextsDevice(m_pALContext);

		//Disable context
		alcMakeContextCurrent(NULL);

		//Release context(s)
		alcDestroyContext(m_pALContext);

		//Close device
		alcCloseDevice(m_pALDevice);

		alutExit();
#endif


	}

	int AudioEngine::loadMusic( int key, const String& strFilename )
	{
		MusicNode* pNode = new MusicNode();
		int status = -1;

		/* Actually loads up the music */
		pNode->m_pData = Mix_LoadMUS(strFilename.c_str());
		
		if( pNode->m_pData != NULL )
		{
			status = 1;
			pNode->m_key = key;
			m_oMusicList.push_back( pNode );
		}

		
		return status;
	}

	int AudioEngine::loadSoundFx(int key, const String& strFilename )
	{
		SoundFxNode* pNode = new SoundFxNode();
		int status = -1;

		pNode->m_pData = Mix_LoadWAV( strFilename.c_str() );

		if( pNode->m_pData != NULL )
		{

			status = 1;
			pNode->m_key = key;
			m_oSoundFxList.push_back( pNode );
		}


		return status;

	}

	int AudioEngine::startMusic(int key, bool loop /* = true */)
	{
		int found = -1;
		int counter = 0;
		for( boost::ptr_list<MusicNode>::iterator i = m_oMusicList.begin();
			i != m_oMusicList.end(); ++i)
		{
			if( key == i->m_key )
			{
				if( loop )
				{
					counter = -1;
				}

				Mix_PlayMusic( i->m_pData, counter );

				break;
			}
		}

		return found;
	}

	int AudioEngine::startSoundFx(int key, bool loop /* = false */ )
	{
		int found = -1;
		int counter = 0;
		for( boost::ptr_list<SoundFxNode>::iterator i = m_oSoundFxList.begin();
			i != m_oSoundFxList.end(); ++i)
		{
			if( key == i->m_key )
			{
				if(loop)
				{
					counter = -1;
				}

				i->m_channel = Mix_PlayChannel( -1, i->m_pData, counter );

				break;

			}
		}

		return found;

	}

	int AudioEngine::stopMusic(int key)
	{
		int found = -1;
		for( boost::ptr_list<MusicNode>::iterator i = m_oMusicList.begin();
			i != m_oMusicList.end(); ++i)
		{
			if( key == i->m_key )
			{

				Mix_HaltMusic();
				break;

			}
		}

		return found;
	}

	int AudioEngine::stopSoundFx(int key)
	{
		int found = -1;
		for( boost::ptr_list<SoundFxNode>::iterator i = m_oSoundFxList.begin();
			i != m_oSoundFxList.end(); ++i)
		{
			if( key == i->m_key )
			{
				Mix_HaltChannel( i->m_channel );
				i->m_channel = -1;
				break;

			}
		}

		return found;
	}

#if defined( PEON_USE_OPENAL_ )

	bool AudioEngine::loadAudioNode(const String& strWAV, AudioNode* pNode)
	{
		ALenum format;
		ALsizei size;
		ALvoid* data;
		ALsizei freq;
		ALboolean loop;
	
		char            pcmout[OGG_BUFFER_SIZE];    // Local fixed size array
		int             endian = 0;    // 0 for little endian, and 1 for big endian
		int             iBitStream;
		long            lBytes;

		FILE*           oggFile;       // file handle
		OggVorbis_File  oggStream;     // stream handle
		vorbis_info*    vorbisInfo;    // some formatting data
		vorbis_comment* vorbisComment; // user comments

		TCHAR strOutput[256];

		alGenSources(1, &pNode->sound_source );

		int pos = (int)strWAV.find( ".ogg", 0 );
		if ( pos != String::npos )
		{
			sprintf(strOutput, "Loading OGG data from: %s", strWAV.c_str());
			FileLogger::getSingleton().logInfo("AudioEngine", strOutput);

			//we're loading an OGG file!!! 
			if(!(oggFile = fopen(strWAV.c_str(), "rb")))
			{
				sprintf(strOutput, "Error loading up ogg resource: %s", strWAV.c_str());
				FileLogger::getSingleton().logError("AudioEngine", strOutput);
				return false;
			}


			if( ov_open(oggFile, &oggStream, NULL, 0) < 0)
			{
				fclose(oggFile);

				FileLogger::getSingleton().logError("AudioEngine", "Error loading ogg resource bit stream");

				return false;
			}

			

			vorbisInfo = ov_info(&oggStream, -1);
			vorbisComment = ov_comment(&oggStream, -1);

			if(NULL == vorbisInfo)
			{
				OutputDebugString("NULL vorbisInfo\n");

			}

		

			alSourcef(pNode->sound_source, AL_ROLLOFF_FACTOR,  0.0f    );
			alSourcei(pNode->sound_source, AL_SOURCE_RELATIVE, AL_TRUE );

		

			do
			{
				// Read up to a buffer's worth of decoded sound data
				lBytes = ov_read(&oggStream, pcmout, sizeof(pcmout), endian, 2, 1, &iBitStream);
				// Append to end of buffer
				pNode->ogg_sound_data.insert(pNode->ogg_sound_data.end(), pcmout, pcmout + lBytes);

			} while (lBytes > 0);

			
			pNode->sound_ogg = true;

			ov_clear( &oggStream );

			alGenBuffers( 1, &pNode->ogg_sound_buffer );

			if(vorbisInfo->channels == 1)
			{
				format = AL_FORMAT_MONO16;
			}
			else
			{
				format = AL_FORMAT_STEREO16;
			}


			// The frequency of the sampling rate
			freq = vorbisInfo->rate;	
			

			sprintf(strOutput,"%s Bitstream is %d channel, %ldHz", strWAV.c_str(), vorbisInfo->channels,vorbisInfo->rate);
    
			FileLogger::getSingleton().logInfo("AudioEngine", strOutput);

			//upload OGG data to sound device
			// Upload sound data to buffer
			alBufferData(pNode->ogg_sound_buffer, 
				format, 
				&pNode->ogg_sound_data[0], 
				static_cast < ALsizei > (pNode->ogg_sound_data.size()), 
				freq);

			


		}
		else
		{

			FileLogger::getSingleton().logInfo("AudioEngine", "Loading WAV data");

			alGenBuffers( 1, &pNode->wav_sound_buffer );

			//we're loading a simple ol' WAV file
			alutLoadWAVFile((char*)strWAV.c_str(), &format, &data, &size, &freq, &loop);
			//alBufferData(m_uAudioBuffers[m_iCurrentSlot], format, data, size, freq);
			alBufferData( pNode->wav_sound_buffer, format, data, size, freq );

			alutUnloadWAV(format, data, size, freq);

			pNode->sound_ogg = false;
		}

		sprintf(strOutput, "Loaded up audio data from resource: %s", strWAV.c_str());
		FileLogger::getSingleton().logInfo("AudioEngine", strOutput);
				
		
		
		return true;
	}

	void AudioEngine::setAudioNode(AudioNode* pNode)
	{
		ALuint source = pNode->sound_source;

		if( pNode->sound_ogg )
		{
			
			alSourcei( source, AL_BUFFER, pNode->ogg_sound_buffer );

		}else
		{
		
			alSourcei (source, AL_BUFFER,   pNode->wav_sound_buffer );

		}

		alSourcef (source, AL_PITCH,    pNode->sound_pitch    );
		alSourcef (source, AL_GAIN,     pNode->sound_gain     );
		alSourcefv(source, AL_POSITION, pNode->sound_position );
		alSourcefv(source, AL_VELOCITY, pNode->sound_velocity );

		if( pNode->sound_loop )
			alSourcei (source, AL_LOOPING, AL_TRUE );
		else
			alSourcei (source, AL_LOOPING, AL_FALSE );

	}

	void AudioEngine::playAudioNode( AudioNode* pNode )
	{
		// Begin the source playing.
		alSourcePlay( pNode->sound_source );

	}

	void AudioEngine::stopAudioNode( AudioNode* pNode )
	{
		alSourceStop( pNode->sound_source );
	}

#endif

}

