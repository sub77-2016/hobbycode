
#include "PeonBillboard.h"

namespace peon
{
	Billboard::Billboard()
	{
	}

	Billboard::~Billboard()
	{

	}
}