

#include "PeonBillboardAnimation.h"
#include "PeonEngineCore.h"

namespace peon
{
	AnimatedFrame::AnimatedFrame()
	{
		m_pTexture = NULL;
		m_fTime = 0.0f;
	}

	AnimatedFrame::~AnimatedFrame()
	{
	
		PEON_DELETE( m_pTexture );
	}



	BillboardAnimation::BillboardAnimation()
	{
		m_bIsRunning = false;
		m_fTotalTime = 0.0f;
	};

	BillboardAnimation::~BillboardAnimation()
	{
	
		unloadFrames();
	}

	bool BillboardAnimation::loadFrame(const peon::String& strFilename, float fTime)
	{
		AnimatedFrame *pFrame = new AnimatedFrame();
  
		// create a texture for this frame
		pFrame->m_pTexture = peon::EngineCore::getSingleton().getRenderer()->loadTexture(strFilename, true, false, false);

		
		// add to vector
		pFrame->m_fTime = fTime;

		m_oFrames.push_back(pFrame);

		return true;

	}

	void BillboardAnimation::unloadFrames()
	{
		for (std::vector<AnimatedFrame *>::iterator i = m_oFrames.begin(); 
			i != m_oFrames.end(); ++i) 
		{
			delete *i;
		}
	
		m_oFrames.clear();
	}

	void BillboardAnimation::updateAnim(float elapsed_time)
	{
		if(m_bIsRunning)
		{
			m_fTotalTime += elapsed_time;
			
			//just make sure that our current frame is valid. Meaning that
			//our time length for our total animation hasn't elapsed.	
			if(getCurrentFrame() > (int)m_oFrames.size())
			{
				stopAnim();
			}
		}
		
	}

	void BillboardAnimation::startAnim()
	{
		m_bIsRunning = true;
		m_fTotalTime = 0.0f;
	}

	void BillboardAnimation::stopAnim()
	{
		m_bIsRunning = false;
		m_fTotalTime = 0.0f;
	}
	
	int BillboardAnimation::getCurrentFrame()
	{
		int iCurFrame = 0; float fTimeCount = 0.0f;
		for (std::vector<AnimatedFrame *>::iterator i = m_oFrames.begin(); i != m_oFrames.end(); ++i)
		{
			fTimeCount += (*i)->m_fTime;
			if (m_fTotalTime <= fTimeCount) break;
			iCurFrame++;
		}
		return(iCurFrame);
	}

	void BillboardAnimation::renderAnim()
	{
		if(!m_bIsRunning)
			return;

		int iCurFrame = getCurrentFrame();

		if (iCurFrame >= (int)m_oFrames.size()) return;

		AnimatedFrame *f = m_oFrames[iCurFrame];

		glPushMatrix();
		glLoadIdentity();
		glTranslatef( m_vecPos.x, m_vecPos.y, m_vecPos.z );
		glColor4f( 1.0f, 1.0f, 1.0f, 0.9f );

		glEnable(GL_TEXTURE_2D);

		glBindTexture( GL_TEXTURE_2D, f->m_pTexture->getTex() );

		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glBegin( GL_QUADS );
		{
			glNormal3f( 0.0f, 0.0f, 1.0f );


			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.0f, -1.0f, 0.0f);

			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.0f, -1.0f, 0.0f);

			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.0f, 1.0f, 0.0f);

			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.0f, 1.0f, 0.0f);

		}
		glEnd();

		glPopMatrix();

		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);


	}


}