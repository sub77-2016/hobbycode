
#include "PeonBoundingSphere.h"

namespace peon
{
	BoundingSphere::BoundingSphere()
	{
	}

	BoundingSphere::~BoundingSphere()
	{

	}

}

