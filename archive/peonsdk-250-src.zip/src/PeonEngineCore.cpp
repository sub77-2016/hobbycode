
#include "PeonFileLogger.h"
#include "PeonIniConfigReader.h"
#include "PeonSceneRenderer.h"
#include "PeonIApplication.h"
#include "PeonEngineCore.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{
	//-----------------------------------------------------------------------
	template<> EngineCore* ISingleton<EngineCore>::ms_Singleton = 0;

	EngineCore* EngineCore::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	EngineCore& EngineCore::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	EngineCore::EngineCore()
	{
		m_pApplication = NULL;
		m_pConfig      = NULL;
		m_pVideoDevice = NULL;
		m_fps		   = 0.0f;

		
	}

	EngineCore::~EngineCore()
	{
		
	}

	bool EngineCore::loadEngine(const String& strWindowTitle, 
								const String& strIniConfig,
								const String strIgnore )
	{

	//Need to test in other compilers, but for now let's only enable the 
	//CrtSetDbgFlag stuff if we are using a Visual Studio product.
	#if defined( _MSC_VER )
		
	#if defined(DEBUG) | defined(_DEBUG)
		_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	#endif

	#endif

	
		new FileLogger();

		if(!FileLogger::getSingleton().openLogStream("PeonSDK-output.log.txt"))
		{
			unloadEngine();
			return false;
		}

		//just for kicks, record our Peon SDK version. Right now we don't ever
		//need to worry about version specific things, but I'm leaving the door
		//open just in case...
		char strOutput[256];
		sprintf(strOutput, "Using Peon SDK Version: %s", strIgnore.c_str() );
		FileLogger::getSingleton().logInfo("EngineCore", strOutput);

		//start up SDL
		if(SDL_Init( SDL_INIT_EVERYTHING ) < 0 || !SDL_GetVideoInfo() )
		{
			FileLogger::getSingleton().logFatal("EngineCore", "Failed to load SDL. Exiting");
			unloadEngine();
			return false;
		}
		FileLogger::getSingleton().logInfo("EngineCore", "SDL created");


		m_pConfig = new IniConfigReader( strIniConfig );
		if(NULL == m_pConfig)
		{
			FileLogger::getSingleton().logFatal("EngineCore", "Failed to load INI file. Exiting");
			unloadEngine();
			return false;
		}
		FileLogger::getSingleton().logInfo("EngineCore", "IniConfigReader created");


		//create an initial window
		SDL_SetVideoMode( 800, 600, SDL_GetVideoInfo()->vfmt->BitsPerPixel, SDL_RESIZABLE );


		SDL_WM_SetCaption(strWindowTitle.c_str(), strWindowTitle.c_str());	
	
		m_pVideoDevice = new SceneRenderer();
		if(!m_pVideoDevice->loadDevice( m_pConfig ))
		{
			FileLogger::getSingleton().logFatal("EngineCore", "Failed to load graphics renderer. Exiting");
			unloadEngine();
			return false;
		}

		FileLogger::getSingleton().logInfo("EngineCore", "SceneRenderer created");	

		new InputEngine();
		if(!InputEngine::getSingleton().loadEngine( m_pConfig ))
		{

			FileLogger::getSingleton().logFatal("EngineCore", "Failed to initialize input device(s). Exiting");
			unloadEngine();
			return false;

		}
		FileLogger::getSingleton().logInfo("EngineCore", "InputEngine created");


		new MathUnit();
		FileLogger::getSingleton().logInfo("EngineCore", "MathUnit created");


		//Initialize the AudioEngine instance
		new AudioEngine();
		if(!AudioEngine::getSingleton().loadEngine( m_pConfig ))
		{
			FileLogger::getSingleton().logInfo("EngineCore", "Failed to initialize sound device. Disabling audio support");
		}

		FileLogger::getSingleton().logInfo("EngineCore", "AudioEngine created");
		
		
		return true;
	}

	void EngineCore::unloadEngine()
	{
		

		FileLogger::getSingleton().logInfo("EngineCore", "Unloading the Peon objects");

		if( m_pApplication )
		{
			m_pApplication->onUnloadWorld();
			m_pApplication->unloadStates();
	
			//delete m_pApplication;
			FileLogger::getSingleton().logInfo("EngineCore", "IApplication destroyed");


		}


		delete MathUnit::getSingletonPtr();
		FileLogger::getSingleton().logInfo("EngineCore", "MathUnit destroyed");
	
		
		//cleanup the AudioEngine instance
		delete AudioEngine::getSingletonPtr();
		FileLogger::getSingleton().logInfo("EngineCore", "AudioEngine destroyed");

		
		delete InputEngine::getSingletonPtr();
		FileLogger::getSingleton().logInfo("EngineCore", "InputEngine destroyed");

		
		PEON_DELETE( m_pVideoDevice );
		FileLogger::getSingleton().logInfo("EngineCore", "SceneRenderer destroyed");


		PEON_DELETE( m_pConfig );
		FileLogger::getSingleton().logInfo("EngineCore", "IniConfigReader destroyed");


		SDL_Quit();
		FileLogger::getSingleton().logInfo("EngineCore", "SDL destroyed");


		delete FileLogger::getSingletonPtr();

	}

	int EngineCore::runEngine()
	{
		m_oTimer.start();

		bool done = false;                                     
		SDL_Event event;

		while(! done)                         
		{							
			while( SDL_PollEvent(&event) )                    
			{
				switch ( event.type )                         
				{

					case SDL_KEYDOWN:
					case SDL_KEYUP:

						if(m_pApplication) 
							m_pApplication->onKeyEvent(&event.key);
                    break;

					case SDL_MOUSEMOTION:
					case SDL_MOUSEBUTTONDOWN:
						if(m_pApplication)
							m_pApplication->onMouseEvent( &event );
					break;

                    

				case SDL_QUIT :                                         
					done = true;                                        
					break;               

				default:                                    
					break;                                  
				} 
			}

			float elapsed_time = m_oTimer.getElapsedTime();

			if(m_pApplication)
			{
			    m_pApplication->onUpdateWorld( elapsed_time );

				if(m_pVideoDevice->clearDevice())
				{

					m_pApplication->onRenderWorld();
					
					m_pVideoDevice->flipDevice();

					updateFPS();

				}
				
			}	

		} 

		m_oTimer.stop();

		unloadEngine();

		return 0;
	}

	bool EngineCore::setApplication( IApplication* pApp )
	{
		if( NULL == pApp )
			return false;

		if(!pApp->onLoadWorld())
		{
			FileLogger::getSingleton().logError("EngineCore", "Error on IApplication::onLoad()");

			return false;
		}
		
		m_pApplication = pApp;

		return true;
	}

	void EngineCore::updateFPS()
	{
		static float fLastTime = 0.0f;
		static DWORD dwFrames  = 0L;
		float fTime = m_oTimer.getAbsoluteTime();
		
		++dwFrames;

		// Update the scene stats once per second
		if( fTime - fLastTime > 1.0f )
		{
			m_fps    = dwFrames / (fTime - fLastTime);
			fLastTime = fTime;
			dwFrames  = 0L;
		}

	}

	void EngineCore::sendQuitMsg()
	{

		// Post a SDL_QUIT event
		SDL_Event event;
		event.type = SDL_QUIT;
		SDL_PushEvent(&event);


	}
}

