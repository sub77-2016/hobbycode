
#include "PeonIActor.h"

namespace peon
{
	IActor::IActor()
	{
	}

	IActor::~IActor()
	{
	}
}