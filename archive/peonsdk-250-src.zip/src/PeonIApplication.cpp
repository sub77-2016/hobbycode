
#include "PeonFileLogger.h"
#include "PeonIApplication.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{

	IApplication::IApplication()
	{
		m_pCurrentState = NULL;
	}

	IApplication::~IApplication()
	{
	
	}

	bool IApplication::loadState(int key, IApplicationState* pState)
	{

		if(!pState->onLoad())
		{
			return false;
		}

		pState->setID( key );

		m_oStates.insert(std::make_pair(key, pState));

		return true;
	}

	void IApplication::setCurrentState( int key )
	{

		std::map<int, IApplicationState*>::iterator it;
		it = m_oStates.find(key);
		if (it == m_oStates.end())
		{
			FileLogger::getSingleton().logError("IApplication", "Couldn't find state");
			return;
		}
		else
		{
			m_pCurrentState = (IApplicationState*)it->second;

		}
	}

	void IApplication::unloadStates()
	{
		IApplicationState* pState;
		for(std::map<int, IApplicationState*>::iterator it = m_oStates.begin();
			it != m_oStates.end();
			it++)
		{
			pState = (IApplicationState*)it->second;
			if(pState)
			{
				pState->onUnload();
				delete pState;
			}

		}

		//clear the map
		m_oStates.clear();

	}

	int IApplication::getCurrentStateID()
	{ 
		if(NULL == m_pCurrentState )
			return -1;

		return m_pCurrentState->getID(); 
		
	}
}