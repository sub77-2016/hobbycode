
#include "PeonIniConfigReader.h"

namespace peon
{

	IniConfigReader::IniConfigReader(const String& strFile)
	{
		//TCHAR strOutput[MAX_PATH];
		//sprintf(strOutput, "attempting to load ini: %s\n", strFile.c_str());
		//OutputDebugString(strOutput);
		m_strFileName = strFile;
	
	}

	IniConfigReader::~IniConfigReader()
	{

	}

	DWORD IniConfigReader::getString(const String strSection, const String strKey, const String strDefault, String& strReturn)
	{

		DWORD dwResult = 0;
		TCHAR strTemp[MAX_PATH];
		ZeroMemory( &strTemp, sizeof( strTemp ) );
		dwResult = GetPrivateProfileString(strSection.c_str(),
										strKey.c_str(),
										strDefault.c_str(),
										strTemp,
										MAX_PATH,
										m_strFileName.c_str());

		strReturn = strTemp;

		
		return dwResult;
	}
	
	UINT IniConfigReader::getInt(const String strSectionName, const String strKeyName, int iDefault)
	{

		UINT iResult;

		iResult = GetPrivateProfileInt(strSectionName.c_str(),
									strKeyName.c_str(),
									iDefault,
									m_strFileName.c_str());
		return iResult;
	}

	bool IniConfigReader::getBool(const String strSection, const String strKey, const String strDefault)
	{

		String strTemp = "";

		getString(strSection, strKey, strDefault, strTemp);

		if(strTemp == "TRUE")
		{
			return true;
		}else
		{
			return false;
		}

	}

	float IniConfigReader::getFloat(const String strSection, const String strKey, const String strDefault)
	{

		String strTemp;

		getString(strSection, strKey, strDefault, strTemp);

		return (float)strtod(strTemp.c_str(),TEXT('\0'));
		

	}


}
