
#include "PeonFileLogger.h"
#include "PeonIniConfigReader.h"
#include "PeonInputEngine.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{
	template<> InputEngine* ISingleton<InputEngine>::ms_Singleton = 0;

	InputEngine* InputEngine::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	InputEngine& InputEngine::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	InputEngine::InputEngine()
	{
		m_bJoystickConnected = false;
		m_pJoystick = NULL;

	}

	InputEngine::~InputEngine()
	{
		unloadEngine();
	}

	bool InputEngine::loadEngine( IniConfigReader* pConfig )
	{
		TCHAR strOutput[MAX_PATH];

		//check number of joysticks found
		if(SDL_NumJoysticks() < 1)
		{
			//no connected joysticks found
			FileLogger::getSingleton().logInfo("InputEngine", "No joystick devices connected");
			m_bJoystickConnected = false;
			m_pJoystick = NULL;
			return true;
		}

		//just spit out the name of the joystick found..
		sprintf( strOutput, "Joystick detected with name: %s", SDL_JoystickName(0));
		FileLogger::getSingleton().logDebug("InputEngine", strOutput);

		m_pJoystick = SDL_JoystickOpen(0);

		int iNumberOfButtons = SDL_JoystickNumButtons( m_pJoystick );
		int iNumberOfAxis    = SDL_JoystickNumAxes( m_pJoystick );

		//a guard against other input devices disguised as joysticks
		if(iNumberOfAxis < 2)
		{
			SDL_JoystickClose( m_pJoystick );
			m_bJoystickConnected = false;
			m_pJoystick = NULL;

			sprintf( strOutput, "Joystick %s doesn't have more than 2 axis. Disabling Joystick support", SDL_JoystickName(0));
			FileLogger::getSingleton().logInfo("InputEngine", strOutput);

			return true;
		}


		sprintf( strOutput, "Joystick properties: %d buttons and %d axis", iNumberOfButtons, iNumberOfAxis);
		FileLogger::getSingleton().logDebug("InputEngine", strOutput);


		m_bJoystickConnected = true;

		return true;
	}

	void InputEngine::unloadEngine()
	{
		if(m_pJoystick)
		{
			SDL_JoystickClose( m_pJoystick );
			m_pJoystick = NULL;
		}

		m_bJoystickConnected = false;


	}

	Sint16 InputEngine::getJoyXAxis()
	{
		Sint16 val = 0;

		if(m_pJoystick)
		{
			val = SDL_JoystickGetAxis(m_pJoystick, 0) / JOYSTICK_DEAD_ZONE;
		}

		return( val );
	}

	Sint16 InputEngine::getJoyYAxis()
	{
		Sint16 val = 0;

		if(m_pJoystick)
		{
			val = SDL_JoystickGetAxis(m_pJoystick, 1) / JOYSTICK_DEAD_ZONE;
		}

		return( val );
	}
}