
#include "PeonMathUnit.h"

namespace peon
{
	template<> MathUnit* ISingleton<MathUnit>::ms_Singleton = 0;

	MathUnit* MathUnit::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	MathUnit& MathUnit::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	MathUnit::MathUnit()
	{
	}

	MathUnit::~MathUnit()
	{

	}

	float MathUnit::randFloat(const float& min, const float& max)
	{
		float range = max - min;
		float num = range * rand() / RAND_MAX;
		return (num + min);
	}

	int MathUnit::randInt(const int &min, const int &max)
	{
		int range = max - min;
		int num = range * rand() / RAND_MAX;
		return (num + min);
	}


}