
#include "PeonMeshFactory.h"
#include "PeonFileLogger.h"
#include "PeonEngineCore.h"

namespace peon
{

	s3DModel::s3DModel()
	{
		numOfObjects = 0;							
		numOfMaterials = 0;	
								
	
	}

	s3DModel::~s3DModel()
	{
		onUnload();
	}

	bool s3DModel::onLoad()
	{
		SceneTexture* pTex = NULL;

		TCHAR strOutput[512];
		TCHAR strTexture[512];

		for(int i = 0; i < numOfMaterials; i++)				
		{
			if(strlen(pMaterials[i].strFile) > 0)				
			{
				sprintf(strTexture, "%s\\%s", MeshFactory::getSingleton().getTexturePath(), pMaterials[i].strFile );


				//Texture_3ds(TextureArray3ds, m3DModel.pMaterials[i].strFile, i);
				sprintf( strOutput, "Attemtping to load texture: %s", strTexture);
				FileLogger::getSingleton().logDebug( "s3DModel", strOutput );

				pTex = peon::EngineCore::getSingleton().getRenderer()->loadTexture( strTexture, true, true, false );
				if(pTex != NULL)
				{
					m_oTextures.insert(std::make_pair(i, pTex));

				}
							
			}
			
			pMaterials[i].textureId = i;						
		}

		return true;
	}

	void s3DModel::onRender()
	{

		TCHAR strDebug[512];
		sprintf(strDebug, "OnRender reports %d objects", numOfObjects);
		FileLogger::getSingleton().logDebug("s3DModel", strDebug);

		for(int i = 0; i < numOfObjects; i++)
		{
			
			if(pObject.size() <= 0) break;						
			
			//s3DObject *pObject = &pObject[i];		
			s3DObject *pObj = &pObject.at(i);
			
			if(pObj->bHasTexture)									
			{									
				glEnable(GL_TEXTURE_2D);								
				
				glColor3ub(255, 255, 255);								
				
				//glBindTexture(GL_TEXTURE_2D, TextureArray3ds[pObject->materialID]);
				setTexture( pObj->materialID );
				
			} 
			else 
			{
				glDisable(GL_TEXTURE_2D);								
				
				glColor3ub(255, 255, 255);								
			}
			
			glBegin(GL_TRIANGLES);										
			
			for(int j = 0; j < pObj->numOfFaces; j++)
			{
				
				for(int whichVertex = 0; whichVertex < 3; whichVertex++)
				{
					int index = pObj->pFaces[j].vertIndex[whichVertex];
					
					glNormal3f(pObj->pNormals[ index ].x, pObj->pNormals[ index ].y, pObj->pNormals[ index ].z);
					
					if(pObj->bHasTexture) {
						
						if(pObj->pTexVerts) {
							glTexCoord2f(pObj->pTexVerts[ index ].x, pObj->pTexVerts[ index ].y);
						}
					} else {
						
						if(pMaterials.size() < pObj->materialID) 
						{
							BYTE *pColor = pMaterials[pObj->materialID].color;
							
							glColor3ub(pColor[0], pColor[1], pColor[2]);
						}
					}
					
					glVertex3f(pObj->pVerts[ index ].x, pObj->pVerts[ index ].y, pObj->pVerts[ index ].z);
				}
			}
			
			glEnd();
		}


	}

	void s3DModel::setTexture( int key )
	{
		SceneTexture* pTex = NULL;

		std::map<int, SceneTexture*>::iterator it;
		it = m_oTextures.find(key);
		if (it == m_oTextures.end())
		{
			FileLogger::getSingleton().logError("s3DModel", "Couldn't find texture handle");
			return;
		}
		else
		{
			//m_pCurrentState = it->second;
			pTex = (SceneTexture*)it->second;

			glBindTexture(GL_TEXTURE_2D, pTex->getTex() );
		}


	}

	void s3DModel::onUnload()
	{
		for(int i = 0; i < numOfObjects; i++)	
		{
			PEON_DELETE_ARRAY( pObject[i].pFaces );
			PEON_DELETE_ARRAY( pObject[i].pNormals );
			PEON_DELETE_ARRAY( pObject[i].pVerts );
			PEON_DELETE_ARRAY( pObject[i].pTexVerts );
		}

		SceneTexture* pObj;
		for(std::map<int, SceneTexture*>::iterator it = m_oTextures.begin();
			it != m_oTextures.end();
			it++)
		{
			pObj = (peon::SceneTexture*)it->second;
			
			PEON_DELETE( pObj );

		}

		m_oTextures.clear();



	}



	///////////////////////////////////////////////////////////////

	template<> MeshFactory* ISingleton<MeshFactory>::ms_Singleton = 0;

	MeshFactory* MeshFactory::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	MeshFactory& MeshFactory::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}


	MeshFactory::MeshFactory()
	{
		m_pCurrentChunk = new sChunk;				 
		m_pTempChunk    = new sChunk;
		m_pFile			= NULL;		
		
		m_strTexturePath= "";			
	}

	MeshFactory::~MeshFactory()
	{
	}

	s3DModel* MeshFactory::loadMeshFrom3DS( const String& strFileName, const String& strTexturePath )
	{
		char strMessage[255] = {0};
		s3DModel* pModel = new s3DModel();

		if(m_pFile)
		{
			unloadData();
		}



		sprintf(strMessage, "Attempting to load mesh from file: %s", strFileName.c_str() );
		FileLogger::getSingleton().logInfo("MeshFactory", strMessage );
		
		m_pFile = fopen(strFileName.c_str(), "rb");
		if( !m_pFile ) 
		{
			sprintf(strMessage, "Unable to find the file: %s!", strFileName.c_str() );
			FileLogger::getSingleton().logError("MeshFactory", strMessage );
			return NULL;
		}

		m_strTexturePath = strTexturePath;

		FileLogger::getSingleton().logDebug("MeshFactory", "Before read chunk");
		
		readChunk(m_pCurrentChunk);

		FileLogger::getSingleton().logDebug("MeshFactory", "after read chunk" );
		
		if (m_pCurrentChunk->ID != PRIMARY)
		{
			sprintf(strMessage, "Unable to load PRIMARY chuck from file: %s!", strFileName.c_str() );
			FileLogger::getSingleton().logError("MeshFactory", strMessage );
			return NULL;
		}
		
		processNextChunk(pModel, m_pCurrentChunk);

		FileLogger::getSingleton().logDebug("MeshFactory", "after processNextChunk" );

		
		computeNormals(pModel);
		
		unloadData();

		if( !pModel->onLoad() )
		{
			PEON_DELETE( pModel );
			pModel = NULL;
		}
		
		return( pModel );
	}


	void MeshFactory::unloadData()
	{
		fclose(m_pFile);						 
		delete m_pCurrentChunk;						
		delete m_pTempChunk;							
	}

	void MeshFactory::processNextChunk(s3DModel *pModel, sChunk *pPreviousChunk)
	{
		s3DObject newObject;					 
		sMaterialInfo newTexture;				
		unsigned short version = 0;					
		int buffer[50000] = {0};
		
		TCHAR strOutput[512];					
		
		m_pCurrentChunk = new sChunk;				
		
		while (pPreviousChunk->bytesRead < pPreviousChunk->length)
		{
			readChunk(m_pCurrentChunk);
			
			switch (m_pCurrentChunk->ID)
			{
			case VERSION:							
				
				m_pCurrentChunk->bytesRead += fread(&version, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				
				if (version > 0x03)
				{
					sprintf(strOutput, "This 3DS file is over version 3 so it may load incorrectly" );
                    FileLogger::getSingleton().logInfo( "MeshFactory", strOutput );
				}

				break;
				
			case OBJECTINFO:						
				readChunk(m_pTempChunk);
				
				m_pTempChunk->bytesRead += fread(&version, 1, m_pTempChunk->length - m_pTempChunk->bytesRead, m_pFile );
				
				m_pCurrentChunk->bytesRead += m_pTempChunk->bytesRead;
				
				processNextChunk(pModel, m_pCurrentChunk);

				break;
				
			case MATERIAL:						
				pModel->numOfMaterials++;
				
				pModel->pMaterials.push_back(newTexture);
				
				processNextMaterialChunk(pModel, m_pCurrentChunk);
				break;
				
			case OBJECT:							
				pModel->numOfObjects++;
				
				pModel->pObject.push_back(newObject);
				
				memset(&(pModel->pObject[pModel->numOfObjects - 1]), 0, sizeof(s3DObject));
				
				m_pCurrentChunk->bytesRead += getString(pModel->pObject[pModel->numOfObjects - 1].strName);
				
				processNextObjectChunk(pModel, &(pModel->pObject[pModel->numOfObjects - 1]), m_pCurrentChunk);
				break;
				
			case EDITKEYFRAME:
				
				m_pCurrentChunk->bytesRead += fread(buffer, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
				
			default: 
				
				m_pCurrentChunk->bytesRead += fread(buffer, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
			}
			
			pPreviousChunk->bytesRead += m_pCurrentChunk->bytesRead;
		}
		
		delete m_pCurrentChunk;
		m_pCurrentChunk = pPreviousChunk;
	}


	void MeshFactory::processNextObjectChunk(s3DModel *pModel, s3DObject *pObject, sChunk *pPreviousChunk)
	{
		int buffer[50000] = {0};					
		
		m_pCurrentChunk = new sChunk;
		
		while (pPreviousChunk->bytesRead < pPreviousChunk->length)
		{
			readChunk(m_pCurrentChunk);
			
			switch (m_pCurrentChunk->ID)
			{
			case OBJECT_MESH:		
				processNextObjectChunk(pModel, pObject, m_pCurrentChunk);
				break;
				
			case OBJECT_VERTICES:			 
				readVertices(pObject, m_pCurrentChunk);
				break;
				
			case OBJECT_FACES:				 
				readVertexIndices(pObject, m_pCurrentChunk);
				break;
				
			case OBJECT_MATERIAL:			 
				readObjectMaterial(pModel, pObject, m_pCurrentChunk);			
				break;
				
			case OBJECT_UV:					
				readUVCoordinates(pObject, m_pCurrentChunk);
				break;
				
			default: 
				m_pCurrentChunk->bytesRead += fread(buffer, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
			}
			
			pPreviousChunk->bytesRead += m_pCurrentChunk->bytesRead;
		}
		
		delete m_pCurrentChunk;
		m_pCurrentChunk = pPreviousChunk;
	}


	void MeshFactory::processNextMaterialChunk(s3DModel *pModel, sChunk *pPreviousChunk)
	{
		int buffer[50000] = {0};					  
		m_pCurrentChunk = new sChunk;
		
		while (pPreviousChunk->bytesRead < pPreviousChunk->length)
		{
			readChunk(m_pCurrentChunk);
			
			switch (pModel, m_pCurrentChunk->ID)
			{
			case MATNAME:
				OutputDebugString("MATNAME\n");						 
				m_pCurrentChunk->bytesRead += fread(pModel->pMaterials[pModel->numOfMaterials - 1].strName, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
				
			case MATDIFFUSE:
				OutputDebugString("MATDIFFUSE\n");					 
				readColorChunk(&(pModel->pMaterials[pModel->numOfMaterials - 1]), m_pCurrentChunk);
				break;
				
			case MATMAP:
				OutputDebugString("MATMAP\n");					 
				processNextMaterialChunk(pModel, m_pCurrentChunk);
				break;
				
			case MATMAPFILE:
				OutputDebugString("MATMAPFILE\n");						 
				m_pCurrentChunk->bytesRead += fread(pModel->pMaterials[pModel->numOfMaterials - 1].strFile, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
				
			default: 
				OutputDebugString("default\n"); 
				m_pCurrentChunk->bytesRead += fread(buffer, 1, m_pCurrentChunk->length - m_pCurrentChunk->bytesRead, m_pFile );
				break;
			}
			pPreviousChunk->bytesRead += m_pCurrentChunk->bytesRead;
		}
		
		delete m_pCurrentChunk;
		m_pCurrentChunk = pPreviousChunk;
	}

	void MeshFactory::readChunk(sChunk *pChunk)
	{
		pChunk->bytesRead = fread(&pChunk->ID, 1, 2, m_pFile );
		
		pChunk->bytesRead += fread(&pChunk->length, 1, 4, m_pFile );
	}

	int MeshFactory::getString(char *pBuffer)
	{
		int index = 0;
		
		fread(pBuffer, 1, 1, m_pFile );
		
		while (*(pBuffer + index++) != 0) 
		{
			fread(pBuffer + index, 1, 1, m_pFile );
		}
		
		return strlen(pBuffer) + 1;
	}

	void MeshFactory::readColorChunk(sMaterialInfo *pMaterial, sChunk *pChunk)
	{
		readChunk(m_pTempChunk);
		m_pTempChunk->bytesRead += fread(pMaterial->color, 1, m_pTempChunk->length - m_pTempChunk->bytesRead, m_pFile );
		pChunk->bytesRead += m_pTempChunk->bytesRead;
	}

	void MeshFactory::readVertexIndices(s3DObject *pObject, sChunk *pPreviousChunk)
	{
		unsigned short index = 0;					 
		pPreviousChunk->bytesRead += fread(&pObject->numOfFaces, 1, 2, m_pFile );
		
		pObject->pFaces = new sFace [pObject->numOfFaces];
		memset(pObject->pFaces, 0, sizeof(sFace) * pObject->numOfFaces);
		
		
		for(int i = 0; i < pObject->numOfFaces; i++)
		{
			for(int j = 0; j < 4; j++)
			{
				pPreviousChunk->bytesRead += fread(&index, 1, sizeof(index), m_pFile );
				
				if(j < 3)
				{
					pObject->pFaces[i].vertIndex[j] = index;
				}
			}
		}
	}

	void MeshFactory::readUVCoordinates(s3DObject *pObject, sChunk *pPreviousChunk)
	{
		pPreviousChunk->bytesRead += fread(&pObject->numTexVertex, 1, 2, m_pFile );
		
		pObject->pTexVerts = new Vector2[pObject->numTexVertex];
		
		pPreviousChunk->bytesRead += fread(pObject->pTexVerts, 1, pPreviousChunk->length - pPreviousChunk->bytesRead, m_pFile );
	}

	void MeshFactory::readVertices(s3DObject *pObject, sChunk *pPreviousChunk)
	{ 
		pPreviousChunk->bytesRead += fread(&(pObject->numOfVerts), 1, 2, m_pFile );
		
		pObject->pVerts = new Vector3 [pObject->numOfVerts];
		memset(pObject->pVerts, 0, sizeof(Vector3) * pObject->numOfVerts);
		
		pPreviousChunk->bytesRead += fread(pObject->pVerts, 1, pPreviousChunk->length - pPreviousChunk->bytesRead, m_pFile );
	}

	void MeshFactory::readObjectMaterial(s3DModel *pModel, s3DObject *pObject, sChunk *pPreviousChunk)
	{
		char strMaterial[255] = {0};			
		int buffer[50000] = {0};				
		
		pPreviousChunk->bytesRead += getString(strMaterial);
		
		for(int i = 0; i < pModel->numOfMaterials; i++)
		{
			if(strcmp(strMaterial, pModel->pMaterials[i].strName) == 0)
			{
				pObject->materialID = i;
				
				if(strlen(pModel->pMaterials[i].strFile) > 0) {
					
					pObject->bHasTexture = true;
				}	
				break;
			}
		}
		
		pPreviousChunk->bytesRead += fread(buffer, 1, pPreviousChunk->length - pPreviousChunk->bytesRead, m_pFile );
	}			

	void MeshFactory::computeNormals(s3DModel *pModel)
	{
		Vector3 vVector1, vVector2, vNormal, vPoly[3];
		int i;
		
		if(pModel->numOfObjects <= 0)
			return;
		
		for(int index = 0; index < pModel->numOfObjects; index++)
		{
			s3DObject *pObject = &(pModel->pObject[index]);
			
			Vector3 *pNormals		= new Vector3 [pObject->numOfFaces];
			Vector3 *pTempNormals	= new Vector3 [pObject->numOfFaces];
			pObject->pNormals		= new Vector3 [pObject->numOfVerts];
			
			for(i=0; i < pObject->numOfFaces; i++)
			{												
				vPoly[0] = pObject->pVerts[pObject->pFaces[i].vertIndex[0]];
				vPoly[1] = pObject->pVerts[pObject->pFaces[i].vertIndex[1]];
				vPoly[2] = pObject->pVerts[pObject->pFaces[i].vertIndex[2]];
				
				vVector1 = vPoly[0] - vPoly[2];				
				vVector2 = vPoly[2] - vPoly[1];				
				
				//vNormal  = Cross(vVector1, vVector2);
				
				vVector1.crossProduct( vVector2 );

				vNormal = vVector1;
						
				pTempNormals[i] = vNormal;					
				//vNormal  = Normalize(vNormal);
				vNormal.normalize();				
				
				pNormals[i] = vNormal;						
			}
			
			
			Vector3 vSum(0.0f, 0.0f, 0.0f);
			Vector3 vZero = vSum;
			int shared=0;
			
			for (i = 0; i < pObject->numOfVerts; i++)			
			{
				for (int j = 0; j < pObject->numOfFaces; j++)	
				{												
					if (pObject->pFaces[j].vertIndex[0] == i || 
						pObject->pFaces[j].vertIndex[1] == i || 
						pObject->pFaces[j].vertIndex[2] == i)
					{
						vSum = vSum + pTempNormals[j];			
						shared++;								
					}
				}      
				
				//pObject->pNormals[i] = DivideVectorByScaler(vSum, float(-shared));

				pObject->pNormals[i] = vSum / float(-shared);
				
				//pObject->pNormals[i] = Normalize(pObject->pNormals[i]);
				pObject->pNormals[i].normalize();	
				
				vSum = vZero;									 
				shared = 0;										
			}
			
			delete [] pTempNormals;
			delete [] pNormals;
		}
	}



}