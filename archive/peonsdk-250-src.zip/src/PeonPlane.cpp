
#include "PeonPlane.h"

namespace peon 
{
	Plane::Plane(float _x, float _y, float _z, float _d)
	{
		normal = Vector3( _x ,_y, _z );

		d = _d;

	}

	Plane::~Plane()
	{

		

	}

	void Plane::normalize()
	{

		//just normalize the vector
		

	}

}

