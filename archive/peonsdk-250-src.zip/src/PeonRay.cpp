
#include "PeonRay.h"

namespace peon
{
	Ray::Ray()
	{
	}

	Ray::~Ray()
	{

	}

}
