
#include "PeonSceneCamera.h"



namespace peon
{
	SceneCamera::SceneCamera()
	{
	}

	SceneCamera::~SceneCamera()
	{
	
	}

	void SceneCamera::setPerspectiveProj( float fAspect, float z_min, float z_max )
	{
		glMatrixMode( GL_PROJECTION );
		glLoadIdentity();
		
		gluPerspective( 45.0f, fAspect, z_min, z_max );

		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();

	}

	void SceneCamera::setViewMatrix( Vector3& vecEye, Vector3& vecLookAt, Vector3& vecUp)
	{
	

		m_vecPos = vecEye;
		m_vecUp = vecUp;
		m_vecLookAt = vecLookAt;


	}

	void SceneCamera::updateView()
	{
		
		gluLookAt( m_vecPos.x, m_vecPos.y, m_vecPos.z,
			m_vecLookAt.x, m_vecLookAt.y, m_vecLookAt.z,
			m_vecUp.x, m_vecUp.y, m_vecUp.z );

	}

	void SceneCamera::generateViewFrustum()
	{

		
		float p[16];   // projection matrix
		float mv[16];  // model-view matrix
		float mvp[16]; // model-view-projection matrix
	
		//grab the current projection matrix and shove it into a 16 element
		//array
		glGetFloatv( GL_PROJECTION_MATRIX, p );

		//grab the current modelview matrix and stick it into
		//a 16 element array
		glGetFloatv( GL_MODELVIEW_MATRIX, mv );

		//
		// Concatenate the projection matrix and the model-view matrix to produce 
		// a combined model-view-projection matrix.
		//
		// Note that this could be handled by just a quick multiplication of
		// two Matrix44 objects, but I wanted to put it out long-hand just
		// for people to see what's happening.
		//
		// Feel free to dump the the mv, mvp and p variables into Matrix44 objects
    
		mvp[ 0] = mv[ 0] * p[ 0] + mv[ 1] * p[ 4] + mv[ 2] * p[ 8] + mv[ 3] * p[12];
		mvp[ 1] = mv[ 0] * p[ 1] + mv[ 1] * p[ 5] + mv[ 2] * p[ 9] + mv[ 3] * p[13];
		mvp[ 2] = mv[ 0] * p[ 2] + mv[ 1] * p[ 6] + mv[ 2] * p[10] + mv[ 3] * p[14];
		mvp[ 3] = mv[ 0] * p[ 3] + mv[ 1] * p[ 7] + mv[ 2] * p[11] + mv[ 3] * p[15];

		mvp[ 4] = mv[ 4] * p[ 0] + mv[ 5] * p[ 4] + mv[ 6] * p[ 8] + mv[ 7] * p[12];
		mvp[ 5] = mv[ 4] * p[ 1] + mv[ 5] * p[ 5] + mv[ 6] * p[ 9] + mv[ 7] * p[13];
		mvp[ 6] = mv[ 4] * p[ 2] + mv[ 5] * p[ 6] + mv[ 6] * p[10] + mv[ 7] * p[14];
		mvp[ 7] = mv[ 4] * p[ 3] + mv[ 5] * p[ 7] + mv[ 6] * p[11] + mv[ 7] * p[15];

		mvp[ 8] = mv[ 8] * p[ 0] + mv[ 9] * p[ 4] + mv[10] * p[ 8] + mv[11] * p[12];
		mvp[ 9] = mv[ 8] * p[ 1] + mv[ 9] * p[ 5] + mv[10] * p[ 9] + mv[11] * p[13];
		mvp[10] = mv[ 8] * p[ 2] + mv[ 9] * p[ 6] + mv[10] * p[10] + mv[11] * p[14];
		mvp[11] = mv[ 8] * p[ 3] + mv[ 9] * p[ 7] + mv[10] * p[11] + mv[11] * p[15];

		mvp[12] = mv[12] * p[ 0] + mv[13] * p[ 4] + mv[14] * p[ 8] + mv[15] * p[12];
		mvp[13] = mv[12] * p[ 1] + mv[13] * p[ 5] + mv[14] * p[ 9] + mv[15] * p[13];
		mvp[14] = mv[12] * p[ 2] + mv[13] * p[ 6] + mv[14] * p[10] + mv[15] * p[14];
		mvp[15] = mv[12] * p[ 3] + mv[13] * p[ 7] + mv[14] * p[11] + mv[15] * p[15];

		//
		// Extract the frustum's right clipping plane and normalize it.
		//
		m_oFrustumPlanes[RIGHT].normal.x = mvp[ 3] - mvp[ 0];
		m_oFrustumPlanes[RIGHT].normal.y = mvp[ 7] - mvp[ 4];
		m_oFrustumPlanes[RIGHT].normal.z = mvp[11] - mvp[ 8];
		m_oFrustumPlanes[RIGHT].d = mvp[15] - mvp[12];

		m_oFrustumPlanes[RIGHT].normalize();


		//
		// Extract the frustum's left clipping plane and normalize it.
		//
		m_oFrustumPlanes[LEFT].normal.x = mvp[ 3] + mvp[ 0];
		m_oFrustumPlanes[LEFT].normal.y = mvp[ 7] + mvp[ 4];
		m_oFrustumPlanes[LEFT].normal.z = mvp[11] + mvp[ 8];
		m_oFrustumPlanes[LEFT].d = mvp[15] + mvp[12];

		m_oFrustumPlanes[LEFT].normalize();

		//
		// Extract the frustum's bottom clipping plane and normalize it.
		//
		m_oFrustumPlanes[BOTTOM].normal.x = mvp[ 3] + mvp[ 1];
		m_oFrustumPlanes[BOTTOM].normal.y = mvp[ 7] + mvp[ 5];
		m_oFrustumPlanes[BOTTOM].normal.z = mvp[11] + mvp[ 9];
		m_oFrustumPlanes[BOTTOM].d = mvp[15] + mvp[13];

		m_oFrustumPlanes[BOTTOM].normalize();

		//
		// Extract the frustum's top clipping plane and normalize it.
		//
		m_oFrustumPlanes[TOP].normal.x = mvp[ 3] - mvp[ 1];
		m_oFrustumPlanes[TOP].normal.y = mvp[ 7] - mvp[ 5];
		m_oFrustumPlanes[TOP].normal.z = mvp[11] - mvp[ 9];
		m_oFrustumPlanes[TOP].d = mvp[15] - mvp[13];

		m_oFrustumPlanes[TOP].normalize();


		//
		// Extract the frustum's far clipping plane and normalize it.
		//
		m_oFrustumPlanes[BACK].normal.x = mvp[ 3] - mvp[ 2];
		m_oFrustumPlanes[BACK].normal.y = mvp[ 7] - mvp[ 6];
		m_oFrustumPlanes[BACK].normal.z = mvp[11] - mvp[10];
		m_oFrustumPlanes[BACK].d = mvp[15] - mvp[14];

		m_oFrustumPlanes[BACK].normalize();

		//
		// Extract the frustum's near clipping plane and normalize it.
		//
		m_oFrustumPlanes[FRONT].normal.x = mvp[ 3] + mvp[ 2];
		m_oFrustumPlanes[FRONT].normal.y = mvp[ 7] + mvp[ 6];
		m_oFrustumPlanes[FRONT].normal.z = mvp[11] + mvp[10];
		m_oFrustumPlanes[FRONT].d = mvp[15] + mvp[14];

		m_oFrustumPlanes[FRONT].normalize();
		


	}

	bool SceneCamera::isSphereInFrustum( float x, float y, float z, float fRadius )
	{
		
		for( int i = 0; i < 6; ++i )
		{
			if( m_oFrustumPlanes[i].normal.x * x +
				m_oFrustumPlanes[i].normal.y * y +
				m_oFrustumPlanes[i].normal.z * z +
				m_oFrustumPlanes[i].d <= -fRadius )
				return false;
		}
		

		return true;
	}

}
