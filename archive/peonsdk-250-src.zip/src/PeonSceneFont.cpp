
#include "PeonFileLogger.h"
#include "PeonEngineCore.h"
#include "PeonSceneFont.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{
	SceneFont::SceneFont()
	{
		m_r = m_g = m_b = m_a = 1.0f;
		m_char_width = 16;
		m_char_height = 16;
		m_char_spacing = 14;

		m_fxCount = 16;
		m_fyCount = 16;

		m_font_batching = false;


	}

	SceneFont::~SceneFont()
	{
		unloadFont();
	}

	bool SceneFont::loadFont(int char_width, int char_height, int char_spacing)
	{


		int     loop;
		float	cx;																// Holds Our X Character Coord
		float	cy;																// Holds Our Y Character Coord
		float   cwx;															// CharWidth in texture units
		float   cwy;
		
		m_char_width = char_width;
		m_char_height = char_height;
		m_char_spacing = char_spacing;															// CharHeight in texture units

		cwx         = (1.0f / 256.0f) * m_char_width;
		cwy         = (1.0f / 256.0f) * m_char_height;
		
		m_display_list = glGenLists(m_fxCount * m_fyCount);									// Creating Display Lists
			
		for (loop=0; loop<(m_fxCount * m_fyCount); loop++)							// Loop Through All Lists
		{
			cx=float(loop%m_fxCount) * cwx;										// X Position Of Current Character
			cy=float(loop/m_fyCount) * cwy;										// Y Position Of Current Character

			glNewList(m_display_list + loop,GL_COMPILE);									// Start Building A List
				glBegin(GL_QUADS);												// Use A Quad For Each Character
					glTexCoord2f(cx,1-cy-cwy);									// Texture Coord (Bottom Left)
					glVertex2i(0, m_char_height);											// Vertex Coord (Bottom Left)
					glTexCoord2f(cx+cwx,1-cy-cwy);								// Texture Coord (Bottom Right)
					//glVertex2i(m_char_width - 1,0);									// Vertex Coord (Bottom Right)
					glVertex2i( m_char_width, m_char_height);
					glTexCoord2f(cx+cwx,1-cy);									// Texture Coord (Top Right)
					//glVertex2i(m_char_width - 1,m_char_height -1);							// Vertex Coord (Top Right)
					glVertex2i( m_char_width, 0);
					glTexCoord2f(cx,1-cy);										// Texture Coord (Top Left)
					//glVertex2i(0,m_char_height -1);									// Vertex Coord (Top Left)
					glVertex2i(0, 0);
				glEnd();														// Done Building Our Quad (Character)
				glTranslated(m_char_spacing,0,0);										// Move To The Right Of The Character
			glEndList();														// Done Building The Display List
		}

		return true;
	}

	void SceneFont::unloadFont()
	{
		glDeleteLists(m_display_list,m_fxCount * m_fyCount);
	}

	void SceneFont::renderText(float xpos, float ypos, const String& strText)
	{
		
		int width = EngineCore::getSingleton().getRenderer()->getWidth();
		int height= EngineCore::getSingleton().getRenderer()->getHeight();
		
		if(!m_font_batching)
		{
		
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glDisable(GL_DEPTH_TEST);	
														// Disables Depth Testing
			glMatrixMode(GL_PROJECTION);				// Select The Projection Matrix
			glPushMatrix();								// Store The Projection Matrix
			glLoadIdentity();							// Reset The Projection Matrix
			glOrtho(0,width,height, 0, -1,1);				// Set Up An Ortho Screen
			glMatrixMode(GL_MODELVIEW);					// Select The Modelview Matrix

			glPushAttrib( GL_CURRENT_BIT );
		
		}
		
		glPushMatrix();															// Store The Modelview Matrix
		glLoadIdentity();														// Reset The Modelview Matrix
		glTranslatef(xpos,ypos,0.0f);											// Position The Text (0,0 - Bottom Left)
		glColor4f(m_r, m_g, m_b, m_a);
		glListBase( m_display_list - 32 + 128 );
		glCallLists((int)strText.length(), GL_UNSIGNED_BYTE, strText.c_str());								// Write The Text To The Screen
		
		if( !m_font_batching )
		{
			glPopAttrib();

			glMatrixMode(GL_PROJECTION);											// Select The Projection Matrix
			glPopMatrix();															// Restore The Old Projection Matrix
			glMatrixMode(GL_MODELVIEW);												// Select The Modelview Matrix
			glPopMatrix();															// Restore The Old Projection Matrix
		
			glDisable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);
		}


	}

	void SceneFont::setColor(float r, float g, float b, float a)
	{
		m_r = r;
		m_g = g;
		m_b = b;
		m_a = a;
	}

	bool SceneFont::beginBatchFont()
	{
		
		
		int width = EngineCore::getSingleton().getRenderer()->getWidth();
		int height= EngineCore::getSingleton().getRenderer()->getHeight();
	
		m_font_batching = true;

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glDisable(GL_DEPTH_TEST);

		glDisable(GL_LIGHTING);
	
													// Disables Depth Testing
		glMatrixMode(GL_PROJECTION);											// Select The Projection Matrix
		glPushMatrix();															// Store The Projection Matrix
		glLoadIdentity();														// Reset The Projection Matrix
		glOrtho(0,width,height,0,-1,1);										// Set Up An Ortho Screen
		glMatrixMode(GL_MODELVIEW);												// Select The Modelview Matrix


		return true;
	}

	void SceneFont::endBatchFont()
	{

		m_font_batching = false;

		glMatrixMode(GL_PROJECTION);											// Select The Projection Matrix
		glPopMatrix();															// Restore The Old Projection Matrix
		glMatrixMode(GL_MODELVIEW);												// Select The Modelview Matrix
		glPopMatrix();															// Restore The Old Projection Matrix
	
		glEnable(GL_LIGHTING);

		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);


	}


}

