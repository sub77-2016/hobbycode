
#include "PeonSceneLight.h"

namespace peon
{
	SceneLight::SceneLight()
	{
	}

	SceneLight::~SceneLight()
	{
	}
}
