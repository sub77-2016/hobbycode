
#include "PeonSceneRoot.h"

#if defined(DEBUG) | defined(_DEBUG)
  #define new DEBUG_NEW
#endif

namespace peon
{
	template<> SceneRoot* ISingleton<SceneRoot>::ms_Singleton = 0;

	SceneRoot* SceneRoot::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	SceneRoot& SceneRoot::getSingleton(void)
	{  
		assert( ms_Singleton );  
		return ( *ms_Singleton ); 

	}


	SceneRoot::SceneRoot( SceneRenderer* pRenderer ) : m_pRenderer( pRenderer )
	{
		if( m_pRenderer )
		{
			m_pRenderer->addRefCount();
		}
	
	}

	SceneRoot::~SceneRoot()
	{
		unloadDisplayObjects();

		if(m_pRenderer)
		{
			m_pRenderer->dropRefCount();
		}

	}

	bool SceneRoot::loadDisplayObject( ISceneObject* pObj )
	{

		if(pObj == NULL || !pObj->onLoad() )
		{
			
			return false;

		}

		pObj->addRefCount();

		m_oDisplayList.push_back( pObj );


		return true;
	}

	void SceneRoot::unloadDisplayObjects()
	{

		ISceneObject* pObj;
		for(std::list<ISceneObject*>::iterator it = m_oDisplayList.begin();
			it != m_oDisplayList.end();
			it++)
		{
			pObj = (ISceneObject*)*it;
			pObj->onUnload();

			pObj->dropRefCount();
			
			PEON_DELETE( pObj );

		}

		//clear the map
		m_oDisplayList.clear();

	}

}
