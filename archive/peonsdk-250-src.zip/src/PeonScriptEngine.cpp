
#include "PeonScriptEngine.h"
#include "PeonFileLogger.h"


#if defined( PEON_USE_LUA_ )

namespace peon
{
	template<> ScriptEngine* ISingleton<ScriptEngine>::ms_Singleton = 0;

	ScriptEngine* ScriptEngine::getSingletonPtr(void)
	{
		return ms_Singleton;
	}

	ScriptEngine& ScriptEngine::getSingleton(void)
	{  

		assert( ms_Singleton );  

		return ( *ms_Singleton ); 
	}

	ScriptEngine::ScriptEngine()
	{
		m_pLuaVM = NULL;

	}

	ScriptEngine::~ScriptEngine()
	{
		unloadEngine();
	}

	bool ScriptEngine::loadEngine( IniConfigReader* pConfig )
	{

		m_pLuaVM = lua_open();

		if(NULL == m_pLuaVM)
		{
			//serious problem, exit program
			return false;
		}

		//
		// The latest version of Lua seems to have renamed the following
		// methods that are printed in the book
		//
		/*
		lua_baselibopen( m_pLuaVM );
		lua_iolibopen( m_pLuaVM );
		lua_strlibopen( m_pLuaVM );
		lua_mathlibopen( m_pLuaVM );
		*/

		//
		// The latest Lua (5.1) seems to have renamed the above methods
		// to the ones used below. No idea why, but there you go
		// 
		luaopen_math( m_pLuaVM );
		luaopen_string( m_pLuaVM );
		luaopen_io( m_pLuaVM );
		luaopen_base( m_pLuaVM );


		return true;
	}

	void ScriptEngine::unloadEngine()
	{
		//do our script processing here.
		//now we are finished, close off Lua
		
		// The latest version of Lua seems to give me nasty exceptions when
		// explicitly calling this function directly. I've looked through
		// the documentation, and all I can see about it is that it's
		// automatically internally called when performing cleanup. This
		// seems to fix my generated exceptions, so there you go.
		// lua_close( m_pLuaVM );
	}

}

#endif
