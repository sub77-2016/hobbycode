
#include "PeonShockwave.h"

namespace peon
{
	Shockwave::Shockwave()
	{
		m_pParticles = NULL;
		m_pTexture   = NULL;

	}

	Shockwave::~Shockwave()
	{
		unload();
		PEON_DELETE( m_pTexture );
		
	}
	
	bool Shockwave::load(float fSize, float fThickness, int iNumDivisions, float fExpandRate, float fLifetime)
	{
		unload();

		m_iNumDivisions = iNumDivisions;
		m_fSize = fSize;
		m_fThickness = fThickness;
		m_fExpandRate = fExpandRate;
		m_fLifetime = fLifetime;

		m_iNumVerts = iNumDivisions * 6;

		m_pParticles = new ParticleVtx[m_iNumVerts];

		m_fAge = 0.0f;
		m_fScale = 0.0f;

		
		// calculate number of vertices
		float fStep = 360.0f / iNumDivisions;

		int i = 0;
		for (float q=0.0f; q < 360.0f; q+= fStep)
		{
			// calculate x1,y1, x2,y2, x3,y3 and x4,y4 points
			float x1 = m_fSize * cosf(PEON_DEGTORAD(q));
			float y1 = m_fSize * sinf(PEON_DEGTORAD(q));
			float x2 = (m_fSize-m_fThickness) * cosf(PEON_DEGTORAD(q));
			float y2 = (m_fSize-m_fThickness) * sinf(PEON_DEGTORAD(q));

			float x3 = m_fSize * cosf(PEON_DEGTORAD(q+fStep));
			float y3 = m_fSize * sinf(PEON_DEGTORAD(q+fStep));
			float x4 = (m_fSize-m_fThickness) * cosf(PEON_DEGTORAD(q+fStep));
			float y4 = (m_fSize-m_fThickness) * sinf(PEON_DEGTORAD(q+fStep));


			m_pParticles[i] = ParticleVtx( x2, y2, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 0.0f, 1.0f);
	
			i++;

			m_pParticles[i] = ParticleVtx( x1, y1, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 0.0f, 0.0f);
	
			i++;
			
			m_pParticles[i] = ParticleVtx( x4, y4, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 1.0f, 1.0f);
		
  			i++;
			m_pParticles[i] = ParticleVtx( x1, y1, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 0.0f, 0.0f);
				
			i++;
			m_pParticles[i] = ParticleVtx( x3, y3, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 1.0f, 0.0f);
		
			i++;

			m_pParticles[i] = ParticleVtx( x4, y4, 0.0f, 0.0f, 0.0f, 1.0f, 255,255,255,255, 1.0f, 1.0f);
	
  			i++;

		}

		m_bIsRunning = false;

		return true;
	}

	void Shockwave::unload()
	{
		PEON_DELETE_ARRAY( m_pParticles );
	}

	void Shockwave::start()
	{ 
		m_bIsRunning = true; 
		m_fAge = 0.0f; 
		m_fScale = 0.0f; 
	}
	
	void Shockwave::stop()
	{ 
		m_bIsRunning = false;
	}
	
	void Shockwave::update( float fElapsedTime )
	{
		if(!m_bIsRunning)
			return;

		m_fScale += m_fExpandRate * fElapsedTime;
		m_fAge += fElapsedTime;

	
		
		int iAlpha = 0;
		iAlpha = (int)(255.0f - ( 255.0f * (m_fAge/m_fLifetime)));

		for( int i = 0; i < m_iNumVerts; i++)
		{
			m_pParticles[i].m_a = iAlpha;
		}

		if (m_fAge > m_fLifetime) stop();



	}

	void Shockwave::render()
	{
		if(!m_bIsRunning)
			return;

		glDisable( GL_DEPTH_TEST );
		glEnable( GL_BLEND );
		glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

		glBindTexture(GL_TEXTURE_2D, m_pTexture->getTex());

		glPushMatrix();
		glLoadIdentity();
		glTranslatef(m_vecPos.x, m_vecPos.y, m_vecPos.z);
		glScalef( m_fScale, 1.0f, m_fScale );


		glBegin( GL_TRIANGLES );

		ParticleVtx* p;
		for(int i = 0; i < m_iNumVerts; i++)
		{
			p = &m_pParticles[i];

			glColor4b( p->m_r, p->m_g, p->m_b, p->m_a );

			glTexCoord2f( p->m_tu, p->m_tv);
			glNormal3f( p->m_nx, p->m_ny, p->m_nz );
			glVertex3f( p->m_x, p->m_y, p->m_z );

		}

		glEnd();
		glPopMatrix();
		
		
		glDisable( GL_BLEND );
		glEnable( GL_DEPTH_TEST );

	}


}