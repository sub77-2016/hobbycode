
#include "PeonSkybox.h"
#include "PeonEngineCore.h"
#include "PeonFileLogger.h"

namespace peon
{

	Skybox::Skybox()
	{
		m_pLeftTexture = NULL;
		m_pRightTexture= NULL;
		m_pFrontTexture = NULL;
		m_pBackTexture = NULL;
		m_pTopTexture = NULL;
		m_pBottomTexture = NULL;
			
	}
	
	/**
	* Destructor
	*/
	Skybox::~Skybox()
	{
		unload();
	}

	bool Skybox::load( const String &strTexLeft, const String& strTexRight,
			   const String &strTexFront, const String& strTexBack,
			   const String &strTexTop,   const String& strTexBottom)
	{
		SceneRenderer* pRenderer = peon::EngineCore::getSingleton().getRenderer();

		
		m_pLeftTexture = pRenderer->loadTexture(strTexLeft, true, true, false);
		m_pRightTexture = pRenderer->loadTexture(strTexRight, true, true, false);
		m_pFrontTexture = pRenderer->loadTexture(strTexFront, true, true, false);
		m_pBackTexture = pRenderer->loadTexture(strTexBack, true, true, false);
		m_pTopTexture = pRenderer->loadTexture(strTexTop, true, true, false);
		m_pBottomTexture = pRenderer->loadTexture(strTexBottom, true, true, false);

		if(m_pLeftTexture == NULL  ||
		   m_pRightTexture == NULL ||
		   m_pFrontTexture == NULL ||
		   m_pBackTexture == NULL  ||
		   m_pTopTexture == NULL   ||
		   m_pBottomTexture == NULL)
		{

			FileLogger::getSingleton().logError("Skybox", "Error loading skybox images");
			return false;

		}

		return true;
	}

	void Skybox::unload()
	{
		PEON_DELETE( m_pLeftTexture );
		PEON_DELETE( m_pRightTexture );
		PEON_DELETE( m_pTopTexture );
		PEON_DELETE( m_pBottomTexture );
		PEON_DELETE( m_pFrontTexture );
		PEON_DELETE( m_pBackTexture );
		
	}

	void Skybox::render(float x, float y, float z)
	{
		
		glDisable(GL_DEPTH_TEST);
		glDepthMask(FALSE);
		glDisable(GL_LIGHTING);


		// This centers the sky box around (x, y, z)
		x = x - m_vecDim.x / 2; 
		y = y - m_vecDim.y / 2; 
		z = z - m_vecDim.z / 2; 



		glBindTexture(GL_TEXTURE_2D, m_pFrontTexture->getTex());

		// Start drawing the side as a QUAD
		glBegin(GL_QUADS);   
		
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x,              y,            z + m_vecDim.z);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x,              y + m_vecDim.y, z + m_vecDim.z);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x + m_vecDim.x, y + m_vecDim.y, z + m_vecDim.z); 
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x + m_vecDim.x, y,            z + m_vecDim.z);
	
	
		glEnd();

		// Draw Back side
		glBindTexture(GL_TEXTURE_2D, m_pBackTexture->getTex());
		glBegin(GL_QUADS);		
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x+m_vecDim.x, y,		z);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x+m_vecDim.x, y+m_vecDim.y, z); 
			glTexCoord2f(0.0f, 1.0f); glVertex3f(x,		  y+m_vecDim.y,	z);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(x,		  y,		z);
		glEnd();

		// Draw Left side
		glBindTexture(GL_TEXTURE_2D, m_pLeftTexture->getTex());
		glBegin(GL_QUADS);		
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x,		  y+m_vecDim.y,	z);	
			glTexCoord2f(0.0f, 1.0f); glVertex3f(x,		  y+m_vecDim.y,	z+m_vecDim.z); 
			glTexCoord2f(0.0f, 0.0f); glVertex3f(x,		  y,		z+m_vecDim.z);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x,		  y,		z);		
		glEnd();

		// Draw Right side
		glBindTexture(GL_TEXTURE_2D, m_pRightTexture->getTex());
		glBegin(GL_QUADS);		
			glTexCoord2f(0.0f, 0.0f); glVertex3f(x+m_vecDim.x, y,		z);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x+m_vecDim.x, y,		z+m_vecDim.z);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x+m_vecDim.x, y+m_vecDim.y,	z+m_vecDim.z); 
			glTexCoord2f(0.0f, 1.0f); glVertex3f(x+m_vecDim.x, y+m_vecDim.y,	z);
		glEnd();

		// Draw Up side
		glBindTexture(GL_TEXTURE_2D, m_pTopTexture->getTex());
		glBegin(GL_QUADS);		
			glTexCoord2f(0.0f, 1.0f); glVertex3f(x+m_vecDim.x, y+m_vecDim.y, z);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x+m_vecDim.x, y+m_vecDim.y, z+m_vecDim.z); 
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x,		  y+m_vecDim.y,	z+m_vecDim.z);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(x,		  y+m_vecDim.y,	z);
		glEnd();

		// Draw Down side
		glBindTexture(GL_TEXTURE_2D, m_pBottomTexture->getTex());
		glBegin(GL_QUADS);		
			glTexCoord2f(0.0f, 0.0f); glVertex3f(x,		  y,		z);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(x,		  y,		z+m_vecDim.z);
			glTexCoord2f(1.0f, 1.0f); glVertex3f(x+m_vecDim.x, y,		z+m_vecDim.z); 
			glTexCoord2f(0.0f, 1.0f); glVertex3f(x+m_vecDim.x, y,		z);
		glEnd();





		glEnable(GL_LIGHTING);
		glEnable( GL_DEPTH_TEST );
		glDepthMask( TRUE );
	}
		
	
}


