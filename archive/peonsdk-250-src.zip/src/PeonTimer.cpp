
#include "PeonTimer.h"

namespace peon
{
	Timer::Timer()
	{
		m_bUsingQPF         = false;
		m_bTimerStopped     = true;
		m_llQPFTicksPerSec  = 0;

		m_llStopTime        = 0;
		m_llLastElapsedTime = 0;
		m_llBaseTime        = 0;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32

		// Use QueryPerformanceFrequency() to get frequency of timer.  
		LARGE_INTEGER qwTicksPerSec;
		m_bUsingQPF = (bool) (QueryPerformanceFrequency( &qwTicksPerSec ) != 0);
		m_llQPFTicksPerSec = qwTicksPerSec.QuadPart;

#endif

	}

	Timer::~Timer()
	{
	}

	void Timer::reset()
	{
		if( !m_bUsingQPF )
			return;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32
		// Get either the current time or the stop time
		LARGE_INTEGER qwTime;
		if( m_llStopTime != 0 )
			qwTime.QuadPart = m_llStopTime;
		else
			QueryPerformanceCounter( &qwTime );

		m_llBaseTime        = qwTime.QuadPart;
		m_llLastElapsedTime = qwTime.QuadPart;

#endif

		m_llStopTime        = 0;
		m_bTimerStopped     = FALSE;
	}


	//--------------------------------------------------------------------------------------
	void Timer::start()
	{
		if( !m_bUsingQPF )
			return;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32
		// Get the current time
		LARGE_INTEGER qwTime;
		QueryPerformanceCounter( &qwTime );

		if( m_bTimerStopped )
			m_llBaseTime += qwTime.QuadPart - m_llStopTime;
		m_llStopTime = 0;
		m_llLastElapsedTime = qwTime.QuadPart;
		m_bTimerStopped = FALSE;

#endif

	}


	//--------------------------------------------------------------------------------------
	void Timer::stop()
	{
		if( !m_bUsingQPF )
			return;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32

		if( !m_bTimerStopped )
		{
			// Get either the current time or the stop time
			LARGE_INTEGER qwTime;
			if( m_llStopTime != 0 )
				qwTime.QuadPart = m_llStopTime;
			else
				QueryPerformanceCounter( &qwTime );

			m_llStopTime = qwTime.QuadPart;
			m_llLastElapsedTime = qwTime.QuadPart;
			m_bTimerStopped = TRUE;
		}

#endif


	}


	//--------------------------------------------------------------------------------------
	void Timer::advance()
	{
		if( !m_bUsingQPF )
			return;

		m_llStopTime += m_llQPFTicksPerSec/10;
	}


	//--------------------------------------------------------------------------------------
	float Timer::getAbsoluteTime()
	{
		if( !m_bUsingQPF )
			return -1.0f;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32
		// Get either the current time or the stop time
		LARGE_INTEGER qwTime;
		if( m_llStopTime != 0 )
			qwTime.QuadPart = m_llStopTime;
		else
			QueryPerformanceCounter( &qwTime );

		float fTime = qwTime.QuadPart / (float) m_llQPFTicksPerSec;
#endif

		return fTime;
	}


	//--------------------------------------------------------------------------------------
	float Timer::getTime()
	{
		if( !m_bUsingQPF )
			return -1.0f;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32

		// Get either the current time or the stop time
		LARGE_INTEGER qwTime;
		if( m_llStopTime != 0 )
			qwTime.QuadPart = m_llStopTime;
		else
			QueryPerformanceCounter( &qwTime );

		float fAppTime = (float) ( qwTime.QuadPart - m_llBaseTime ) / (float) m_llQPFTicksPerSec;
#endif

		return fAppTime;
	}


	//--------------------------------------------------------------------------------------
	float Timer::getElapsedTime()
	{
		if( !m_bUsingQPF )
			return -1.0f;

#if PEON_PLATFORM == PEON_PLATFORM_WIN32
		// Get either the current time or the stop time
		LARGE_INTEGER qwTime;
		if( m_llStopTime != 0 )
			qwTime.QuadPart = m_llStopTime;
		else
			QueryPerformanceCounter( &qwTime );

		float fElapsedTime = (float) ( qwTime.QuadPart - m_llLastElapsedTime ) / (float) m_llQPFTicksPerSec;
		m_llLastElapsedTime = qwTime.QuadPart;

#endif


		return fElapsedTime;
	}


	//--------------------------------------------------------------------------------------
	bool Timer::isStopped()
	{
		return m_bTimerStopped;
	}




}