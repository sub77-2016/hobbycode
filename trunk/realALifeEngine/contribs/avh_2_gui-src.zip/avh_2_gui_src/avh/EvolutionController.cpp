#include "EvolutionController.h"

EvolutionController* EvolutionController::Instance()
{
   static EvolutionController* instance = NULL;
   
   if (instance == NULL)
   {
      instance = new EvolutionController();
   }

   return instance;
}

EvolutionController::EvolutionController()
{
	SetState(EVOLUTION_OFF);
   //mPopulation = NULL;
	SetFitnessFunction(NULL);
   SetProgress(0.0);
	//SetStopRequested(false);

	ExperimentParameters p;
	p.fitnessType = FITNESS_FUNCTION_STANDING;
	p.mode = EVOLUTION_TRAINING;
	p.numGenerations = 0;
	p.numRuns = 0;
	p.popSize = 0;
	p.savePeriod = 0;
	p.testingFilename = "";
	SetExperimentParameters(p);
}

void EvolutionController::ResetEvolution()
{
	DestroyPopulation();
	DestroyFitnessFunction();
	//SetStopRequested(false);
	SetProgress(0.0);
	FireEvent(LISTENER_PROGRESS_EVENT, GetProgress());
}

void EvolutionController::Start()
{
	if (EVOLUTION_TRAINING == mExperimentParameters.mode)
	{
		CreateFitnessFunction();
		StartTraining();
		ResetEvolution();
	}
	else
	{
		//filename must be valid at this point!
		assert(!mExperimentParameters.testingFilename.empty());
		StartTesting();
	}
}

void EvolutionController::StartTraining()
{
	int numRuns = GetExperimentParameters().numRuns;
	int numGens = GetExperimentParameters().numGenerations;

	for (int currentRun=0; currentRun<numRuns; currentRun++)
	{
		std::cout << "Beginning new run" << std::endl;
		CreatePopulation();
		
		for (int currentGen=0; currentGen<numGens; currentGen++)
		{
			float gensDone = currentRun*numGens + currentGen;
			float totalGens = numGens*numRuns;
			SetProgress(100.0*(gensDone/totalGens));
			FireEvent(LISTENER_PROGRESS_EVENT, GetProgress());

			if (true == EvolutionEpoch(currentGen))
			{
				return;
			}

			//Eventually allow multiple fitness functions; multiply fitnesses together
		}

		DestroyPopulation();
	}
}

void EvolutionController::CreatePopulation()
{
	NeuralNet* brainPtr;
	int numBrainInputs = 15;
	int numBrainOutputs = 11;
	int activationFunction = 0;
	int brainSize[3];
	brainSize[0] = 2;
	brainSize[1] = 5;
	brainSize[2] = 5;
	for (int i=0; i<TEMP_POPULATION_SIZE; i++)
	{
		brainPtr = new NeuralNet(numBrainInputs, brainSize, numBrainOutputs, activationFunction);
		brainList.push_back(brainPtr);
	}
}

void EvolutionController::DestroyPopulation()
{
	while (!brainList.empty())
	{
		delete brainList.back();
		brainList.pop_back();
	}
}

bool EvolutionController::EvolutionEpoch(int generationNumber)
{
	wxCriticalSectionLocker locker(mFitnessFunctionCS);

	assert(mFitnessFunction);

	bool returnValue = false; //return true if we should quit early

	returnValue = mFitnessFunction->EvaluatePopulation(brainList);

	//If true, return early (user has requested to stop).
	if (true == returnValue) 
	{
		//Population statistics/individual fitnesses are not all correct at 
		//this point, so we must not use them before returning early.
		return true;
	}

	//Calculate stats

	//Output files

	std::cout << "End of Generation " << generationNumber;

	TempPopulationEpoch();

	return false;
}

void EvolutionController::TempPopulationEpoch()
{
	double averageFitness=0;
	std::list<NeuralNet*>::iterator brainIter;
	//std::cout << "End of Generation " << generationNumber;
	
	//1. sort brain list by fitness
	brainList.sort(ComparisonFunction); //highest value at the front of the list

	//2. save stats, best brain
	for (brainIter = brainList.begin(); brainIter != brainList.end(); brainIter++)
	{
		averageFitness += (*brainIter)->GetFitness();
	}
	averageFitness = averageFitness/double(TEMP_POPULATION_SIZE);

	std::cout << ". Best: " << (*brainList.begin())->GetFitness() << ". Average: " << averageFitness << std::endl;

	////only write to files every 10 generations
	//if (generationNumber != 0 && generationNumber%FILE_WRITING_PERIOD == 0)
	//{
	//	//write to stats file
	//	statsFile = fopen("stats/stats.dat", "a");
	//	//output format: generation#,best,average; this format is good for Microsoft Excel importing
	//	fprintf(statsFile, "%d,%lf,%lf\n", generationNumber, (*brainList.begin())->GetFitness(), averageFitness);
	//	fclose(statsFile);

	//	//write to genes files
	//	//char buffer[32];
	//	std::string filename = "genes/g";
	//	//filename += itoa(generationNumber, buffer, 10); //this uses VC++ version
	//	filename += itoa(generationNumber);
	//	filename += "_best.nn";
	//	genesFile = fopen(filename.c_str(), "w");
	//	(*brainList.begin())->PrintGenesToFile(genesFile);
	//	fclose(genesFile);

	//	//wait a little while before starting the next generation; the file writing sometimes
	//	//messes up the beginning of the next generation since it takes a while to write.
	//	std::cout << std::endl << "=====================================" << std::endl;
	//	std::cout << "Writing data to output files..." << std::endl;
	//	std::cout << "=====================================" << std::endl << std::endl;

	//	//float waitValue = 4;
	//	//while (waitValue >=0)
	//	//{
	//	//	waitValue -= timer->GetElapsedSeconds();
	//	//}
	//}

	//3. remove worst half
	for (int i=0; i<TEMP_POPULATION_SIZE/2; i++)
	{
		delete brainList.back();
		brainList.pop_back();
	}

	//4. create new genes by crossover and mutate them; add new brains to the list
	NNGeneString* newGenes1 = NULL;
	NNGeneString* newGenes2 = NULL;
	std::list<NeuralNet*>::iterator brainIter2;
	NeuralNet* brainPtr;

	brainIter = brainList.begin();
	brainIter2 = brainList.begin();

	for (int i=0; i<TEMP_POPULATION_SIZE/4; i++)
	{
		//Getting number between 0 and population/2-1, inclusive.
		//This number will be the number of times to increment brainIter2.
		int randomNum = rand()%(TEMP_POPULATION_SIZE/2);

		for (int j=0; j<randomNum; j++)
		{
			brainIter2++; //randomly choosing mate for brainIter
		}

		CrossoverAndMutation((*brainIter), (*brainIter2), newGenes1, newGenes2);
		brainPtr = new NeuralNet(newGenes1, 0); //creating 1st new brain
		brainList.push_back(brainPtr);
		brainPtr = new NeuralNet(newGenes2, 0); //creating 2nd new brain
		brainList.push_back(brainPtr);
		brainIter++; //move to next brain
		brainIter2 = brainList.begin(); //reset this iterator
		delete newGenes1;
		delete newGenes2;
	}

	//reset things
	//brainIter = brainList.begin();
	//humanPtr->SetBrain(*brainIter);
	//generationNumber++;
}

void EvolutionController::StartTesting()
{
}

void EvolutionController::AddListener(Listener* listener)
{
	wxCriticalSectionLocker locker(mListenersCS);
	mListeners.push_back(listener);
}

void EvolutionController::RemoveListener(Listener* listener)
{
	wxCriticalSectionLocker locker(mListenersCS);
	std::vector<Listener*>::iterator iter;

	for (iter = mListeners.begin(); iter != mListeners.end(); iter++)
	{
		if (listener == (*iter))
		{
			mListeners.erase(iter);
			iter--;
		}
	}
}

void EvolutionController::FireEvent(ListenerEvent event, int value)
{
	wxCriticalSectionLocker locker(mListenersCS);
	std::vector<Listener*>::iterator iter;
	
	for (iter = mListeners.begin(); iter != mListeners.end(); iter++)
	{
		// Block execution until the main thread leaves the GUI library.  These
		// Mutex calls must NOT be called if there are no listeners (GUI has
		// already been destroyed).
		::wxMutexGuiEnter();
		(*iter)->HandleEvent(event, value);
		::wxMutexGuiLeave();
	}
}

void EvolutionController::CreateFitnessFunction()
{
	wxCriticalSectionLocker locker(mFitnessFunctionCS);

	switch(mExperimentParameters.fitnessType)
	{
		case FITNESS_FUNCTION_STANDING:
			mFitnessFunction = new StandingFitnessFunction();
			break;
		case FITNESS_FUNCTION_JUMPING:
			//mFitnessFunction = new JumpingFitnessFunction();
			break;
		case FITNESS_FUNCTION_WALKING:
			//mFitnessFunction = new WalkingFitnessFunction();
			break;
		default:
			assert(false);
			break;
	}
}
void EvolutionController::DestroyFitnessFunction()
{
	wxCriticalSectionLocker locker(mFitnessFunctionCS);
	
	if (NULL != mFitnessFunction)
	{
		delete mFitnessFunction;
		mFitnessFunction = NULL;
	}
}


//OLD_AVH_CODE//////////////////////////////
bool ComparisonFunction(NeuralNet* a, NeuralNet* b)
{
	return (a->GetFitness() > b->GetFitness());
}
//////////////////////////////////////////
