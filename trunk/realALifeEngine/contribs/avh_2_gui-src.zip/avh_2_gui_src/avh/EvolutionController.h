#ifndef __AVH_EVOLUTION_CONTROLLER_H__
#define __AVH_EVOLUTION_CONTROLLER_H__

#include <iostream>
#include <assert.h>
#include <vector>
#include <list>

#include <wx/thread.h>

//#include "avhApp.h"
#include "Listener.h"
#include "StandingFitnessFunction.h"

enum EvolutionMode
{
	EVOLUTION_TRAINING,
	EVOLUTION_TESTING
};

enum EvolutionState
{
	EVOLUTION_OFF,
	EVOLUTION_RUNNING
};

struct ExperimentParameters
{
	EvolutionMode mode;
   FitnessType fitnessType;
   int numGenerations;
   int numRuns;
   int popSize;
   int savePeriod;
	std::string testingFilename;
};

#define TEMP_POPULATION_SIZE 8

//Description: EvolutionController is a singleton object in control of
//the entire evolution process.  It also has functions to test advanced
//individuals on various fitness functions.  It should not deal with
//the SimulationController or the GraphicsController at all (they will
//be updated in the FitnessFunction).

class EvolutionController
{
public:
	static EvolutionController* Instance();
	void Start();
	void RequestStop()
	{
		wxCriticalSectionLocker locker(mFitnessFunctionCS);
		//SetStopRequested(true);

		assert(mFitnessFunction);

		mFitnessFunction->SetStopRequested(true);
	}

	void SetExperimentParameters(const ExperimentParameters& params)
	{
		wxCriticalSectionLocker locker(mEvolutionParametersCS);
		mExperimentParameters.mode = params.mode;
		mExperimentParameters.fitnessType = params.fitnessType;
		mExperimentParameters.numGenerations = params.numGenerations;
		mExperimentParameters.numRuns = params.numRuns;
		mExperimentParameters.popSize = params.popSize;
		mExperimentParameters.savePeriod = params.savePeriod;
		mExperimentParameters.testingFilename = params.testingFilename;
	}
	ExperimentParameters GetExperimentParameters()
	{
		wxCriticalSectionLocker locker(mEvolutionParametersCS);
		return mExperimentParameters;
	}
	EvolutionState GetState() 
	{
		wxCriticalSectionLocker locker(mEvolutionStateCS);
		return mEvolutionState;
	}
	void SetState(EvolutionState newState) //State should only be changed by EvolutionThread.
	{
		wxCriticalSectionLocker locker(mEvolutionStateCS);
		mEvolutionState = newState;
	}

	//Functions dealing with listeners
   void AddListener(Listener* listener);
   void RemoveListener(Listener* listener);
	void FireEvent(ListenerEvent event, int value);

private:
	EvolutionController();
	~EvolutionController(){;}

	void StartTraining();
	bool EvolutionEpoch(int generationNumber);
	void TempPopulationEpoch();
	void CreatePopulation();
	void DestroyPopulation();
	void StartTesting();
	void CreateFitnessFunction();
	void DestroyFitnessFunction();
	void ResetEvolution();

	float GetProgress()
	{
		wxCriticalSectionLocker locker(mProgressCS);
		return mProgress;
	}

	void SetProgress(float percentDone)
	{
		wxCriticalSectionLocker locker(mProgressCS);
		mProgress = percentDone;
	}
	//bool GetStopRequested()
	//{
	//	wxCriticalSectionLocker locker(mStopRequestedCS);
	//	return mStopRequested;
	//}

	//void SetStopRequested(bool stopRequested)
	//{
	//	wxCriticalSectionLocker locker(mStopRequestedCS);
	//	mStopRequested = stopRequested;
	//}
	//bool GetFitnessFunction()
	//{
	//	wxCriticalSectionLocker locker(mFitnessFunctionCS);
	//	return mFitnessFunction;
	//}
	void SetFitnessFunction(FitnessFunction* fitnessFunction)
	{
		wxCriticalSectionLocker locker(mFitnessFunctionCS);
		mFitnessFunction = fitnessFunction;
	}

	//All sections that access data that COULD be accessed by another thread should use
	//critical section objects.

	//Population* mPopulation;
   //wxCriticalSection mPopulationCS;

	FitnessFunction* mFitnessFunction;
   wxCriticalSection mFitnessFunctionCS;
 
   std::vector<Listener*> mListeners;
   wxCriticalSection mListenersCS;

	//bool mStopRequested;
	//wxCriticalSection mStopRequestedCS;

	EvolutionState mEvolutionState;
	wxCriticalSection mEvolutionStateCS;

	float mProgress;
	wxCriticalSection mProgressCS;

	ExperimentParameters mExperimentParameters;
	wxCriticalSection mEvolutionParametersCS;

	//track time spent in training to give users an estimate of time remaining...
	//float mElapsedTime;
	//wxCriticalSection mElapsedTimeCS;

	//OLD_AVH_CODE///////////////////////////
	std::list<NeuralNet*> brainList;
	std::list<NeuralNet*>::iterator brainIter;
	//////////////////////////////////////
};

//OLD_AVH_CODE//////////////////////////////
bool ComparisonFunction(NeuralNet* a, NeuralNet* b);
///////////////////////////////////////////////

#endif
