#include "EvolutionThread.h"

void* EvolutionThread::Entry()
{
	std::cout << "Starting new thread." << std::endl;
	EvolutionController::Instance()->SetState(EVOLUTION_RUNNING);
	EvolutionController::Instance()->FireEvent(LISTENER_START_EVENT, 0);

   EvolutionController::Instance()->Start();

	EvolutionController::Instance()->SetState(EVOLUTION_OFF);
	EvolutionController::Instance()->FireEvent(LISTENER_STOP_EVENT, 0);
   std::cout << "Thread exiting..." << std::endl;
	return NULL;
}
