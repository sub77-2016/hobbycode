#ifndef __AVH_EVOLUTION_THREAD_H__
#define __AVH_EVOLUTION_THREAD_H__

#include <wx/thread.h>
#include "EvolutionController.h"

//Description: EvolutionThread simply exists to allow the evolution
//process (including visualization) to run in a separate thread
//from the GUI.

class EvolutionThread : public wxThread
{
public:
	~EvolutionThread(){;}
   ExitCode Entry();
};

#endif
