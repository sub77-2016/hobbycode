#ifndef __AVH_FITNESS_FUNCTION_H__
#define __AVH_FITNESS_FUNCTION_H__

#include <list>
#include <wx/thread.h>
#include "../common/AI/NeuralNet.h"
#include "GraphicsController.h"

#define SIMULATION_FRAME_TIME 1.0 //Amount of time to simulate each frame when not in real-time

enum FitnessType
{
	FITNESS_FUNCTION_STANDING,
	FITNESS_FUNCTION_JUMPING,
	FITNESS_FUNCTION_WALKING
};

//Description: FitnessFunction is a base class for all other
//fitness function objects.

class FitnessFunction
{
public:
	FitnessFunction()
	{
		mStopRequested = false;
	}
	//virtual ~FitnessFunction(){;}

	virtual bool EvaluatePopulation(std::list<NeuralNet*> brainList) = 0;
	//virtual void TestIndividual(NeuralNet* nn) = 0;

	bool GetStopRequested()
	{
		wxCriticalSectionLocker locker(mStopRequestedCS);
		return mStopRequested;
	}

	void SetStopRequested(bool stopRequested)
	{
		wxCriticalSectionLocker locker(mStopRequestedCS);
		mStopRequested = stopRequested;
	}

protected:
	virtual bool EvaluateIndividual(NeuralNet* nn) = 0;
	virtual void SetupEnvironment() = 0;
	virtual void DestroyEnvironment() = 0;

	bool mStopRequested;
	wxCriticalSection mStopRequestedCS;

	long int mMaxTimeSteps;
};

#endif
