#include "GraphicsController.h"

GraphicsController* GraphicsController::Instance()
{
   static GraphicsController* instance = NULL;
   
   if (instance == NULL)
   {
      instance = new GraphicsController();
   }

   return instance;
}

GraphicsController::GraphicsController()
{
	SetVisualMode(false);
	RequestVisualMode(false);
	mLightSource = NULL;
	InitializeVariables();

	//Most variables will be reinitialized inInitSDL() where InitializeVariables
	//is called.  This ensures that they get reset every time a new SDL window 
	//is created.
}

void GraphicsController::InitializeVariables()
{
	mWindowWidth = 640;
	mWindowHeight = 480;
	mAspectRatio = (float)mWindowWidth/(float)mWindowHeight;
	mCameraRotX = 0.0;
	mCameraRotY = 0.0;
	mCameraZoom = -30.0;
	mOldMousePos[0] = 0;
	mOldMousePos[1] = 0;
	mMouseButtonsPressed[0] = false;
	mMouseButtonsPressed[1] = false;
}

GraphicsController::~GraphicsController()
{
	ShutdownSDL();
}

void GraphicsController::ShutdownSDL()
{
	wxCriticalSectionLocker locker(mSDLCS);

	if(0 != SDL_WasInit(SDL_SYSTEMS_USED))
	{
		SDL_Quit();
	}

	DestroyLight();
}

void GraphicsController::InitSDL()
{
	wxCriticalSectionLocker locker(mSDLCS);

	//atexit(SDL_Quit); //SDL_Quit shouldn't get called more than once...
	//"using atexit in a library is a sure way to crash dynamically loaded code"

	////first create wxFrame for SDL to use...
	//wxFrame* sdlFrame = new wxFrame(this, -1, "SDL Test Window", wxPoint(250,250), wxSize(200,200));
	//sdlFrame->Show(true);

	//HWND sdlwnd;
	//sdlwnd = ((HWND)(sdlFrame->GetHandle()));
	//::SetFocus(sdlwnd);

 //  char windowid[100];
 //  strcpy(windowid, "SDL_WINDOWID=");
 //  _ltoa((long)sdlwnd, windowid+13, 10);
 //  _putenv(windowid);
	//_putenv("SDL_VIDEODRIVER=windib");

	//Initialize SDL
	if (SDL_Init(SDL_SYSTEMS_USED) < 0)
	{
		fprintf(stderr, "SDL initialization failed: %s\n", SDL_GetError());
		SDL_Quit();
		return;
		//::wxExit();
	}

	////Setup video mode
	//SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5 //Size of the framebuffer red component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5  //Size of the framebuffer green component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5 //Size of the framebuffer blue component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE,  //Size of the framebuffer alpha component, in bits 
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);  //0 or 1, enable or disable double buffering 
	//SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE,  //Size of the framebuffer, in bits 
	//SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,  //Size of the depth buffer, in bits 
	//SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE,  //Size of the stencil buffer, in bits 
	//SDL_GL_SetAttribute(SDL_GL_ACCUM_RED_SIZE,  //Size of the accumulation buffer red component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_ACCUM_GREEN_SIZE,  //Size of the accumulation buffer green component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_ACCUM_BLUE_SIZE,  //Size of the accumulation buffer blue component, in bits 
	//SDL_GL_SetAttribute(SDL_GL_ACCUM_ALPHA_SIZE,  //Size of the accumulation buffer alpha component, in bits

	SDL_Surface *SDLSurface = SDL_SetVideoMode(mWindowWidth, mWindowHeight, 0, SDL_OPENGL|SDL_RESIZABLE);
	//mSDLSurface = SDL_SetVideoMode(screenWidth, screenHeight, 0, SDL_ANYFORMAT|SDL_OPENGL|SDL_RESIZABLE);
	//SDL_Surface *screen = SDL_SetVideoMode(screenWidth, screenHeight, 0, SDL_ANYFORMAT|SDL_OPENGL|SDL_FULLSCREEN);

	if (NULL == SDLSurface)
	{
		fprintf(stderr, "Video mode initialization failed: %s\n", SDL_GetError());
		SDL_Quit();
		return;
		//::wxExit();
	}

	InitializeVariables();
	InitOpenGL();
	CreateLight();

	//SDL_PixelFormat *pf = NULL;
	//Uint32 black;
	//Uint32 red;
	//Uint32 green;
	//Uint32 blue;

	//// Grab the pixel format for the screen. SDL_MapRGB()
	//// needs the pixel format to create pixels that are laid
	//// out correctly for the screen.

	//pf = screen->format;

	////Create the pixel values used in the program. Black is
	////for clearing the background and the other three are
	////for line colors. Note that in SDL you specify color
	////intensities in the rang 0 to 255 (hex ff). That
	////doesn't mean that you always get 24 or 32 bits of
	////color. If the format doesn't support the full color
	////range, SDL scales it to the range that is correct for
	////the pixel format.

	//black = SDL_MapRGB(pf, 0x00, 0x00, 0x00);
	//red = SDL_MapRGB(pf, 0xff, 0x00, 0x00);
	//green = SDL_MapRGB(pf, 0x00, 0xff, 0x00);
	//blue = SDL_MapRGB(pf, 0x00, 0x00, 0xff);


	// Set the window caption and the icon caption for the
	// program. In this case I'm just setting it to whatever
	// the name of the program happens to be.
	//char *name = argv[0];
	SDL_WM_SetCaption("Training Visualization", "Training Visualization");

	//SDL_ShowCursor(SDL_ENABLE);
	//SDL_SetEventFilter(E_FILTER);
	//SDL_EnableKeyRepeat(0,1);
}

void GraphicsController::InitOpenGL()
{
	//glClearColor(0.9, 0.9, 0.8, 1.0);
	glColor3f(0.0, 0.0, 0.0);
	glPointSize(4.0);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40.0, mAspectRatio, 1, 5000.0);
	glMatrixMode(GL_MODELVIEW);

	glEnable(GL_TEXTURE_2D);	// Turn on texture mapping
	glEnable(GL_DEPTH_TEST);

	glCullFace(GL_BACK); // don't draw the back of faces
	glEnable(GL_CULL_FACE);
	glEnable(GL_NORMALIZE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 0); //don't light the back of faces
	glEnable(GL_LIGHTING);

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	//creating light source
	//lightPtr = new LightObject(0, -30, 10, 30);

	//float matAmbientAndDiffuse[4] = {.5, .5, .5, 1};
	//float matSpecular[4] = {1, 1, 1, 1};
	//float matShininess = 60;

	//glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbientAndDiffuse);
	//glMaterialfv(GL_FRONT, GL_SPECULAR, matSpecular);
	//glMaterialf(GL_FRONT, GL_SHININESS, matShininess);

	//GLfloat ambient[] =  {0.1f, 0.1f, 0.1f, 1.0f};
	//GLfloat diffuse[] =  {.8f, .8f, 0.8f, 1.0f};
	//GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
	//GLfloat light_position[] = {20.0f, 20.0f, 30.0f, 0.0f};

	//glEnable(GL_LIGHTING);
	//glEnable(GL_LIGHT0);
	//glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	//glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	//glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	//glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	//make display lists here
	//humanPtr->MakeDisplayList();
}

void GraphicsController::Update()
{
	//Check if we should init or shutdown SDL
	if (true == GetVisualModeRequested() && false == GetVisualMode())
	{
		//visual requested, but currently not visual
		SetVisualMode(true);
		InitSDL();
	}
	else if (false == GetVisualModeRequested() && true == GetVisualMode())
	{
		//requested no visual mode, but currently in visual mode
		SetVisualMode(false);
		ShutdownSDL();
		return;
	}
	else if (false == GetVisualModeRequested() && false == GetVisualMode())
	{
		//requested no visual mode, not currently visual
		return;
	}

	wxCriticalSectionLocker locker(mSDLCS);

	SDL_Event event;

	while (SDL_PollEvent(&event)) //handle events until event queue is empty
	{
		switch(event.type)
		{
			case SDL_MOUSEBUTTONDOWN:
			{
				int clickPosX = event.button.x;
				int clickPosY = mWindowHeight - event.button.y;

				switch (event.button.button)
				{
					case SDL_BUTTON_LEFT:
						//std::cout << "Button 1 pressed" << std::endl;
						//if (event.button.state == SDL_PRESSED)
						//{
							mMouseButtonsPressed[0] = true;
							mOldMousePos[0] = clickPosX;
							mOldMousePos[1] = clickPosY;
						//}
						break;
					case SDL_BUTTON_RIGHT:
						//std::cout << "Button 3 pressed" << std::endl;
						//if (event.button.state == SDL_PRESSED)
						//{
							mMouseButtonsPressed[1] = true;
							mOldMousePos[0] = clickPosX;
							mOldMousePos[1] = clickPosY;
						//}
						break;
					case SDL_BUTTON_MIDDLE:
						//std::cout << "Button 2 pressed" << std::endl;
						break;
					default:				
						break;
				}
				break;
			}
			case SDL_MOUSEBUTTONUP:
			{
				switch (event.button.button)
				{
					case SDL_BUTTON_LEFT:
						//std::cout << "Button 1 released" << std::endl;
						mMouseButtonsPressed[0] = false;
						break;
					case SDL_BUTTON_RIGHT:
						//std::cout << "Button 3 released" << std::endl;
						mMouseButtonsPressed[1] = false;
						break;
					case SDL_BUTTON_MIDDLE:
						//std::cout << "Button 2 released" << std::endl;
						break;
					default:				
						break;
				}
				break;
			}
			case SDL_MOUSEMOTION:
			{
				//arguments: x, y
				int clickPosX = event.button.x;
				int clickPosY = mWindowHeight - event.button.y;

				int deltaMouse[2];
				deltaMouse[0] = clickPosX - mOldMousePos[0];
				deltaMouse[1] = clickPosY - mOldMousePos[1];

				mOldMousePos[0] = clickPosX;
				mOldMousePos[1] = clickPosY;

				if (mMouseButtonsPressed[0] == true)
				{
					mCameraRotY += double(deltaMouse[0])/5.0;
					mCameraRotX -= double(deltaMouse[1])/5.0;
				}
				if (mMouseButtonsPressed[1]==true)
				{
 					mCameraZoom -= double(deltaMouse[1])/5.0;
				}

				break;
			}
			//case SDL_KEYDOWN:
			//{
			//	switch(event.key.keysym.sym)
			//	{
			//		case SDLK_ESCAPE:
			//			break;
			//		case SDLK_q:
			//			break;
			//		default:
			//			break;
			//	}
			//	break;
			//}
			//case SDL_QUIT:
			//{
			//	break;
			//}
			case SDL_VIDEORESIZE:
			{
				mWindowWidth = event.resize.w;
				mWindowHeight = event.resize.h;
				float mAspectRatio = (float)mWindowWidth/(float)mWindowHeight;
				glViewport(0, 0, mWindowWidth, mWindowHeight);
				glMatrixMode(GL_PROJECTION);
				glLoadIdentity();
				gluPerspective(40.0, mAspectRatio, 1, 5000.0);
				glMatrixMode(GL_MODELVIEW);
				break;
			}
			default:
				break;
		}
	}

	glClearColor(0.8, 0.8, 0.7, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();

	glTranslatef(0.0, -5, mCameraZoom); // move camera back
	glRotatef(mCameraRotX, 1, 0, 0);
	glRotatef(mCameraRotY, 0, 1, 0);

	assert (mLightSource);
	mLightSource->Draw(); //reposition the light source

	SimulationController::Instance()->DrawObjects();

	SDL_GL_SwapBuffers();
}

void GraphicsController::CreateLight()
{
	assert (NULL == mLightSource);

	mLightSource = new LightObject(0, -30, 10, 30);
	//SimulationController::Instance()->AddObject(lightPtr);
}

void GraphicsController::DestroyLight()
{
	assert (mLightSource);

	delete mLightSource;
}