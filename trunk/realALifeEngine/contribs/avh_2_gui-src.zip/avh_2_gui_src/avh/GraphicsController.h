#ifndef __AVH_GRAPHICS_CONTROLLER_H__
#define __AVH_GRAPHICS_CONTROLLER_H__

#include <iostream>
#include <assert.h>

#include <wx/thread.h>

#ifdef WIN32
#include <windows.h>
#endif

#include <sdl/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include "SimulationController.h"
#include "../common/graphics/LightObject.h"

#define SDL_SYSTEMS_USED SDL_INIT_VIDEO
//other possibilities: 
//SDL_INIT_AUDIO Initializes the audio subsystem. 
//SDL_INIT_CDROM Initializes the cdrom subsystem. 
//SDL_INIT_JOYSTICK Initializes the joystick subsystem. 
//SDL_INIT_EVERYTHING Initialize all of the above. 
//SDL_INIT_NOPARACHUTE Prevents SDL from catching fatal signals. 
//SDL_INIT_EVENTTHREAD not for win32; fixes multithreading problems in unix?
//SDL_INIT_TIMER

//Description: GraphicsController is a singleton object that handles
//all graphics output.  Since we are using SDL for now, it also handles
//input event handling.

class GraphicsController
{
public:
	static GraphicsController* Instance();
	void Update();
	void RequestVisualMode(bool isVisual)
	{
		wxCriticalSectionLocker locker(mVisualModeRequestedCS);
		mVisualModeRequested = isVisual;
	}
	bool GetVisualModeRequested()
	{
		wxCriticalSectionLocker locker(mVisualModeRequestedCS);
		return mVisualModeRequested;
	}
	bool GetVisualMode()
	{
		wxCriticalSectionLocker locker(mVisualModeCS);
		return mVisualMode;
	}

private:
	GraphicsController();
	~GraphicsController();

	void InitSDL();
	void ShutdownSDL();
	void InitOpenGL();
	void InitializeVariables();
	void CreateLight(); //This must happen after OpenGL is initialized.
	void DestroyLight();

	void SetVisualMode(bool isEnabled)
	{
		wxCriticalSectionLocker locker(mVisualModeCS);
		mVisualMode = isEnabled;
	}

	bool mVisualMode;
	wxCriticalSection mVisualModeCS;

	bool mVisualModeRequested;
	wxCriticalSection mVisualModeRequestedCS;

	wxCriticalSection mSDLCS;

	LightObject* mLightSource;
	int mWindowWidth;
	int mWindowHeight;
	float mAspectRatio;
	float mCameraRotX;
	float mCameraRotY;
	float mCameraZoom;
	int mOldMousePos[2];
	bool mMouseButtonsPressed[2];
};

#endif
