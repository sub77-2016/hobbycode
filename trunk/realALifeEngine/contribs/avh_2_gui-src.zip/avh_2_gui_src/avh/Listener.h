#ifndef __AVH_LISTENER_H__
#define __AVH_LISTENER_H__

enum ListenerEvent
{
	LISTENER_START_EVENT,
	LISTENER_STOP_EVENT,
	LISTENER_PROGRESS_EVENT
};

class Listener
{
public:
   //virtual void UpdateProgress(int val) = 0;
   //virtual void StopEvent(int val) = 0;
   //virtual void StartEvent(int val) = 0;
	virtual void HandleEvent(ListenerEvent event, int value) = 0;
};

#endif
