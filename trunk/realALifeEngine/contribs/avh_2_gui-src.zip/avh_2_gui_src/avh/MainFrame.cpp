// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "MainFrame.h"

enum MainFrameID
{
	ID_CLEAR_LOG=1,
	ID_ABOUT,
	ID_QUIT
};

BEGIN_EVENT_TABLE(MainFrame, wxFrame)
	EVT_MENU(ID_QUIT, MainFrame::OnQuit)
	EVT_MENU(ID_ABOUT, MainFrame::OnAbout)
	EVT_MENU(ID_CLEAR_LOG,  MainFrame::OnClearLog)
	//EVT_CLOSE(OnClose)
END_EVENT_TABLE()

MainFrame::MainFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
: wxFrame((wxFrame*)NULL, -1, title, pos, size, wxMINIMIZE_BOX|wxSYSTEM_MENU|wxCAPTION)
{
	wxMenu *fileMenu = new wxMenu;

	fileMenu->Append(ID_CLEAR_LOG, wxT("&Clear log"));
	fileMenu->Append(ID_ABOUT, wxT("&About..."));
	fileMenu->AppendSeparator();
	fileMenu->Append(ID_QUIT, wxT("E&xit"));

	wxMenuBar *menuBar = new wxMenuBar;
	menuBar->Append(fileMenu, wxT("&File"));

	SetMenuBar(menuBar);

	mPanel = new MainPanel(this, 10, 10, 10, 10); //this will get resized automatically

	//CreateStatusBar();
	//SetStatusText("Welcome to wxWindows!");
}

MainFrame::~MainFrame()
{
}

void MainFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
	Close(true);
}

void MainFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
	wxString s = "Autonomous Virtual Humans, 2004\nVersion 0.3\n\n";
	s += "Tyler Streeter (tylerstreeter@yahoo.com)\nwww.vrac.iastate.edu/~streeter";
	wxMessageBox(s, "About AVH", wxOK | wxICON_INFORMATION, this);
}

void MainFrame::OnClearLog(wxCommandEvent& WXUNUSED(event))
{
    mPanel->ClearLogText();
}

//void MainFrame::UpdateGUI()
//{
//	if (NULL != mPanel)
//	{
//		mPanel->UpdateGUI();
//	}
//}