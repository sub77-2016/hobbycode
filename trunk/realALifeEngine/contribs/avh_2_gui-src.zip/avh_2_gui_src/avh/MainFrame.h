#ifndef __AVH_MAIN_FRAME_H__
#define __AVH_MAIN_FRAME_H__

#include "MainPanel.h"
#include <wx/frame.h>

//Description: MainFrame is the only wxFrame (the "foundation" for
//the GUI) used in avhApp.  The frame contains a wxPanel which actually
//contains most of the widgets.

class MainFrame : public wxFrame
{
public:
	MainFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
	~MainFrame();
	void OnClearLog(wxCommandEvent& event);
	void OnAbout(wxCommandEvent& event);
	void OnQuit(wxCommandEvent& event);
	//void OnClose(wxCloseEvent& event);
	//void UpdateGUI();

private:
	MainPanel *mPanel;

	DECLARE_EVENT_TABLE()
};

#endif