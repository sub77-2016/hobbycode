// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "MainPanel.h"

enum MainPanelID
{
	ID_NOTEBOOK=1,
	ID_PICK_DIR_BUTTON,
	ID_SAVE_OUTPUT_CHECKBOX,
	ID_BEGIN_TRAINING_BUTTON,
	ID_STOP_TRAINING_BUTTON,
	ID_VISUAL_MODE_BUTTON,
	ID_FAST_MODE_BUTTON,
	ID_BEGIN_TESTING_BUTTON
};

BEGIN_EVENT_TABLE(MainPanel, wxPanel)
	EVT_SIZE(MainPanel::OnSize)
	//EVT_NOTEBOOK_PAGE_CHANGING(ID_NOTEBOOK, MainPanel::OnPageChanging)
	EVT_NOTEBOOK_PAGE_CHANGED(ID_NOTEBOOK,  MainPanel::OnPageChanged)
	EVT_BUTTON(ID_PICK_DIR_BUTTON, MainPanel::OnPickDir)
	EVT_CHECKBOX(ID_SAVE_OUTPUT_CHECKBOX, MainPanel::OnSaveOutput)
	EVT_BUTTON(ID_BEGIN_TRAINING_BUTTON, MainPanel::OnBeginTraining)
	EVT_BUTTON(ID_STOP_TRAINING_BUTTON, MainPanel::OnStopTraining)
	EVT_BUTTON(ID_VISUAL_MODE_BUTTON, MainPanel::OnVisualMode)
	EVT_BUTTON(ID_FAST_MODE_BUTTON, MainPanel::OnFastMode)
	EVT_BUTTON(ID_BEGIN_TESTING_BUTTON, MainPanel::OnBeginTesting)
	//EVT_IDLE(MainPanel::OnIdle)
END_EVENT_TABLE()

MainPanel::MainPanel(wxFrame *frame, int x, int y, int w, int h)
: wxPanel(frame, -1, wxPoint(x, y), wxSize(w, h))
{
	mNotebook = NULL;
	mLogText = NULL;
	mOutputRedirector = NULL;

	//Training Utility Controls
	mTrainingFitnessFunction = NULL;
	mPopulationSize = NULL;
	mNumGenerations = NULL;
	mNumRuns = NULL;
	mSaveOutput = NULL;
	mExperimentName = NULL;
	mPickDirButton = NULL;
	mExperimentDirDlg = NULL;
	mSavePeriod = NULL;
	mBeginTraining = NULL;
	mStopTraining = NULL;
	mVisualModeButton = NULL;
	mFastModeButton = NULL;
	mProgressBar = NULL;
	mTrainingFitnessFunctionText = NULL;
	mPopulationSizeText = NULL;
	mNumGenerationsText = NULL;
	mNumRunsText = NULL;
	mExperimentNameText = NULL;
	mExperimentDirDlgText = NULL;
	mSavePeriodText1 = NULL;
	mSavePeriodText2 = NULL;

	//Testing Utility Controls
	//mTestingFitnessFunction = NULL;

	wxString fitnessFunctionChoices[] =
	{
		wxT("Standing"),
		wxT("Jumping"),
		wxT("Walking")
	};

	mNumFitnessFunctions = 3;
	//mVisualMode = false;

	mLogText = new wxTextCtrl(this, -1, wxT(""),
		wxPoint(0, 250), wxSize(100, 50), wxTE_MULTILINE|wxTE_READONLY);
	mLogText->SetBackgroundColour(wxT("wheat"));

	//Create wxNotebook, the parent of the different tab windows
	mNotebook = new wxNotebook(this, ID_NOTEBOOK);

	//Now creating panels, setting a wxNotebook as parent window; these panels will
	//get deleted automatically as children of the wxNotebook.

	//creating training panel
	wxPanel *panel = new wxPanel(mNotebook);

	/***************************STATIC BOX 1**************************************/
	mStaticBox1 = new wxStaticBox(this, -1, wxT("Genetic Algorithm Parameters"), 
		wxPoint(10,35),wxSize(210,150));

	mTrainingFitnessFunction = new wxChoice(panel, -1, wxPoint(15,35), wxSize(80,-1),
		mNumFitnessFunctions, fitnessFunctionChoices);
	mTrainingFitnessFunction->SetSelection(0);

	mTrainingFitnessFunctionText = new wxStaticText(panel,-1,wxT("Fitness Function"),
		wxPoint(100,38),wxSize(-1,-1));

	mPopulationSize = new wxSpinCtrl(panel,-1,wxT("64"),wxPoint(15,65),wxSize(80,-1));
	mPopulationSize->SetRange(4,10000);

	mPopulationSizeText = new wxStaticText(panel,-1,wxT("Population Size"),
		wxPoint(100,68),wxSize(-1,-1));

	mNumGenerations = new wxSpinCtrl(panel,-1,wxT("1000"),wxPoint(15,95),wxSize(80,-1));
	mNumGenerations->SetRange(1,4000);

	mNumGenerationsText = new wxStaticText(panel,-1,wxT("Generations Per Run"),
		wxPoint(100,98),wxSize(-1,-1));

	mNumRuns = new wxSpinCtrl(panel,-1,wxT(""),wxPoint(15,125),wxSize(80,-1));
	mNumRuns->SetRange(1,100);
	mNumRuns->SetValue(5);

	mNumRunsText = new wxStaticText(panel,-1,wxT("Number of Runs"),
		wxPoint(100,128),wxSize(-1,-1));

	/***************************STATIC BOX 2**************************************/
	mStaticBox2 = new wxStaticBox(this,-1, wxT("File Output"), 
		wxPoint(230,35),wxSize(250,150));

	mSaveOutput = new wxCheckBox(panel, ID_SAVE_OUTPUT_CHECKBOX, 
		wxT("Save Output Files (Statistics, Champions)"), wxPoint(240,35));
	mSaveOutput->SetValue(true);

	mExperimentName = new wxTextCtrl(panel, -1, wxT(""), wxPoint(340,65), wxSize(80,-1));

	mExperimentNameText = new wxStaticText(panel,-1,wxT("Experiment Name"),
		wxPoint(240,68),wxSize(-1,-1));

	mPickDirButton = new wxButton(panel,ID_PICK_DIR_BUTTON,wxT("Browse..."),wxPoint(340,95),wxSize(80,-1));

	mExperimentDirDlgText = new wxStaticText(panel,-1,wxT("Output Directory"),
		wxPoint(240,98),wxSize(-1,-1));

	mSavePeriod = new wxSpinCtrl(panel,-1,wxT("10"),wxPoint(350,125),wxSize(50,-1));
	mSavePeriod->SetRange(1,1000);

	mSavePeriodText1 = new wxStaticText(panel,-1,wxT("Save Champion Every"),
		wxPoint(240,128),wxSize(-1,-1));
	mSavePeriodText2 = new wxStaticText(panel,-1,wxT("Generations"),
		wxPoint(407,128),wxSize(-1,-1));

	/***************************STATIC BOX 3**************************************/
	mStaticBox3 = new wxStaticBox(this,-1, wxT(""), 
		wxPoint(10,185),wxSize(470,77));

	mBeginTraining = new wxButton(panel,ID_BEGIN_TRAINING_BUTTON,wxT("Begin Training"),wxPoint(18,180),wxSize(90,-1));
	mStopTraining = new wxButton(panel,ID_STOP_TRAINING_BUTTON,wxT("Stop Training"),wxPoint(118,180),wxSize(90,-1));
	mStopTraining->Disable();

	mFastModeButton = new wxButton(panel,ID_FAST_MODE_BUTTON,wxT("Fast Mode"),wxPoint(270,180),wxSize(90,-1));
	mFastModeButton->Disable();
	mVisualModeButton = new wxButton(panel,ID_VISUAL_MODE_BUTTON,wxT("Visual Mode"),wxPoint(370,180),wxSize(90,-1));
	mVisualModeButton->Disable();

	mProgressBar = new wxGauge(panel, -1, 100, wxPoint(30,210), wxSize(420, 20), wxGA_HORIZONTAL|wxGA_SMOOTH);
	//mProgressBar->SetForegroundColour(*wxRED);

	mNotebook->AddPage(panel, wxT("Training"), true);

	//creating training panel
	panel = new wxPanel(mNotebook);

	//The following controls will be automatically added to panel.

	mNotebook->AddPage(panel, wxT("Testing"), false);


	//Output Redirection:
	//Some compilers and/or build configurations don't support multiply inheriting wxTextCtrl 
	//from std::streambuf in which case this class is not compiled in. You also must have 
	//wxUSE_STD_IOSTREAM option on (i.e. set to 1) in your setup.h to be able to use it. Under Unix, 
	//specify --enable-std_iostreams switch when running configure for this.

	mOutputRedirector = new wxStreamToTextRedirector(mLogText);

	EvolutionController::Instance()->AddListener(this);
}

MainPanel::~MainPanel()
{
	EvolutionController::Instance()->RemoveListener(this);

	//All wxWindow objects delete themselves.  Delete everything
	//else explicitly.

	delete mOutputRedirector;
	mOutputRedirector = NULL;

	EvolutionController::Instance()->RequestStop();
}

void MainPanel::ClearLogText()
{
    mLogText->Clear();
}

void MainPanel::OnSize(wxSizeEvent& WXUNUSED(event))
{
	int x = 0;
	int y = 0;
	GetClientSize(&x,&y);

	if (mNotebook)
	{
		mNotebook->SetSize(2, 2, x-4, y/2-4);
	}
	if (mLogText) 
	{
		mLogText->SetSize(2, y/2+2, x-4, y/2-4);
	}
}

//If disabling tabs doesn't work, use this to intercept events
//when they shouldn't happen...
//void MainPanel::OnPageChanging( wxNotebookEvent &event )
//{
//    int selOld = event.GetOldSelection();
//    if ( selOld == 2 )
//    {
//        if ( wxMessageBox(_T("This demonstrates how a program may prevent the\n")
//                          _T("page change from taking place - if you select\n")
//                          _T("[No] the current page will stay the third one\n"),
//                          _T("Control sample"),
//                          wxICON_QUESTION | wxYES_NO, this) != wxYES )
//        {
//            event.Veto();
//
//            return;
//        }
//    }
//
//    *m_text << _T("Notebook selection is being changed from ") << selOld
//            << _T(" to ") << event.GetSelection()
//            << _T(" (current page from notebook is ")
//            << m_notebook->GetSelection() << _T(")\n");
//}

void MainPanel::OnPageChanged(wxNotebookEvent &event)
{
	//UpdateGUI();

	switch(event.GetSelection())
	{
		case 0: //Training Utility tab
			mStaticBox1->Refresh();
			mStaticBox2->Refresh();
			mStaticBox3->Refresh();
			break;
		case 1: //Testing Utility tab
			break;
		default:
			break;
	}
}

void MainPanel::OnPickDir(wxCommandEvent& event)
{
	//TODO
}

void MainPanel::OnSaveOutput(wxCommandEvent& event)
{
	if (mSaveOutput->IsChecked())
	{
		mExperimentName->Enable();
		mPickDirButton->Enable();
		mSavePeriod->Enable();
	}
	else
	{
		mExperimentName->Disable();
		mPickDirButton->Disable();
		mSavePeriod->Disable();
	}
}

void MainPanel::OnBeginTraining(wxCommandEvent& event)
{
	if (EvolutionController::Instance()->GetState() == EVOLUTION_RUNNING)
	{
		return;
	}

   //Check if population size is not a multiple of 4
	int popSize = mPopulationSize->GetValue();
   int remainder = popSize%4;
   if(0 != remainder)
   {
      char* tempString = new char[100];
      sprintf(tempString,"Population Size Must Be a Multiple of 4!\nPopulation Size Changed from %d to %d",
                                 popSize,popSize+4-remainder);
      mPopulationSize->SetValue(popSize+4-remainder);
      wxMessageBox(tempString);
   }

	//Create training parameters data structure
   ExperimentParameters params;
	params.mode = EVOLUTION_TRAINING;
	int fitnessType = mTrainingFitnessFunction->GetSelection();

	switch(fitnessType)
	{
		case 0:
			params.fitnessType = FITNESS_FUNCTION_STANDING;
			break;
		case 1:
			params.fitnessType = FITNESS_FUNCTION_JUMPING;
			break;
		case 2:
			params.fitnessType = FITNESS_FUNCTION_WALKING;
			break;
		default:
			break;
	}

	assert(params.fitnessType >= 0 && params.fitnessType <= mNumFitnessFunctions);

	params.numGenerations = mNumGenerations->GetValue();
	params.numRuns = mNumRuns->GetValue();
	params.popSize = mPopulationSize->GetValue();
	params.savePeriod = mSavePeriod->GetValue();

   //Set the training parameters to be used in next experiment
	EvolutionController::Instance()->SetExperimentParameters(params);

   //Create a thread to run the experiment
   EvolutionThread* thread = new EvolutionThread();
   thread->Create();
	//thread->SetPriority(60); //The evolution thread is much more important than the GUI thread.
   thread->Run();

	UpdateTrainingWidgets(EVOLUTION_RUNNING);
}

void MainPanel::OnStopTraining(wxCommandEvent& event)
{
	EvolutionController::Instance()->RequestStop();
}

void MainPanel::OnVisualMode(wxCommandEvent& event)
{
	GraphicsController::Instance()->RequestVisualMode(true);

	mFastModeButton->Enable();
	mVisualModeButton->Disable();
}

void MainPanel::OnFastMode(wxCommandEvent& event)
{
	GraphicsController::Instance()->RequestVisualMode(false);
	
	mFastModeButton->Disable();
	mVisualModeButton->Enable();
}

void MainPanel::OnBeginTesting(wxCommandEvent& event)
{
	//ExperimentParameters params;
	//params.mode = EVOLUTION_TESTING;
	//params.fitnessType = mTestingFitnessFunction->GetSelection();
	//params.testingFilename = (file dialog return value...); assert(NULL != filename)

 //  //Set the training parameters to be used in next experiment
	//EvolutionController::Instance()->SetExperimentParameters(params);

 //  //Create a thread to run the experiment
 //  EvolutionThread* thread = new EvolutionThread();
 //  thread->Create();
 //  thread->Run();

	//UpdateTestingWidgets(EVOLUTION_RUNNING);
}

//void MainPanel::OnIdle(wxIdleEvent& event)
//{
//	//UpdateGUI();
//
//	//if (EvolutionController::Instance()->GetState() == EVOLUTION_RUNNING)
//	//{
//	//	//continuously generate idle events to update GUI
//	//	event.RequestMore();
//	//}
//}

void MainPanel::HandleEvent(ListenerEvent event, int value)
{
	switch(event)
	{
		case LISTENER_START_EVENT:
			if (EVOLUTION_TRAINING == value)
			{
				UpdateTrainingWidgets(EVOLUTION_RUNNING);
			}
			else if (EVOLUTION_TESTING == value)
			{
				UpdateTestingWidgets(EVOLUTION_RUNNING);
			}
			else
			{
				assert(false);
			}
			break;
		case LISTENER_STOP_EVENT:
			if (EVOLUTION_TRAINING == value)
			{
				UpdateTrainingWidgets(EVOLUTION_OFF);
			}
			else if (EVOLUTION_TESTING == value)
			{
				UpdateTestingWidgets(EVOLUTION_OFF);
			}
			else
			{
				assert(false);
			}
			break;
		case LISTENER_PROGRESS_EVENT:
			mProgressBar->SetValue(value);
			break;
		default:
			assert(false);
	}
}

void MainPanel::UpdateTrainingWidgets(EvolutionState state)
{
	if (EVOLUTION_OFF == state)
	{
		mTrainingFitnessFunction->Enable();
		mPopulationSize->Enable();
		mNumGenerations->Enable();
		mNumRuns->Enable();

		mSaveOutput->Enable();
		if (mSaveOutput->IsChecked())
		{
			mExperimentName->Enable();
			mPickDirButton->Enable();
			mSavePeriod->Enable();
		}
		else
		{
			mExperimentName->Disable();
			mPickDirButton->Disable();
			mSavePeriod->Disable();
		}

		mBeginTraining->Enable();
		mStopTraining->Disable();
		mVisualModeButton->Disable();
		mFastModeButton->Disable();
	}
	else if (EVOLUTION_RUNNING == state)
	{
		mTrainingFitnessFunction->Disable();
		mPopulationSize->Disable();
		mNumGenerations->Disable();
		mNumRuns->Disable();
		mSaveOutput->Disable();
		mExperimentName->Disable();
		mPickDirButton->Disable();
		mSavePeriod->Disable();
		mBeginTraining->Disable();
		mStopTraining->Enable();
		mVisualModeButton->Enable();
		mFastModeButton->Disable();
	}
	else
	{
		assert(false);
	}
}

void MainPanel::UpdateTestingWidgets(EvolutionState state)
{

}
