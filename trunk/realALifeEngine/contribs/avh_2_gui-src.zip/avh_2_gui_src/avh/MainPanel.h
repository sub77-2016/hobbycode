#ifndef __AVH_MAIN_PANEL_H__
#define __AVH_MAIN_PANEL_H__

#include <wx/panel.h>
#include <wx/notebook.h>
#include <wx/choice.h>
#include <wx/spinctrl.h>
#include <wx/button.h>
#include <wx/gauge.h>
#include <wx/textdlg.h>
#include <wx/stattext.h>
#include <wx/dirdlg.h>
#include <wx/textctrl.h>
#include <wx/checkbox.h>
#include <wx/timer.h>

#include "EvolutionController.h"
#include "GraphicsController.h"
#include "EvolutionThread.h"
#include "Listener.h"

//Description: MainPanel is the only wxPanel used in avhApp.  It
//is located within the wxFrame and contains most of the GUI widgets.

class MainPanel : public wxPanel, public Listener
{
public:
	MainPanel(wxFrame *frame, int x, int y, int w, int h);
	~MainPanel();
	void ClearLogText();
	void HandleEvent(ListenerEvent event, int value);
	void OnSize(wxSizeEvent& WXUNUSED(event));
	//void OnIdle(wxIdleEvent& event);
	void OnPickDir(wxCommandEvent& event);
	void OnSaveOutput(wxCommandEvent& event);

	//Maybe use these if we can't disable tabs...
	void OnPageChanged(wxNotebookEvent &event);
	//void OnPageChanging(wxNotebookEvent &event);

	//Training Utility Event Handlers
	void OnBeginTraining(wxCommandEvent& event);
	void OnStopTraining(wxCommandEvent& event);
	void OnVisualMode(wxCommandEvent& event);
	void OnFastMode(wxCommandEvent& event);

	//Testing Utility Event Handlers
	void OnBeginTesting(wxCommandEvent& event);

private:
	void UpdateTrainingWidgets(EvolutionState state);
	void UpdateTestingWidgets(EvolutionState state);

	wxNotebook *mNotebook; //parent window of the different tabs
	wxTextCtrl *mLogText;
	wxStreamToTextRedirector* mOutputRedirector; //redirect std output to a wxTextCtrl

	//Training Utility Controls
	wxChoice* mTrainingFitnessFunction;
	wxSpinCtrl* mPopulationSize;
	wxSpinCtrl* mNumGenerations;
	wxSpinCtrl* mNumRuns;
	wxCheckBox* mSaveOutput;
	wxTextCtrl* mExperimentName;
	wxButton* mPickDirButton;
	wxDirDialog* mExperimentDirDlg;
	wxSpinCtrl* mSavePeriod;
	wxButton* mBeginTraining;
	wxButton* mStopTraining;
	wxButton* mVisualModeButton;
	wxButton* mFastModeButton; //Fast Mode is the default (no visuals)
	wxGauge* mProgressBar;
	wxStaticText* mTrainingFitnessFunctionText;
	wxStaticText* mPopulationSizeText;
	wxStaticText* mNumGenerationsText;
	wxStaticText* mNumRunsText;
	wxStaticText* mExperimentNameText;
	wxStaticText* mExperimentDirDlgText;
	wxStaticText* mSavePeriodText1;
	wxStaticText* mSavePeriodText2;
	//wxStaticText* mProgressBarText;
	wxStaticBox* mStaticBox1;
	wxStaticBox* mStaticBox2;
	wxStaticBox* mStaticBox3;

	//Testing Utility Controls
	//wxChoice* mTestingFitnessFunction;

	int mNumFitnessFunctions;
	//bool mVisualMode;
	//EvolutionThread* mThread;

	DECLARE_EVENT_TABLE()
};

#endif