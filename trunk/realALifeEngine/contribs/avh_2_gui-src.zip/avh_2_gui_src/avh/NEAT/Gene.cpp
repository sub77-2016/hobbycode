#include "Gene.h"

void Gene::print_to_file(ofstream &outFile) {
  outFile<<"gene ";
  //Start off with the trait number for this gene
  if ((lnk->linktrait)==0) outFile<<"0 ";
  else outFile<<((lnk->linktrait)->trait_id)<<" ";
  outFile<<(lnk->in_node)->node_id<<" ";
  outFile<<(lnk->out_node)->node_id<<" ";
  outFile<<(lnk->weight)<<" ";
  outFile<<(lnk->is_recurrent)<<" ";
  outFile<<innovation_num<<" ";
  outFile<<mutation_num<<" ";
  outFile<<enable<<endl;
}