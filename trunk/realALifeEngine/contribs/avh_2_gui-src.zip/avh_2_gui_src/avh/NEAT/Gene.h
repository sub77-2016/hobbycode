#ifndef __NEAT_GENE_H__
#define __NEAT_GENE_H__

#include "NEAT.h"

//Description: 

/* ----------------------------------------------------------------------- */
/* The Gene class in this system specifies a "Connection Gene." 
   Nodes are represented using the Node class, which serves as both
   a genotypic and phenotypic representation of nodes.
   Genetic Representation of connections uses this special class because
   it calls for special operations better served by a specific genetic 
   representation  */
/* A Gene object in this system specifies a link      */
/* between two nodes along with an "innovation number" which tells when    */
/* in the history of a population the gene first arose.   This allows      */
/* the system to track innovations and use those to determine which        */
/* organisms are compatible.  (i.e. in the same species)                   */
/* A mutation_num gives a rough sense of how much mutation the gene has    */
/* experienced since it originally appeared.  (Since it was first          */
/* innovated.) In the current implenetation the mutation number is the
   same as the weight */

class Gene
{
 public:

  Link *lnk;
  double innovation_num;
  double mutation_num;  //Used to see how much mutation has changed the link

  bool enable;  //When this is off the Gene is disabled

  //Construct a gene with no trait
  Gene(double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum) {
    lnk=new Link(w,inode,onode,recur);
    innovation_num=innov;
    mutation_num=mnum;

    enable=true;
  }

  //Construct a gene with a trait
  Gene(Trait *tp,double w,NNode *inode,NNode *onode,bool recur,double innov,double mnum) {
    lnk=new Link(tp,w,inode,onode,recur);
    innovation_num=innov;
    mutation_num=mnum;

    enable=true;
  }

  //Construct a gene off of another gene as a duplicate
  Gene(Gene *g,Trait *tp,NNode *inode,NNode *onode) {
    //cout<<"Trying to attach nodes: "<<inode<<" "<<onode<<endl;
    lnk=new Link(tp,(g->lnk)->weight,inode,onode,(g->lnk)->is_recurrent);
    innovation_num=g->innovation_num;
    mutation_num=g->mutation_num;
    enable=g->enable;
  }

  //Construct a gene from a file spec given traits and nodes
  Gene(ifstream &iFile,vector<Trait*> &traits,list<NNode*> &nodes) {
    //Gene parameter holders
    int traitnum;
    int inodenum;
    int onodenum;
    NNode *inode;
    NNode *onode;
    double weight;
    int recur;
    Trait *traitptr;

    vector<Trait*>::iterator curtrait;
    list<NNode*>::iterator curnode;

    //Get the gene parameters
    iFile>>traitnum;
    iFile>>inodenum;
    iFile>>onodenum;
    iFile>>weight;
    iFile>>recur;
    iFile>>innovation_num;
    iFile>>mutation_num;
    iFile>>enable;
    
    //Get a pointer to the linktrait
    if (traitnum==0) traitptr=0;
    else {
      curtrait=traits.begin();
      while(((*curtrait)->trait_id)!=traitnum)
	++curtrait;
      traitptr=(*curtrait);
    }
    
    //Get a pointer to the input node
    curnode=nodes.begin();
    while(((*curnode)->node_id)!=inodenum)
      ++curnode;
    inode=(*curnode);
    
    //Get a pointer to the output node
    curnode=nodes.begin();
    while(((*curnode)->node_id)!=onodenum)
      ++curnode;
    onode=(*curnode);

    lnk=new Link(traitptr,weight,inode,onode,recur);
      
    
  }

  
  ~Gene() {
    delete lnk;
  }

  void print_to_file(ofstream &outFile); //Print gene to a file- called from Genome

  friend ostream& operator<< (ostream& os, const Gene *thegene);


};

#endif