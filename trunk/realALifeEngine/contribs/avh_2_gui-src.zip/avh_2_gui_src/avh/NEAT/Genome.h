#ifndef __NEAT_GENOME_H__
#define __NEAT_GENOME_H__

#include "NEAT.h"

//Description: 

/* ----------------------------------------------------------------------- */  
/* A Genome is the primary source of genotype information used to create   */
/* a phenotype.  It contains 3 major constituents:                         */
/*   1) A Vector of Traits                                                 */
/*   2) A List of NNodes pointing to a Trait from (1)                      */
/*   3) A List of Genes with Links that point to Traits from (1)           */
/* (1) Reserved parameter space for future use                             */
/* (2) NNode specifications                                                */
/* (3) Is the primary source of innovation in the evolutionary Genome.     */
/*     Each Gene in (3) has a marker telling when it arose historically.   */
/*     Thus, these Genes can be used to speciate the population, and the   */
/*     list of Genes provide an evolutionary history of innovation and     */
/*     link-building. */
class Genome
{         

 protected:
  //Inserts a NNode into a given ordered list of NNodes in order
  void node_insert(list<NNode*> &nlist,NNode *n);

 public:             

  friend ostream& operator<< (ostream& os, const Genome *thegenome);

  int genome_id;

  vector<Trait*> traits; //parameter conglomerations
  list<NNode*> nodes;     //List of NNodes for the Network
  list<Gene*> genes;     //List of innovation-tracking genes

  Network *phenotype;  //Allows Genome to be matched with its Network

  int get_last_node_id();  //Return id of final NNode in Genome
  double get_last_gene_innovnum();  //Return last innovation number in Genome

  void print_genome();  //Displays Genome on screen

  //Constructor which takes full genome specs and puts them into the new one
  Genome(int id,vector<Trait*> t, list<NNode*> n, list<Gene*> g) {
    genome_id=id;
    traits=t;
    nodes=n; 
    genes=g;
  }

  //Constructor which takes in links (not genes) and creates a Genome
  Genome(int id,vector<Trait*> t, list<NNode*> n, list<Link*> links) {
    list<Link*>::iterator curlink;
    Gene *tempgene;
    traits=t;
    nodes=n;

    genome_id=id;
    
    //We go through the links and turn them into original genes
    for(curlink=links.begin();curlink!=links.end();++curlink) {
      //Create genes one at a time
      tempgene=new Gene((*curlink)->linktrait, (*curlink)->weight,(*curlink)->in_node,(*curlink)->out_node,(*curlink)->is_recurrent,1.0,0.0);
      genes.push_back(tempgene);
    }

  }

  //Special constructor which spawns off an input file
  //This constructor assumes that some routine has already read in GENOMESTART
  Genome(int id,ifstream &iFile) {
    char curword[20];  //max word size of 20 characters

    int done=0;

    genome_id=id;

    //Loop until file is finished, parsing each line
    while (!done) {
      
      iFile>>curword;

      //Check for end of Genome
      if (strcmp(curword,"genomeend")==0) {
	int idcheck;
	iFile>>idcheck;
	if (idcheck!=genome_id) cout<<"ERROR: id mismatch in genome"<<endl;
	done=1;
      }

      //Ignore comments surrounded by /* */ - they get printed to screen
      else if (strcmp(curword,"/*")==0) {
	iFile>>curword;
	while (strcmp(curword,"*/")!=0) {
	  cout<<curword<<" ";
	  iFile>>curword;
	}
	cout<<endl;
      }

      //Read in a trait
      else if (strcmp(curword,"trait")==0) {
	Trait *newtrait;

	//Allocate the new trait
	newtrait=new Trait(iFile);

	//Add trait to vector of traits
	traits.push_back(newtrait);
      }

      //Read in a node
      else if (strcmp(curword,"node")==0) {
	NNode *newnode;

	//Allocate the new node
	newnode=new NNode(iFile,traits);
	
	//Add the node to the list of nodes
	nodes.push_back(newnode);
      }

      //Read in a Gene
      else if (strcmp(curword,"gene")==0) {
	Gene *newgene;

	//Allocate the new Gene
	newgene=new Gene(iFile,traits,nodes);

	//Add the gene to the genome
	genes.push_back(newgene);
	
	//cout<<"Added gene "<<newgene<<endl;
      }
      
    }
    
  }

    /* This special constructor creates a Genome
     with i inputs, o outputs, n out of nmax hidden units, and random
     connectivity.  If r is true then recurrent connections will
     be included. 
     The last input is a bias
     Linkprob is the probability of a link  */
  Genome(int new_id,int i, int o, int n,int nmax, bool r, double linkprob) {
    int totalnodes;
    bool *cm; //The connection matrix which will be randomized
    bool *cmp; //Connection matrix pointer
    int matrixdim;
    int count;
    
    int ncount; //Node and connection counters
    int ccount;

    int row;  //For navigating the matrix
    int col;

    double new_weight;

    int maxnode; //No nodes above this number for this genome

    int first_output; //Number of first output node

    totalnodes=i+o+nmax;
    matrixdim=totalnodes*totalnodes;
    cm=new bool[matrixdim];  //Dimension the connection matrix
    maxnode=i+n;

    first_output=totalnodes-o+1;

    //For creating the new genes
    NNode *newnode;
    Gene *newgene;
    Trait *newtrait;
    NNode *in_node;
    NNode *out_node;

    //Retrieves the nodes pointed to by connection genes
    list<NNode*>::iterator node_iter;

    //Assign the id
    genome_id=new_id;

    cout<<"Assigned id "<<genome_id<<endl;

    //Step through the connection matrix, randomly assigning bits
    cmp=cm;
    for(count=0;count<matrixdim;count++) {
      if (randfloat()<linkprob)
	*cmp=true;
      else *cmp=false;
      cmp++;
    }

    //Create a dummy trait (this is for future expansion of the system)
    newtrait=new Trait(1,0,0,0,0,0,0,0,0,0);
    traits.push_back(newtrait);

    //Build the input nodes
    for(ncount=1;ncount<=i;ncount++) {
      if (ncount<i)
	newnode=new NNode(SENSOR,ncount,INPUT);
      else newnode=new NNode(SENSOR,ncount,BIAS);
      
      newnode->nodetrait=newtrait;

      //Add the node to the list of nodes
      nodes.push_back(newnode);
    }

    //Build the hidden nodes
    for(ncount=i+1;ncount<=i+n;ncount++) {
      newnode=new NNode(NEURON,ncount,HIDDEN);
      newnode->nodetrait=newtrait;
      //Add the node to the list of nodes
      nodes.push_back(newnode);
    }
    
    //Build the output nodes
    for(ncount=first_output;ncount<=totalnodes;ncount++) {
      newnode=new NNode(NEURON,ncount,OUTPUT);
      newnode->nodetrait=newtrait;
      //Add the node to the list of nodes
      nodes.push_back(newnode);
    }

    cout<<"Built nodes"<<endl;

    //Connect the nodes 
    ccount=1;  //Start the connection counter
    
    //Step through the connection matrix, creating connection genes
    cmp=cm;
    count=0;
    for(col=1;col<=totalnodes;col++)
      for(row=1;row<=totalnodes;row++) {
	//Only try to create a link if it is in the matrix
	//and not leading into a sensor
		
	if ((*cmp==true)&&(col>i)&&
	    ((col<=maxnode)||(col>=first_output))&&
	    ((row<=maxnode)||(row>=first_output))) {
	  //If it isn't recurrent, create the connection no matter what
	  if (col>row) {

	    //Retrieve the in_node
	    node_iter=nodes.begin();
	    while((*node_iter)->node_id!=row)
	      node_iter++;

	    in_node=(*node_iter);

	    //Retrieve the out_node
	    node_iter=nodes.begin();
	    while((*node_iter)->node_id!=col)
	      node_iter++;

	    out_node=(*node_iter);

	    //Create the gene
	    new_weight=randposneg()*randfloat();
	    newgene=new Gene(newtrait,new_weight, in_node, out_node,false,count,new_weight);
  
	    //Add the gene to the genome
	    genes.push_back(newgene);
	  }
	  else if (r) {
	    //Create a recurrent connection
	    	    
	    //Retrieve the in_node
	    node_iter=nodes.begin();
	    while((*node_iter)->node_id!=row)
	      node_iter++;
	    
	    in_node=(*node_iter);
	    
	    //Retrieve the out_node
	    node_iter=nodes.begin();
	    while((*node_iter)->node_id!=col)
	      node_iter++;
	    
	    out_node=(*node_iter);
	    
	    //Create the gene
	    new_weight=randposneg()*randfloat();
	    newgene=new Gene(newtrait,new_weight, in_node, out_node,true,count,new_weight);
  
	    //Add the gene to the genome
	    genes.push_back(newgene);

	  }

	}

	count++; //increment gene counter	    
	cmp++;
      }

    delete [] cm;

  }

  //Destructor kills off all lists (including the trait vector)
  ~Genome() {
    vector<Trait*>::iterator curtrait;
    list<NNode*>::iterator curnode;
    list<Gene*>::iterator curgene;

    for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
      delete (*curtrait);
    }

    for(curnode=nodes.begin();curnode!=nodes.end();++curnode) {
      delete (*curnode);
    }
    
    for(curgene=genes.begin();curgene!=genes.end();++curgene) {
      delete (*curgene);
    }

  }

  Network *genesis(int);  //Generate a network phenotype from this Genome with specified id

  void print_to_file(ofstream &outFile); //Dump this genome to specified file

  void print_to_filename(char *filename); //Dump genome to file

  Genome *duplicate(int new_id);  /* Duplicate this Genome to create a new one
				     with the specified id */
  
  bool verify();  /* For debugging- tests node integrity */

  /* ******* MUTATORS ******* */

  void mutate_random_trait(); /* Perturb params in one trait */

  void mutate_link_trait(int times);  /* Change random link's trait. 
					 Repeat times times */

  void mutate_node_trait(int times); /* Change random node's trait times 
					times */

  void mutate_link_weights(double power,double rate,mutator mut_type);  /* Add Gaussian noise to 
					      linkweights either GAUSSIAN
					      or COLDGAUSSIAN (from zero) */

  void mutate_toggle_enable(int times); /* toggle genes on or off */

  void mutate_gene_reenable();  /* Find first disabled gene and enable it */

  /* These last kinds of mutations return false if they fail
     They can fail under certain conditions,  being unable
     to find a suitable place to make the mutation.
     Generally, if they fail, they can be called again if desired. */

  bool mutate_add_node(list<Innovation*> &innovs,int &curnode_id,double &curinnov); /* Mutate genome by adding a node respresentation */

  /* Mutate the genome by adding a new link between 2 random NNodes */
  bool mutate_add_link(list<Innovation*> &innovs,double &curinnov,int tries); 

  /* ****** MATING METHODS ***** */

  /* This method mates this Genome with another Genome g.  
     For every point in each Genome, where each Genome shares
     the innovation number, the Gene is chosen randomly from 
     either parent.  If one parent has an innovation absent in 
     the other, the baby will inherit the innovation */
  Genome *mate_multipoint(Genome *g,int genomeid,double fitness1, double fitness2);

  /* This method mates like multipoint but instead of selecting one
     or the other when the innovation numbers match, it averages their
     weights */
  Genome *mate_multipoint_avg(Genome *g,int genomeid,double fitness1,double fitness2);

  /* This method is similar to a standard single point CROSSOVER
     operator.  Traits are averaged as in the previous 2 mating
     methods.  A point is chosen in the smaller Genome for crossing
     with the bigger one.  */
  Genome *mate_singlepoint(Genome *g,int genomeid);


  /* ******** COMPATIBILITY CHECKING METHODS * ********/
  
  /* This function gives a measure of compatibility between
     two Genomes by computing a linear combination of 3
     characterizing variables of their compatibilty.
     The 3 variables represent PERCENT DISJOINT GENES, 
     PERCENT EXCESS GENES, MUTATIONAL DIFFERENCE WITHIN
     MATCHING GENES.  So the formula for compatibility 
     is:  disjoint_coeff*pdg+excess_coeff*peg+mutdiff_coeff*mdmg.
     The 3 coefficients are global system parameters */
  double compatibility(Genome *g);

  /* Return number of non-disabled genes */
  int extrons();

};

#endif