#include "Link.h"

/* ************************************************************** */
/* *                       LINK METHODS HERE                    * */
/* ************************************************************** */
//Reserved for future system expansion
void Link::derive_trait(Trait *curtrait) {
 
  if (curtrait!=0) {
    for (int count=0;count<NEAT::num_trait_params;count++)
      params[count]=(curtrait->params)[count];
  }
  else {
    for (int count=0;count<NEAT::num_trait_params;count++)
      params[count]=0;
  }

}