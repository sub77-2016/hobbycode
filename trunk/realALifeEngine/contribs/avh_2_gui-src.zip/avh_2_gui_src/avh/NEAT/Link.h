#ifndef __NEAT_LINK_H__
#define __NEAT_LINK_H__

#include "NEAT.h"

//Description: 

/* ----------------------------------------------------------------------- */
/* A LINK is a connection from one node to another with an associated weight */
/* It can be marked as recurrent */
/* Its parameters are made public for efficiency */
class Link
{
 public: 
  double weight; //Weight of connection
  NNode *in_node; //NNode inputting into the link
  NNode *out_node; //NNode that the link affects
  bool is_recurrent; //TRUE or FALSE
  bool time_delay; //TRUE or FALSE

  Trait *linktrait; //Points to a trait of parameters for genetic creation
  
  /* ************ LEARNING PARAMETERS *********** */
  /* These are link-related parameters that change
     during Hebbian type learning */
  double added_weight;  /* The amount of weight adjustment */

  double params[NEAT::num_trait_params];

  Link(double w,NNode *inode,NNode *onode,bool recur) {
    weight=w;
    in_node=inode;
    out_node=onode;
    is_recurrent=recur;
    added_weight=0;
    linktrait=0;
    time_delay=false;
  }

  //Including a trait pointer in the Link creation
  Link(Trait *lt,double w,NNode *inode,NNode *onode,bool recur) {
    weight=w;
    in_node=inode;
    out_node=onode;
    is_recurrent=recur;
    added_weight=0;
    linktrait=lt;
    time_delay=false;
  }	

  Link(double w) {  //For when you don't know the connections yet
    weight=w;
    in_node=out_node=0;  
    is_recurrent=FALSE;
    linktrait=0;
    time_delay=false;
  }

  ~Link() {
    //if (linktrait!=0) delete linktrait;
  }

  void derive_trait(Trait *curtrait);  //Derive a trait into link params

};

#endif