#include "NNode.h"


/* These are NNode types */
typedef int nodetype;
const int NEURON=0;
const int SENSOR=1;

typedef int nodeplace;
const int HIDDEN=0;
const int INPUT=1;
const int OUTPUT=2;
const int BIAS=3;

/* ************************************************************** */
/* *                       NODE METHODS HERE                    * */
/* ************************************************************** */

//Returns the type of the node, NEURON or SENSOR
const nodetype NNode::get_type() {
  return type;
}

//Allows alteration between NEURON and SENSOR.  Returns its argument
nodetype NNode::set_type(nodetype newtype) {
  type=newtype;
  return newtype;
}

//If the node is a SENSOR, returns TRUE and loads the value
bool NNode::sensor_load(double value) {
  if (type==SENSOR) {

    //Time delay memory
    last_activation2=last_activation;
    last_activation=activation;

    activation_count++;  //Puts sensor into next time-step
    activation=value;
    return true;
  }
  else return false;
}

// SIGMOID FUNCTION ********************************
//This is a signmoidal activation function, which is an S-shaped squashing function
//It smoothly limits the amplitude of the output of a neuron to between 0 and 1
//It is a helper to the neural-activation function get_active_out
//It is made inline so it can execute quickly since it is at every non-sensor 
// node in a network.
//NOTE:  In order to make node insertion in the middle of a link possible,
// the signmoid can be shifted to the right and more steeply sloped:
// slope=4.924273
// constant= 2.4621365
// These parameters optimize mean squared error between the old output,
// and an output of a node inserted in the middle of a link between
// the old output and some other node. 
// When not right-shifted, the steepened slope is closest to a linear
// ascent as possible between -0.5 and 0.5
inline double fsigmoid(double activesum,double slope,double constant) {
  //RIGHT SHIFTED ---------------------------------------------------------
  //return (1/(1+(exp(-(slope*activesum-constant))))); //ave 3213 clean on 40 runs of p2m and 3468 on another 40 
  //41394 with 1 failure on 8 runs

  //LEFT SHIFTED ----------------------------------------------------------
  //return (1/(1+(exp(-(slope*activesum+constant))))); //original setting ave 3423 on 40 runs of p2m, 3729 and 1 failure also

  //PLAIN SIGMOID ---------------------------------------------------------
  //return (1/(1+(exp(-activesum)))); //3511 and 1 failure

  //LEFT SHIFTED NON-STEEPENED---------------------------------------------
  //return (1/(1+(exp(-activesum-constant)))); //simple left shifted

  //NON-SHIFTED STEEPENED
  return (1/(1+(exp(-(slope*activesum))))); //Compressed
}


//NNode Display
ostream& operator<<(ostream &os,const NNode &thenode) {
  if (thenode.type==SENSOR)
    cout<<"(S"<<thenode.node_id<<", step "<<thenode.activation_count<<":"<<thenode.activation<<")";
  else if (thenode.type==NEURON)
    cout<<"(N"<<thenode.node_id<<", step "<<thenode.activation_count<<":"<<thenode.activation<<")";
  return os;
}

//NNode Pointer Display
ostream& operator<<(ostream &os,const NNode *thenode) {
  if ((*thenode).type==SENSOR)
    cout<<"(S"<<(*thenode).node_id<<","<<" step "<<(*thenode).activation_count<<":"<<(*thenode).activation<<")";
  else if ((*thenode).type==NEURON)
    cout<<"(N"<<(*thenode).node_id<<","<<" step "<<(*thenode).activation_count<<":"<<(*thenode).activation<<")";
  return os;
}

//Note: NEAT keeps track of which links are recurrent and which
//are not even though this is unnecessary for activation.
//It is useful to do so for 2 other reasons: 
//1. It makes networks visualization of recurrent networks possible
//2. It allows genetic control of the proportion of connections
//    that may become recurrent

//Add an incoming connection a node
void NNode::add_incoming(NNode *feednode,double weight,bool recur) {
  Link *newlink=new Link(weight,feednode,this,recur);
  incoming.push_back(newlink);
  (feednode->outgoing).push_back(newlink);
}

//Nonrecurrent version
void NNode::add_incoming(NNode *feednode,double weight) {
  Link *newlink=new Link(weight,feednode,this,FALSE);
  incoming.push_back(newlink);
  (feednode->outgoing).push_back(newlink);
}

//Return activation currently in node, if it has been activated
double NNode::get_active_out() {
  if (activation_count>0)
    return activation;
  else return 0.0;
}

//Return activation currently in node from PREVIOUS (time-delayed) time step,
// if there is one
double NNode::get_active_out_td() {
  if (activation_count>1)
    return last_activation;
  else return 0.0;
}

//This recursively flushes everything leading into and including this NNode, including recurrencies
void NNode::flushback() {
  list<Link*>::iterator curlink;

  //A sensor should not flush black
  if (type!=SENSOR) {
    
    if (activation_count>0) {
      activation_count=0;
      activation=0;
      last_activation=0;
      last_activation2=0;
    }

    //Flush back recursively
    for(curlink=incoming.begin();curlink!=incoming.end();++curlink) {
      //Flush the link itself (For future learning parameters possibility) 
      (*curlink)->added_weight=0;
      if ((((*curlink)->in_node)->activation_count>0))
	  ((*curlink)->in_node)->flushback();
    }
  }
  else {
    //Flush the SENSOR
    activation_count=0;
    activation=0;
    last_activation=0;
    last_activation2=0;
    
  }

}

//This recursively checks everything leading into and including this NNode, 
// including recurrencies
// Useful for debugging
void NNode::flushback_check(list<NNode*> &seenlist) {
  list<Link*>::iterator curlink;
  int pause;
  list<Link*> innodes=incoming;
  list<NNode*>::iterator location;

  if (!(type==SENSOR)) {
    

      cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<endl;
      cout<<"ALERT: "<<this<<" has activation  "<<activation<<endl;
      cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<endl;
      cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<endl;

    if (activation_count>0) {
      cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<endl;
      cin>>pause;
    }

    if (activation>0) {
      cout<<"ALERT: "<<this<<" has activation  "<<activation<<endl;
      cin>>pause;
    }

    if (last_activation>0) {
      cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<endl;
      cin>>pause;
    }

    if (last_activation2>0) {
      cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<endl;
      cin>>pause;
    }

    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      location=find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
      if (location==seenlist.end()) {
	seenlist.push_back((*curlink)->in_node);
	((*curlink)->in_node)->flushback_check(seenlist);
      }
    }

  }
  else {
    //Flush_check the SENSOR

    
      cout<<"sALERT: "<<this<<" has activation count "<<activation_count<<endl;
      cout<<"sALERT: "<<this<<" has activation  "<<activation<<endl;
      cout<<"sALERT: "<<this<<" has last_activation  "<<last_activation<<endl;
      cout<<"sALERT: "<<this<<" has last_activation2  "<<last_activation2<<endl;
    

    if (activation_count>0) {
      cout<<"ALERT: "<<this<<" has activation count "<<activation_count<<endl;
      cin>>pause;
    }
    
    if (activation>0) {
      cout<<"ALERT: "<<this<<" has activation  "<<activation<<endl;
      cin>>pause;
    }
    
    if (last_activation>0) {
      cout<<"ALERT: "<<this<<" has last_activation  "<<last_activation<<endl;
      cin>>pause;
    }
    
    if (last_activation2>0) {
      cout<<"ALERT: "<<this<<" has last_activation2  "<<last_activation2<<endl;
      cin>>pause;
    }
    
  }
  
}

//Reserved for future system expansion
void NNode::derive_trait(Trait *curtrait) {

  if (curtrait!=0) {
    for (int count=0;count<NEAT::num_trait_params;count++)
      params[count]=(curtrait->params)[count];
  }
  else {
    for (int count=0;count<NEAT::num_trait_params;count++)
      params[count]=0;
  }

}



//Find the greatest depth starting from this neuron at depth d
int NNode::depth(int d, Network *mynet) {
  list<Link*> innodes=this->incoming;
  list<Link*>::iterator curlink;
  int cur_depth; //The depth of the current node
  int max=d; //The max depth
  int pause;

  if (d>100) {
    //cout<<mynet->genotype<<endl;
    cout<<"** DEPTH NOT DETERMINED FOR NETWORK WITH LOOP"<<endl;
    return 10;
  }

  //Base Case
  if ((this->type)==SENSOR)
    return d;
  //Recursion
  else {

    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      cur_depth=((*curlink)->in_node)->depth(d+1,mynet);
      if (cur_depth>d) max=cur_depth;
    }
  
    return max;

  } //end else

}

void NNode::print_to_file(ofstream &outFile) {
  outFile<<"node "<<node_id<<" ";
  if (nodetrait!=0) outFile<<nodetrait->trait_id<<" ";
  else outFile<<"0 ";
  outFile<<type<<" ";
  outFile<<gen_node_label<<endl;
}