#ifndef __NEAT_NNODE_H__
#define __NEAT_NNODE_H__

#include "NEAT.h"

//Description: 

/* ----------------------------------------------------------------------- */
/* A NODE is either a NEURON or a SENSOR.  
   If it's a sensor, it can be loaded with a value for output
   If it's a neuron, it has a list of its incoming input signals (List<Link> is used) */
//Use an activation count to avoid flushing
class NNode
{
  friend class Network;
  friend class Genome;
  //friend class Population;

 protected:

  int activation_count;  //keeps track of which activation the node is currently in
  double last_activation; //Holds the previous step's activation for recurrency
  double last_activation2; //Holds the activation BEFORE the prevous step's
  //This is necessary for a special recurrent case when the innode 
  // of a recurrent link is one time step ahead of the outnode.
  // The innode then needs to send from TWO time steps ago

  Trait *nodetrait; //Points to a trait of parameters

  NNode *analogue;  //Used for Gene decoding 
  NNode *dup;       //Used for Genome duplication

 public:
  functype ftype; //type is either SIGMOID ..or others that can be added
  nodetype type; //type is either NEURON or SENSOR 

  double activesum;  //The incoming activity before being processed 
  double activation; //The total activation entering the NNode 
  bool active_flag;  //To make sure outputs are active

  //NOT USED IN NEAT- covered by "activation" above
  double output;  //Output of the NNode- the value in the NNode 

  /* ************ LEARNING PARAMETERS *********** */
  /* The following parameters are for use in    
     neurons that learn through habituation,
     sensitization, or Hebbian-type processes  */

  double params[NEAT::num_trait_params];

  list<Link*> incoming; //A list of pointers to incoming weighted signals from other nodes
  list<Link*> outgoing;  //A list of pointers to links carrying this node's signal

  //These members are used for graphing with GTK+/GDK
  list<double> rowlevels;  //Depths from output where this node appears
  int row;  //Final row decided upon for drawing this NNode in
  int ypos;
  int xpos;

  friend ostream& operator<< (ostream& os, const NNode &thenode);
  friend ostream& operator<< (ostream& os, const NNode *thenode); 

  int node_id;  //A node can be given an identification number for saving in files

  nodeplace gen_node_label;  //Used for genetic marking of nodes

  NNode(nodetype ntype,int nodeid) {
    active_flag=false;
    activesum=0;
    activation=0;
    output=0;
    last_activation=0;
    last_activation2=0;
    type=ntype; //NEURON or SENSOR type
    activation_count=0; //Inactive upon creation
    node_id=nodeid;
    ftype=SIGMOID;
    nodetrait=0;
    gen_node_label=HIDDEN;
    dup=0;
    analogue=0;
  }

  NNode(nodetype ntype,int nodeid, nodeplace placement) {
    active_flag=false;
    activesum=0;
    activation=0;
    output=0;
    last_activation=0;
    last_activation2=0;
    type=ntype; //NEURON or SENSOR type
    activation_count=0; //Inactive upon creation
    node_id=nodeid;
    ftype=SIGMOID;
    nodetrait=0;
    gen_node_label=placement;
    dup=0;
    analogue=0;
  }

  //Construct a NNode off another NNode for genome purposes
  NNode(NNode *n,Trait *t) {
    active_flag=false;
    activation=0;
    output=0;
    last_activation=0;
    last_activation2=0;
    type=n->type; //NEURON or SENSOR type
    activation_count=0; //Inactive upon creation
    node_id=n->node_id;
    ftype=SIGMOID;
    nodetrait=0;
    gen_node_label=n->gen_node_label;
    dup=0;
    analogue=0;
    nodetrait=t;
  }

  //Construct the node out of a file specification using given list of traits
  NNode (ifstream &iFile,vector<Trait*> &traits) {
    int traitnum;
    vector<Trait*>::iterator curtrait;

    activesum=0;

    //Get the node parameters
    iFile>>node_id;
    iFile>>traitnum;
    iFile>>type;
    iFile>>gen_node_label;
    
    //Get a pointer to the trait this node points to
    if (traitnum==0) nodetrait=0;
    else {
      curtrait=traits.begin();
      while(((*curtrait)->trait_id)!=traitnum)
	++curtrait;
      nodetrait=(*curtrait);
    }
  }

  ~NNode() {
    list<Link*>::iterator curlink;

    //Kill off all incoming links
    for(curlink=incoming.begin();curlink!=incoming.end();++curlink) {
      delete (*curlink);
    }

    //if (nodetrait!=0) delete nodetrait;
    
  }

  double get_active_out(); //Just return activation for step
  double get_active_out_td(); //Return activation from PREVIOUS time step

  const nodetype get_type(); //Returns the type of the node, NEURON or SENSOR
  nodetype set_type(nodetype);  //Allows alteration between NEURON and SENSOR.  Returns its argument
  bool sensor_load(double); //If the node is a SENSOR, returns TRUE and loads the value
  void add_incoming(NNode*,double); //Adds a NONRECURRENT Link to a new NNode in the incoming List
  void add_incoming(NNode*,double,bool); //Adds a Link to a new NNode in the incoming List
  void flushback();  //Recursively deactivate backwards through the network
  void flushback_check(list<NNode*> &seenlist);  //Verify flushing for debuginh

  void  print_to_file(ofstream &outFile); //Print the node to a file

  void derive_trait(Trait *curtrait);//Have NNode gain its properties from the trait

  //Find the greatest depth starting from this neuron at depth d
  int depth(int d,Network *mynet); 

};

#endif