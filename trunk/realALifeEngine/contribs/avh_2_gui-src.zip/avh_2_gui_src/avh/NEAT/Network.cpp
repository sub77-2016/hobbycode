#include "Network.h"

/* ************************************************************** */
/* *                      NETWORK METHODS HERE                  * */
/* ************************************************************** */

//Network pointer display
ostream& operator<<(ostream &os,Network *thenet) {
  thenet->show_activation();
}
 
//Puts the network back into an initial state
void Network::flush() {
  list<NNode*>::iterator curnode;

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    (*curnode)->flushback();
  }
}

//Debugger: Checks network state
void Network::flush_check() {
  list<NNode*>::iterator curnode;
  list<NNode*>::iterator location;
  list<NNode*> seenlist;  //List of nodes not to doublecount

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {    
    location=find(seenlist.begin(),seenlist.end(),(*curnode));
    if (location==seenlist.end()) {
      seenlist.push_back(*curnode);
      (*curnode)->flushback_check(seenlist);
    }
  }
}

//If all output are not active then return true
bool Network::outputsoff() {
  list<NNode*>::iterator curnode;

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    if (((*curnode)->activation_count)==0) return true;
  }

  return false;
}

//Activates the net such that all outputs are active
//Returns true on success;
bool Network::activate() {
  list<NNode*>::iterator curnode;
  list<Link*>::iterator curlink;
  double add_amount;  //For adding to the activesum
  bool onetime; //Make sure we at least activate once
  int abortcount=0;  //Used in case the output is somehow truncated from the network

  //cout<<"Activating network: "<<this->genotype<<endl;

  //Keep activating until all the outputs have become active 
  //(This only happens on the first activation, because after that they
  // are always active)

  onetime=false;

  while(outputsoff()||!onetime) {

    ++abortcount;

    if (abortcount==20) {
      return false;
      cout<<"Inputs disconnected from output!"<<endl;
    }
    //cout<<"Outputs are off"<<endl;

    /* For each node, compute the sum of its incoming activation */
    for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {
      //Ignore SENSORS

      //cout<<"On node "<<(*curnode)->node_id<<endl;

      if (((*curnode)->type)!=SENSOR) {
	(*curnode)->activesum=0;
	(*curnode)->active_flag=false;  //This will tell us if it has any active inputs

	/* For each incoming connection, add the activity from the connection
	   to the activesum */
	for(curlink=((*curnode)->incoming).begin();curlink!=((*curnode)->incoming).end();++curlink) {
	  //Handle possible time delays
	  if (!((*curlink)->time_delay)) {
	    add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out());
	    if ((((*curlink)->in_node)->active_flag)||
		(((*curlink)->in_node)->type==SENSOR)) (*curnode)->active_flag=true;
	    (*curnode)->activesum+=add_amount;
	    //cout<<"Node "<<(*curnode)->node_id<<" adding "<<add_amount<<" from node "<<((*curlink)->in_node)->node_id<<endl;
	  }
	  else {
	    //Input over a time delayed connection
	    add_amount=((*curlink)->weight)*(((*curlink)->in_node)->get_active_out_td());
	    (*curnode)->activesum+=add_amount;
	  }
	  
	} //End for over incoming links
	
      } //End if (((*curnode)->type)!=SENSOR) 
	
    } //End for over all nodes
    
    /* Now activate all the non-sensor nodes off their incoming activation */
    for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {

      if (((*curnode)->type)!=SENSOR) {
	//Only activate if some active input came in
	if ((*curnode)->active_flag) {
	  //cout<<"Activating "<<(*curnode)->node_id<<" with "<<(*curnode)->activesum<<": ";
	  
	  //Keep a memory of activations for potential time delayed connections
	  (*curnode)->last_activation2=(*curnode)->last_activation;
	  (*curnode)->last_activation=(*curnode)->activation;
	  //Now run the net activation through an activation function
	  if ((*curnode)->ftype==SIGMOID)
	    (*curnode)->activation=fsigmoid((*curnode)->activesum,4.924273,2.4621365);  //Sigmoidal activation- see comments under fsigmoid
	  
	  //cout<<(*curnode)->activation<<endl;
	  
	  //Increment the activation_count
	  //First activation cannot be from nothing!!
	  (*curnode)->activation_count++;
	}
      }
    }

    onetime=true;
  }

  return true;  
}


//THIS WAS NOT USED IN THE FINAL VERSION, AND NOT FULLY IMPLEMENTED,
//BUT IT SHOWS HOW SOMETHING LIKE THIS COULD BE INITIATED
//Note that checking networks for loops in general in not necessary
// and therefore I stopped writing this function
//Check Network for loops.  Return true if its ok, false if there is a loop.
//bool Network::integrity() {
//  list<NNode*>::iterator curnode;
//  list<list<NNode*>*> paths;
//  int count;
//  list<NNode*> *newpath;
//  list<list<NNode*>*>::iterator curpath;

//  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
//    newpath=new list<NNode*>();
//    paths.push_back(newpath);
//    if (!((*curnode)->integrity(newpath))) return false;
//  }

  //Delete the paths now that we are done
//  curpath=paths.begin();
//  for(count=0;count<paths.size();count++) {
//    delete (*curpath);
//    curpath++;
//  }

//  return true;
//}

//Prints the values of its outputs
void Network::show_activation() {
  list<NNode*>::iterator curnode;
  int count;

  if (name!=0)
    cout<<"Network "<<name<<" with id "<<net_id<<" outputs: (";
  else cout<<"Network id "<<net_id<<" outputs: (";

  count=1;
  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    cout<<"[Output #"<<count<<": "<<(*curnode)<<"] ";
    count++;
  }

  cout<<")"<<endl;
}

void Network::show_input() {
  list<NNode*>::iterator curnode;
  int count;

  if (name!=0)
    cout<<"Network "<<name<<" with id "<<net_id<<" inputs: (";
  else cout<<"Network id "<<net_id<<" outputs: (";

  count=1;
  for(curnode=inputs.begin();curnode!=inputs.end();++curnode) {
    cout<<"[Input #"<<count<<": "<<(*curnode)<<"] ";
    count++;
  }

  cout<<")"<<endl;
}

//Add an input
void Network::add_input(NNode *in_node) {
  inputs.push_back(in_node);
}

//Add an output
void Network::add_output(NNode *out_node) {
  outputs.push_back(out_node);
}

//Takes an array of sensor values and loads it into SENSOR inputs ONLY
void Network::load_sensors(double *sensvals) {
  int counter=0;  //counter to move through array
  list<NNode*>::iterator sensPtr;

  for(sensPtr=inputs.begin();sensPtr!=inputs.end();++sensPtr) {
    //only load values into SENSORS (not BIASes)
    if (((*sensPtr)->type)==SENSOR) {
     (*sensPtr)->sensor_load(*sensvals);
      sensvals++;
    }
  }
}

void Network::give_name(char *newname) {
  char *temp;
  char *temp2;
  temp=new char[strlen(newname)+1];
  strcpy(temp,newname);
  if (name==0) name=temp;
  else {
    temp2=name;
    delete temp2;
    name=temp;
  }
}

//The following two methods recurse through a network from outputs
//down in order to count the number of nodes and links in the network.
//This can be useful for debugging genotype->phenotype spawning 
//(to make sure their counts correspond)

int Network::nodecount() {
  int counter=0;
  list<NNode*>::iterator curnode;
  list<NNode*>::iterator location;
  list<NNode*> seenlist;  //List of nodes not to doublecount

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    
    location=find(seenlist.begin(),seenlist.end(),(*curnode));
    if (location==seenlist.end()) {
      counter++;
      seenlist.push_back(*curnode);
      nodecounthelper((*curnode),counter,seenlist);
    }
  }

  numnodes=counter;

  return counter;

}

void Network::nodecounthelper(NNode *curnode,int &counter,list<NNode*> &seenlist) {
  list<Link*> innodes=curnode->incoming;
  list<Link*>::iterator curlink;
  list<NNode*>::iterator location;

  if (!((curnode->type)==SENSOR)) {
    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      location=find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
      if (location==seenlist.end()) {
	counter++;
	seenlist.push_back((*curlink)->in_node);
	nodecounthelper((*curlink)->in_node,counter,seenlist);
      }
    }

  }

}

int Network::linkcount() {
  int counter=0;
  list<NNode*>::iterator curnode;
  list<NNode*> seenlist;  //List of nodes not to doublecount

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    linkcounthelper((*curnode),counter,seenlist);
  }

  numlinks=counter;

  return counter;

}

void Network::linkcounthelper(NNode *curnode,int &counter,list<NNode*> &seenlist) {
  list<Link*> inlinks=curnode->incoming;
  list<Link*>::iterator curlink;
  list<NNode*>::iterator location;

  location=find(seenlist.begin(),seenlist.end(),curnode);
  if ((!((curnode->type)==SENSOR))&&(location==seenlist.end())) {
    seenlist.push_back(curnode);

    for(curlink=inlinks.begin();curlink!=inlinks.end();++curlink) {
      counter++;
      linkcounthelper((*curlink)->in_node,counter,seenlist);
    }

  }

}


//Destroy will find every node in the network and subsequently
//delete them one by one.  Since deleting a node deletes its incoming
//links, all nodes and links associated with a network will be destructed
//Note: Traits are parts of genomes and not networks, so they are not
//      deleted here
void Network::destroy() {
  list<NNode*>::iterator curnode;
  list<NNode*>::iterator location;
  list<NNode*> seenlist;  //List of nodes not to doublecount

  /* Erase all nodes from all_nodes list */

  for(curnode=all_nodes.begin();curnode!=all_nodes.end();++curnode) {
    delete (*curnode);
  }


  /* ----------------------------------- 

    OLD WAY-the old way collected the nodes together and then deleted them

  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    //cout<<seenlist<<endl;
    //cout<<curnode<<endl;
    //cout<<curnode->node_id<<endl;
    
    location=find(seenlist.begin(),seenlist.end(),(*curnode));
    if (location==seenlist.end()) {
      seenlist.push_back(*curnode);
      destroy_helper((*curnode),seenlist);
    }
  }

  //Now destroy the seenlist, which is all the NNodes in the network
  for(curnode=seenlist.begin();curnode!=seenlist.end();++curnode) {
    delete (*curnode);
  }

  */

}

void Network::destroy_helper(NNode *curnode,list<NNode*> &seenlist) {
  list<Link*> innodes=curnode->incoming;
  list<Link*>::iterator curlink;
  list<NNode*>::iterator location;

  if (!((curnode->type)==SENSOR)) {
    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      location=find(seenlist.begin(),seenlist.end(),((*curlink)->in_node));
      if (location==seenlist.end()) {
	seenlist.push_back((*curlink)->in_node);
	destroy_helper((*curlink)->in_node,seenlist);
      }
    }

  }

}

/* This checks a POTENTIAL link between a potential in_node
   and potential out_node to see if it must be recurrent */
bool Network::is_recur(NNode *potin_node,NNode *potout_node,int &count,int thresh) {
  list<Link*>::iterator curlink;


  ++count;  //Count the node as visited

  if (count>thresh) {
    cout<<"returning false"<<endl;
    return false;  //Short out the whole thing- loop detected
  }

  if (potin_node==potout_node) return true;
  else {
    //Check back on all links...
    for(curlink=(potin_node->incoming).begin();curlink!=(potin_node->incoming).end();curlink++) {
      //But skip links that are already recurrent
      //(We want to check back through the forward flow of signals only
      if (!((*curlink)->is_recurrent)) {
	if (is_recur((*curlink)->in_node,potout_node,count,thresh)) return true;
      }
    }
    return false;
  }
}

//NETWORK GRAPHICS METHODS ------------------------------------
//USING GTKMM

//Network graphing- preprocessing before GTK+ draws a Network
/* Width and height give the size of the drawing window */
void Network::graph(int width,int height) {

  list<NNode*> drawlist;  //Draw-order list of nodes
  list<NNode*>::iterator curnode;  //Moves through outputs
  list<double>::iterator currow;  //For row averaging
  double rowsum;
  int maxrow=0;
  int xpixels;
  int ypixels;
  int ystep;
  int xstep;
  int ypos=50;  //Always start drawing 20 pixels in
  int xpos=3;
  int rownum;
  int nodes_in_row;
  int noise;  //Noise is added to x values so they won't perfectly align
  list<NNode*> *startpath; //For detecting loops

  ScribbleWindow *window;

  // Before setting up graphics, we need to compute the coordinates
  // of the nodes
  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {

    //Create a new path for this output
    startpath=new list<NNode*>();
    startpath->push_back((*curnode));

    ((*curnode)->rowlevels).push_back(0);
    drawlist.push_back((*curnode));
    findrows((*curnode),0,drawlist,startpath);

    //path used
    delete startpath;
  }

  //Now assign each NNode an average row for drawing purposes
  for(curnode=drawlist.begin();curnode!=drawlist.end();++curnode) {
    rowsum=0;
    for(currow=((*curnode)->rowlevels).begin();currow!=((*curnode)->rowlevels).end();++currow) {
      rowsum+=*currow;
    }
    //Now average it
    (*curnode)->row=floor(rowsum/(((*curnode)->rowlevels).size())+0.5);
    if ((*curnode)->row>maxrow) 
      maxrow=(*curnode)->row;  //Keep track of lowest row
  }

  //Pull the sensors down to below the lowest row
  ++maxrow;

  //Now push the sensors onto the drawlist at the maxrow level
  for(curnode=inputs.begin();curnode!=inputs.end();++curnode) {
    ((*curnode)->rowlevels).push_back(0);
    (*curnode)->row=maxrow;
    drawlist.push_back((*curnode));
  }

  //Pull the outputs to the top row
  for(curnode=outputs.begin();curnode!=outputs.end();++curnode) {
    ((*curnode)->rowlevels).push_back(0);
    (*curnode)->row=0;
  }

  //Compute the size of the drawing area
  ypixels=height-100;
  xpixels=width-6;
  ystep=floor(ypixels/maxrow);

  //Assign coordinates to every node
  for(rownum=0;rownum<=maxrow;rownum++) {
    //See how many NNodes are in this row
    nodes_in_row=0;
    for(curnode=drawlist.begin();curnode!=drawlist.end();++curnode) {
      if (((*curnode)->row)==rownum) {
	nodes_in_row++;
      }
    }

    //Compute the xstep for this row
    xstep=floor(((double) xpixels)/
		((double) (nodes_in_row+1)));
    
    xpos+=xstep;

    for(curnode=drawlist.begin();curnode!=drawlist.end();++curnode) {
      if (((*curnode)->row)==rownum) {
	(*curnode)->ypos=ypos;

	noise=0;
	if (((*curnode)->type)!=SENSOR) {
	  noise=randint(0,xstep/2);
	  if (randbit()) noise=noise*-1;
	}

	(*curnode)->xpos=xpos+noise;

	xpos+=xstep;
      }
    }
    ypos+=ystep;
    xpos=3;
  }

  //Now that each node has a coordinate,we can graph the network
  //Note that the actual drawing takes place during he configuration

  window = new ScribbleWindow(this,&drawlist,width,height);
  window->show();

  myapp->run();

  //delete window;
  
}

int Network::input_start() {
  input_iter=inputs.begin();
  return 1;
}
  
int Network::load_in(double d) {
  (*input_iter)->sensor_load(d);
  input_iter++;
  if (input_iter==inputs.end()) return 0;
  else return 1;
}

//Find the maximum number of neurons between an ouput and an input
int Network::max_depth() {
  list<NNode*>::iterator curoutput; //The current output we are looking at
  int cur_depth; //The depth of the current node
  int max=0; //The max depth
  
  for(curoutput=outputs.begin();curoutput!=outputs.end();curoutput++) {
    cur_depth=(*curoutput)->depth(0,this);
    if (cur_depth>max) max=cur_depth;
  }

  return max;

}




// **************** FOR GRAPHING ******************
 
//Find out which rows each NNode in the Network might belong to
//Path contains a pointer to a list of all nodes visited
//on the way to this node, so we can avoid inifnite loops
void Network::findrows(NNode *curnode,double row,list<NNode*> &drawlist,
		       list<NNode*> *path) {
  list<Link*> innodes=curnode->incoming;
  list<Link*>::iterator curlink;
  list<NNode*>::iterator location;
  list<NNode*> *newpath;
  list<NNode*>::iterator pathnode; //To copy the path

  //Go down one row
  row=row+1.0;

  if (!((curnode->type)==SENSOR)) {
    for(curlink=innodes.begin();curlink!=innodes.end();++curlink) {
      //Skip recurrent links- they don't affect row positioning of nodes
      if ((!((*curlink)->is_recurrent))) {

	//Make sure there is no loop
	location=find(path->begin(),path->end(),((*curlink)->in_node));
	if (location==path->end()) {

	  //Create a new path containing this node
	  newpath=new list<NNode*>();
	  
	  //Copy the current path into the new path
	  for(pathnode=path->begin();pathnode!=path->end();++pathnode) {
	    newpath->push_back((*pathnode));
	  }
	  
	  //Add the next node in the path to the path
	  newpath->push_back(((*curlink)->in_node));
	  
	  //cout<<"found Node "<<((*curlink)->in_node)<<" at row "<<row<<endl;

	  (((*curlink)->in_node)->rowlevels).push_back(row);
	  location=find(drawlist.begin(),drawlist.end(),((*curlink)->in_node));
	  
	  if (location==drawlist.end()) {
	    //Do not add SENSORS here because the traversal order may visit them
	    //out of order
	    if (!((((*curlink)->in_node)->type)==SENSOR))
	      drawlist.push_back((*curlink)->in_node);
	  }
	  //cout<<"calling findrows on node "<<((*curlink)->in_node)->node_id<<endl;
	  findrows((*curlink)->in_node,row,drawlist,newpath);
	  
	  delete newpath; //Path has been used

	} //end if (location==drawlist.end()) 
	
      } //end if ((!((*curlink)->is_recurrent)))
    }
  }
  
}
