#ifndef __NEAT_NETWORK_H__
#define __NEAT_NETWORK_H__

#include "NEAT.h"

//Description: 

/* A NETWORK is a LIST of input NODEs and a LIST of output NODEs           
   The point of the network is to define a single entity which can evolve
   or learn on its own, even though it may be part of a larger framework */
class Network
{

  friend class Genome;
  //friend class Population;
  friend ostream& operator<< (ostream& os, const NNode *thenode);

 protected:

  int numnodes; //The number of nodes in the net (-1 means not yet counted)
  int numlinks; //The number of links in the net (-1 means not yet counted)

  list<NNode*> all_nodes;  //A list of all the nodes

  list<NNode*>::iterator input_iter;  //For GUILE network inputting

  void destroy();  //Kills all nodes and links within
  void destroy_helper(NNode *curnode,list<NNode*> &seenlist); //helper for above

  void nodecounthelper(NNode *curnode,int &counter,list<NNode*> &seenlist);
  void linkcounthelper(NNode *curnode,int &counter,list<NNode*> &seenlist);

 public:

  Genome *genotype;  //Allows Network to be matched with its Genome

  char *name; //Every Network or subNetwork can have a name
  list<NNode*> inputs;  //NNodes that input into the network
  list<NNode*> outputs; //Values output by the network

  int net_id; //Allow for a network id
  
  friend ostream& operator<< (ostream& os, const Network &thenet);

  //This constructor allows the input and output lists to be supplied
  Network(list<NNode*> in,list<NNode*> out,list<NNode*> all,int netid) {
    inputs=in;
    outputs=out;
    all_nodes=all;
    name=0;   //Defaults to no name  ..NOTE: TRYING TO PRINT AN EMPTY NAME CAN CAUSE A CRASH
    numnodes=-1;
    numlinks=-1;
    net_id=netid;
  }

  //This constructs a net with empty input and output lists
  Network(int netid) {
    name=0; //Defaults to no name
    numnodes=-1;
    numlinks=-1;
    net_id=netid;
  }

  ~Network() {
    if (name!=0)
      delete [] name;

    destroy();  //Kill off all the nodes and links
                                                                         
   }

  void flush();  //Puts the network back into an inactive state
  void flush_check();  //Verify flushedness for debugging
 
  bool activate(); //Activates the net such that all outputs are active

  void show_activation(); //Prints the values of its outputs
  void show_input();
  void add_input(NNode*);  //Add a new input node
  void add_output(NNode*);  //Add a new output node
  void load_sensors(double*); //Takes an array of sensor values and loads it into SENSOR inputs ONLY
  void give_name(char*); //Name the network

  int nodecount(); //Counts the number of nodes in the net if not yet counted


  int linkcount(); //Counts the number of links in the net if not yet counted

  /* This checks a POTENTIAL link between a potential in_node
     and potential out_node to see if it must be recurrent */
  /* Use count and thresh to jump out in the case of an infinite loop */
  bool is_recur(NNode *potin_node,NNode *potout_node,int &count,int thresh); 

  /* Some functions to help GUILE input into Networks */
  int input_start();
  int load_in(double d);

  /* A Network Graphing Routine using GTK+ and GDK */
  /* Width and height give the size of the drawing window */
  void graph(int width,int height);
  //This collects a record of which row every NNode appears in
  //counting from the top (outputs) down
  //Path contains a pointer to a list of all nodes visited
  //on the way to this node, so we can avoid inifnite loops
  void findrows(NNode *curnode,double row,list<NNode*> &drawlist,list<NNode*> *path);

  bool outputsoff(); //If all output are not active then return true

  //Find the maximum number of neurons between an ouput and an input
  int max_depth();

 };

#endif