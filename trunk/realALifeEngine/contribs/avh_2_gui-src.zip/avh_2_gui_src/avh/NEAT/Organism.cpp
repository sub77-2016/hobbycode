#include "Organism.h"

/* Regenerate the network based on a change
   in the genotype */
void Organism::update_phenotype() {
  
  //First, delete the old phenotype (net)
  delete net;

  //Now, recreate the phenotype off the new genotype
  net=gnome->genesis(gnome->genome_id);

}