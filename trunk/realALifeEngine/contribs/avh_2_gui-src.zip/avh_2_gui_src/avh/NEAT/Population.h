#ifndef __NEAT_POPULATION_H__
#define __NEAT_POPULATION_H__

#include "NEAT.h"

//Description: 

/* ---------------------------------------------  */
/* POPULATION CLASS:
   A Population is a group of Organisms   
   including their species                        */
/* ---------------------------------------------  */
class Population
{

 protected: 

  /* A Population can be spawned off of a single Genome */
  /* There will be size Genomes added to the Population */
  /* The Population does not have to be empty to add Genomes */
  bool spawn(Genome *g,int size);

 public:

  list<Organism*> organisms; //The organisms in the Population

  list<Species*> species;  /* Species in the Population
				   Note that the species should comprise
				   all the genomes */

  /* Member variables used during reproduction */

  list<Innovation*> innovations;  /* For holding the genetic innovations
				     of the newest generation */
  int cur_node_id;  //Current label number available
  double cur_innov_num;

  int last_species;  //The highest species number

  int final_gen;  //The last generation played

  list<Generation_viz*> generation_snapshots; /* Visualization of Speciation History */

  /* Fitness Statistics */
  double mean_fitness;
  double variance;
  double standard_deviation;

  //An integer that when above zero tells when the first winner appeared
  int winnergen;
  
  /*  When do we need to delta code?  */
  double highest_fitness;  //Stagnation detector
  int highest_last_changed; //If too high, leads to delta coding

  bool speciate(); //Separate the Organisms into species

  //Print Population to a file specified by a string 
  bool print_to_file(char *filename);

  //Print Population to a file in speciated order with comments
  //separating each species
  bool print_to_file_by_species(char *filename);

  //Run verify on all Genomes in this Population (Debugging)
  bool verify();

  //Turnover the population to a new generation using fitness 
  //The generation argument is the next generation
  bool epoch(int generation);

  //Take a snapshot of the current generation for visualization purpose
  void snapshot();

  //Visualize the Population's Speciation using a graphic depiction
  //width and height denote the size of the window
  void visualize(int width,int height,int start_gen,int stop_gen);

  /* Construct off of a single spawning Genome */
  Population(Genome *g,int size) {
    winnergen=0;
    highest_fitness=0.0;
    highest_last_changed=0;
    spawn(g,size);
  }

  /* Special constructor to create a population of random topologies */
  // uses Genome(int i, int o, int n,int nmax, bool r, double linkprob) 
  //See the Genome constructor above for the argument specifications
  Population(int size,int i,int o, int nmax, bool r, double linkprob) {
    int count;
    Genome *new_genome; 

    cout<<"Making a random pop"<<endl;

    winnergen=0;
    highest_fitness=0.0;
    highest_last_changed=0;

    for(count=0;count<size;count++) {
      new_genome=new Genome(count,i,o,randint(0,nmax),nmax,r,linkprob);
      organisms.push_back(new Organism(0,new_genome,1));
    }

    cur_node_id=i+o+nmax+1;;
    cur_innov_num=(i+o+nmax)*(i+o+nmax)+1;

    cout<<"Calling speciate"<<endl;
    speciate(); 

  }

  /* Construct off of a file of Genomes */
  Population(char *filename) {

    char curword[20];  //max word size of 20 characters

    ifstream iFile(filename,ios::in);

    Genome *new_genome;

    winnergen=0;

    highest_fitness=0.0;
    highest_last_changed=0;

    cur_node_id=0;
    cur_innov_num=0.0;

    //Make sure it worked
    if (!iFile) {
      cerr<<"Can't open "<<filename<<" for input"<<endl;
    }
   
    else {

      //Loop until file is finished, parsing each line
      while (iFile>>curword) {
	
	//Check for next
	if (strcmp(curword,"genomestart")==0) {
	  int idcheck;
	  iFile>>idcheck;
	  new_genome=new Genome(idcheck,iFile);
	  organisms.push_back(new Organism(0,new_genome,1));
	  if (cur_node_id<(new_genome->get_last_node_id()))
	    cur_node_id=new_genome->get_last_node_id();
	  
	  if (cur_innov_num<(new_genome->get_last_gene_innovnum()))
	    cur_innov_num=new_genome->get_last_gene_innovnum();
	}
	
	//Ignore comments surrounded by /* */ - they get printed to screen
	else if (strcmp(curword,"/*")==0) {
	  iFile>>curword;
	  while (strcmp(curword,"*/")!=0) {
	    cout<<curword<<" ";
	    iFile>>curword;
	  }
	  cout<<endl;
	  
	}
      }
      
      iFile.close();
      
      speciate();
     
    }
  }


  //It can delete a Population in two ways:
  //-delete by killing off the species
  //-delete by killing off the organisms themselves (if not speciated)
  //It does the latter if it sees the species list is empty
  ~Population() {
    
    list<Species*>::iterator curspec;
    list<Organism*>::iterator curorg;
    list<Generation_viz*>::iterator cursnap;

    if (species.begin()!=species.end()) {
      for(curspec=species.begin();curspec!=species.end();++curspec) {
	delete (*curspec);
      }
    }
    else {
      for(curorg=organisms.begin();curorg!=organisms.end();++curorg) {
	delete (*curorg);
      }


    }

    //Delete the snapshots
    for(cursnap=generation_snapshots.begin();cursnap!=generation_snapshots.end();++cursnap) {
      delete (*cursnap);
    }

  }


};

#endif