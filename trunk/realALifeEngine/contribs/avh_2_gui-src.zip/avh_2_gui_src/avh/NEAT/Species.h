#ifndef __NEAT_SPECIES_H__
#define __NEAT_SPECIES_H__

#include "NEAT.h"

//Description: 

/* ---------------------------------------------  */
/* SPECIES CLASS:
   A Species is a group of similar Organisms      
   Reproduction takes place mostly within a
   single species, so that compatible organisms
   can mate.                                      */
/* ---------------------------------------------  */
class Species
{

 public:

  int id;

  int age;  //The age of the Species 
  
  double ave_fitness;  //The average fitness of the Species
  double max_fitness;  //Max fitness of the Species
  double max_fitness_ever;  //The max it ever had

  int expected_offspring;

  bool novel;

  bool checked;

  list<Organism*> organisms; //The organisms in the Species

  //list<Organism*> reproduction_pool;  //The organisms for reproduction- NOT NEEDED

  int age_of_last_improvement;  //If this is too long ago, the Species will goes extinct
  
  bool add_Organism(Organism *o);

  Organism *first();

  bool print_to_file(ofstream &outFile);

  //Change the fitness of all the organisms in the species 
  //to possibly depend slightly on the age of the species
  //and then divide it by the size of the species so that the
  //organisms in the species "share" the fitness
  void adjust_fitness();

  double compute_average_fitness(); 

  double compute_max_fitness();

  //Counts the number of offspring expected from all its members
  //skim is for keeping track of remaining fractional parts of offspring
  //and distributing them among species
  double count_offspring(double skim);

  //Compute generations since last improvement
  int last_improved() {
    return age-age_of_last_improvement;
  }

  //Remove an organism from Species
  bool remove_org(Organism *org);

  double size() {
    return organisms.size();
  }

  Organism *get_champ();

  //Perform mating and mutation to form next generation
  bool reproduce(int generation, Population *pop,list<Species*> &sorted_species);

  Species(int i) {
    id=i;
    age=1;
    ave_fitness=0.0;
    expected_offspring=0;
    novel=false;
    age_of_last_improvement=0;
    max_fitness=0;
    max_fitness_ever=0;
  }

  //Allows the creation of a Species that won't age (a novel one)
  //This protects new Species from aging inside their first generation
  Species(int i,bool n) {
    id=i;
    age=1;
    ave_fitness=0.0;
    expected_offspring=0;
    novel=n;
    age_of_last_improvement=0;
    max_fitness=0;
    max_fitness_ever=0;
  }


  ~Species() {
    
    list<Organism*>::iterator curorg;

    for(curorg=organisms.begin();curorg!=organisms.end();++curorg) {
      delete (*curorg);
    }

  }

};

#endif