#ifndef __NEAT_SPECIES_VIZ_H__
#define __NEAT_SPECIES_VIZ_H__

#include "NEAT.h"


/* The visualization of a generation is a list of all the Species visualizations
   of that generation */
struct Generation_viz {
  int gen_num;
  list<Species_viz*> species_list;
};

//Description: 

/* Special Structures for Speciation visualization */
class Species_viz
{
 public:
  int id;
  int size;
  double fitness;   //The average fitness
  double max_fitness;  //Max fitness for Species
  
  int startx;   //Starting x position on window
  int endx;     //Ending x position on window
  
  //The program can orient species along the x or y axis
  int starty;
  int endy;

  bool firstgen;  //Is it the Species' first generation?

  //A visualization of a Species is constructed off of that Species s
  Species_viz(Species *s) {
    id=s->id;
    size=(s->organisms).size();
    fitness=s->ave_fitness;
    max_fitness=s->max_fitness;
    startx=0;  //These positions will be computed later
    endx=0;
    if (s->age==1)
      firstgen=true; 
    else firstgen=false;
  }

};

#endif