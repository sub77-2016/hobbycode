#ifndef __NEAT_TRAIT_H__
#define __NEAT_TRAIT_H__

#include "NEAT.h"

//Description: 

/* ------------------------------------------------------------------ */
/* TRAIT: A Trait is a group of parameters that can be expressed     */
/*        as a group more than one time.  Traits save a genetic      */
/*        algorithm from having to search vast parameter landscapes  */
/*        on every node.  Instead, each node can simply point to a trait */
/*        and those traits can evolve on their own */
class Trait 
{

  /* ************ LEARNING PARAMETERS *********** */
  /* The following parameters are for use in    
     neurons that learn through habituation,
     sensitization, or Hebbian-type processes  */

 public:

  int trait_id;  //Used in file saving and loading

  //static const int num_params=8; //Now defined in neat.h instead

  double params[NEAT::num_trait_params];  //Keep traits in an array

  Trait () {
    for (int count=0;count<NEAT::num_trait_params;count++)
      params[count]=0;

    trait_id=0;
  }

  Trait(int id,double p1,double p2,double p3,double p4,double p5,double p6,double p7,double p8,double p9) {
    trait_id=id;

    params[0]=p1;
    params[1]=p2;
    params[2]=p3;
    params[3]=p4;
    params[4]=p5;
    params[5]=p6;
    params[6]=p7;
    params[7]=0;

  }

  //Create a trait exactly like another trait
  Trait(Trait *t) {
    for(int count=0;count<NEAT::num_trait_params;count++)
      params[count]=(t->params)[count];

    trait_id=t->trait_id;
  }


  //Special constructor off a file assume word "trait" has been read in
  Trait(ifstream &iFile) {

    //Read in trait id
    iFile>>trait_id;

    //IS THE STOPPING CONDITION CORRECT?  ALERT
    for(int count=0;count<NEAT::num_trait_params;count++)
      iFile>>params[count];

  }

  //Special Constructor creates a new Trait which is the average
  //of 2 existing traits passed in
  Trait(Trait *t1,Trait *t2) {
    for(int count=0;count<NEAT::num_trait_params;count++)
      params[count]=(((t1->params)[count])+((t2->params)[count]))/2.0;
    trait_id=t1->trait_id;
  }

  ~Trait() {
  }

  void print_to_file(ofstream &outFile);  //Dump trait to a file
  void mutate();  //Perturb the trait parameters slightly
  
  friend ostream& operator<< (ostream& os, const Trait *thetrait);
  
};

#endif