#ifndef __NEAT_UTILITIES_H__
#define __NEAT_UTILITIES_H__

//Guile Wrappers
Genome *new_Genome_fromfile(char *filename, int id);
Genome *new_Genome_load(char *filename);
Genome *display_Genome(char *filename, int width, int height);
int print_Genome_tofile(Genome *g,char *filename);
int print_Genome(Genome *g);
Population *new_Pop_fromfile(char *filename);
Population *new_Pop_fromGenomefile(char *filename);

list<Innovation*> *new_innov_list(); //Retrns a brand new empty list of innovations (for Guile)

/* Inline Random Functions */
inline bool randbit() {return rand()%2;}
inline int randposneg() {
  if (randbit()) return 1; 
  else return -1;
}
inline int randint(int x,int y) {return rand()%(y-x+1)+x;}
inline double randfloat() {return (rand())/(RAND_MAX+1.0);}

//Returns a normally distributed deviate with 0 mean and unit variance
//Algorithm is from Numerical Recipes in C, Second Edition
inline double gaussrand() {
  static int iset=0;
  static double gset;
  double fac,rsq,v1,v2;

  if (iset==0) {
    do {
      v1=2.0*((rand())/(RAND_MAX+1.0))-1.0;
      v2=2.0*((rand())/(RAND_MAX+1.0))-1.0;
      rsq=v1*v1+v2*v2;
    } while (rsq>=1.0 || rsq==0.0);
    fac=sqrt(-2.0*log(rsq)/rsq);
    gset=v1*fac;
    iset=1;
    return v2*fac;
  }
  else {
    iset=0;
    return gset;
  }
}

//This is an incorrect gassian distribution...but it is faster than gaussrand (maybe it's good enough?)
inline double gaussrand_wrong() {return (randposneg())*(sqrt(-log((rand()*1.0)/RAND_MAX)));}

//Conversion of types for graphics
void reverse(char *s);
char *itoa(int n,char s[]);

inline double fsigmoid(double,double,double); /* Sigmoid activation function- helper for NNode */

//This is used for list sorting of Organisms by fitness..highest fitness first
bool order_orgs(Organism *x, Organism *y) {
  return (x)->fitness > (y)->fitness;
}
  
//This is used for list sorting of Species by fitness of best organism
//highest fitness first
bool order_species(Species *x, Species *y) {

  //cout<<"Comparing "<<((*((x->organisms).begin()))->orig_fitness)<<" and "<<((*((y->organisms).begin()))->orig_fitness)<<": "<<(((*((x->organisms).begin()))->orig_fitness) > ((*((y->organisms).begin()))->orig_fitness))<<endl;

  return (((*((x->organisms).begin()))->orig_fitness) > 
	  ((*((y->organisms).begin()))->orig_fitness));
}

//Gene printing method
ostream& operator<< (ostream& os, const Gene *thegene) {
  Link *thelink=thegene->lnk;
  NNode *inode=thelink->in_node;
  NNode *onode=thelink->out_node;

  cout<<"[Link ("<<inode->node_id<<", "<<onode->node_id<<") INNOV ("<<thegene->innovation_num<<", "<<thegene->mutation_num<<")";
  cout<<" Weight "<<(thegene->lnk)->weight;
  if (((thegene->lnk)->linktrait)!=0)
    cout<<" Link's trait_id "<<((thegene->lnk)->linktrait)->trait_id;
  if (thegene->enable==false) cout<<"-DISABLED-";
  if (((thegene->lnk)->is_recurrent)) cout<<"RECUR";
  cout<<"]"<<endl;
  return os;

}

//Genome printing method
ostream& operator<< (ostream& os, const Genome *thegenome) {
  list<NNode*>::iterator curnode;
  list<Gene*>::iterator curgene;
  vector<Trait*>::iterator curtrait;

  list<NNode*> nodes=thegenome->nodes;
  list<Gene*> genes=thegenome->genes;
  vector<Trait*> traits=thegenome->traits;

  cout<<"GENOME START"<<endl;
  
  for(curnode=nodes.begin();curnode!=nodes.end();++curnode) {
    if (((*curnode)->gen_node_label)==INPUT) cout<<"I";
    else if (((*curnode)->gen_node_label)==OUTPUT) cout<<"O";
    else if (((*curnode)->gen_node_label)==HIDDEN) cout<<"H";
    else if (((*curnode)->gen_node_label)==BIAS) cout<<"B";
    cout<<(*curnode)<<" ";
  }
  cout<<endl;

  for(curgene=genes.begin();curgene!=genes.end();++curgene) {
    cout<<(*curgene)<<" ";
  }
  cout<<endl;

  cout<<"Traits: ";
  for(curtrait=traits.begin();curtrait!=traits.end();++curtrait) {
    cout<<(*curtrait)<<" ";
  }
  cout<<endl;

  cout<<"GENOME END"<<endl;

  return os;

}

ostream& operator<< (ostream& os, const Trait *thetrait) {
  if (thetrait==0) cout<<"EMPTY TRAIT"<<endl;
  else {

    cout<<"Trait #"<<thetrait->trait_id<<endl;
    for (int count=0;count<NEAT::num_trait_params;count++) {
      cout<<(thetrait->params)[count]<<" ";
    }
    cout<<endl; 
  }
}

//GUILE WRAPPERS
//This is a Guile Wrapper
Genome *new_Genome_fromfile(char *filename, int id) {

  Genome *newgenome;

  ifstream iFile(filename,ios::in);
  
  //Make sure it worked
  if (!iFile) {
    cerr<<"Can't open "<<filename<<" for input"<<endl;
    return 0;
  }

  newgenome=new Genome(id,iFile);

  iFile.close();

  return newgenome;

}

//Does not require knowing the genome id in order to load
Genome *new_Genome_load(char *filename) {
  Genome *newgenome;

  int id;

  char curword[20];  //max word size of 20 characters

  ifstream iFile(filename,ios::in);
  
  //Make sure it worked
  if (!iFile) {
    cerr<<"Can't open "<<filename<<" for input"<<endl;
    return 0;
  }

  iFile>>curword;
  
  iFile>>id;

  newgenome=new Genome(id,iFile);

  iFile.close();

  return newgenome;
}

//Display a graph of a Genome's resultant Network directly from a file
Genome *display_Genome(char *filename, int width, int height) {
  Genome *g;
  Network *n;

  //Get the Genome from the file
  g=new_Genome_load(filename);

  //Generate its network
  n=g->genesis(g->genome_id);
  
  //Graph the network
  n->graph(width,height);

  delete g;
  delete n;

}

int print_Genome_tofile(Genome *g,char *filename) {
  
  ofstream oFile(filename,ios::out);

  //Make sure it worked
  if (!oFile) {
    cerr<<"Can't open "<<filename<<" for output"<<endl;
    return 0;
  }

  g->print_to_file(oFile);

  oFile.close();

  return 1;

}

int print_Genome(Genome *g) {
  cout<<g<<endl;
  return 1;
}

/* Retrns a brand new empty list of innovations (for Guile) */
list<Innovation*> *new_innov_list() {
  list<Innovation*> *il=new list<Innovation*>();

  return il;
}

Population *new_Pop_fromfile(char *filename) {
  Population *newpop;

  newpop=new Population(filename);

  return newpop;;

}

Population *new_Pop_fromGenomefile(char *filename) {
  Population *newpop;
  Genome *spawner;

  ifstream iFile(filename,ios::in);
  
  //Make sure it worked
  if (!iFile) {
    cerr<<"Can't open "<<filename<<" for input"<<endl;
    return 0;
  }

  spawner=new Genome(0,iFile);

  iFile.close();

  newpop=new Population(spawner,NEAT::pop_size);

  delete spawner;

  return newpop;

}

#endif




