#include "SimulationController.h"

SimulationController* SimulationController::Instance()
{
   static SimulationController* instance = NULL;
   
   if (instance == NULL)
   {
      instance = new SimulationController();
   }

   return instance;
}

SimulationController::SimulationController()
{
	mStepSize = SIMULATION_STEP_SIZE;
	mODEWorld = new ODEWorld(GRAVITY, false);
}

SimulationController::~SimulationController()
{
	RemoveAllObjects();
	delete mODEWorld; // always do this last
}

void SimulationController::Step()
{
	mODEWorld->StepPhysics(mStepSize);
}

void SimulationController::DrawObjects()
{
	std::vector<Base3DObject*>::iterator iter;

	for (iter = mObjects.begin(); iter != mObjects.end(); iter++)
	{
		(*iter)->Draw();
	}
}

void SimulationController::AddObject(Base3DObject* object)
{
	mObjects.push_back(object);
}

void SimulationController::RemoveObject(Base3DObject* object)
{

}

void SimulationController::RemoveAllObjects()
{
	while (!mObjects.empty())
	{
		delete mObjects.back();
		mObjects.pop_back();
	}
}
