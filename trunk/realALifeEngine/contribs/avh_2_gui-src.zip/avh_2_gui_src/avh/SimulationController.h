#ifndef __AVH_SIMULATION_CONTROLLER_H__
#define __AVH_SIMULATION_CONTROLLER_H__

#include <iostream>
#include <assert.h>
#include <vector>

#include "../common/ODE/ODEWorld.h"
#include "../common/ODE/Base3DObject.h"
#include "../common/ODE/PC/Timer.h"

#define GRAVITY -9.81*7
#define SIMULATION_STEP_SIZE 0.01

//Description: SimulationController is a singleton object in control of
//all 3D objects in the simulation, including physically-simulated
//objects and simple graphical objects.  It encapsulates a std::vector
//of these objects and handles all collision detection & response.
//There are no critical sections in this class because it will never
//be accessed by another thread.

class SimulationController
{
public:
	static SimulationController* Instance();
	void Step();
	void DrawObjects();
	void AddObject(Base3DObject* object);
	void RemoveObject(Base3DObject* object);
	void RemoveAllObjects();
	ODEWorld* GetODEWorld() //Eventually, keep this private somehow...
	{
		return mODEWorld;
	}
	void ResetTimer()
	{
		mTimer.Reset();
	}
	double GetElapsedSeconds()
	{
		return mTimer.GetElapsedSeconds();
	}
	float GetStepSize()
	{
		return mStepSize;
	}
	void SetStepSize(float stepSize)
	{
		mStepSize = stepSize;
	}

private:
	SimulationController();
	~SimulationController();

   std::vector<Base3DObject*> mObjects;
	ODEWorld* mODEWorld;
	Timer mTimer;
	float mStepSize;
};

#endif
