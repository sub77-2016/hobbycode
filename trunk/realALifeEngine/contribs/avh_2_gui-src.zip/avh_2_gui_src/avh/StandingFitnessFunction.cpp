#include "StandingFitnessFunction.h"

StandingFitnessFunction::StandingFitnessFunction()
{
	mMaxTimeSteps = 500;
	mTimeStepsRemaining = 0;
	mHumanPtr = NULL;
	initialPosition.x = 0.0;
	initialPosition.y = 4.7*BODY_SIZE;
	initialPosition.z = 0.0;
	mCutoffHeight = 5.0;
	SetupEnvironment();
}

StandingFitnessFunction::~StandingFitnessFunction()
{
	DestroyEnvironment();
}

void StandingFitnessFunction::SetupEnvironment()
{
	ODEWorld* world = SimulationController::Instance()->GetODEWorld();

	//creating the ground platform
	ODEObject* ground = new ODEBox(world, false, false, "", "", 0, -1, 0, 40, 2, 40);
	point3d startPoint = {0, -1, 0};
	ground->SetPosition(startPoint);
	SimulationController::Instance()->AddObject(ground);

	//creating the human's body
	mHumanPtr = new ODEHuman(world, false, initialPosition.x, initialPosition.y, initialPosition.z, BODY_SIZE);
	//mHumanPtr->SetBrain(evolutionController->GetFirstBrain());
	SimulationController::Instance()->AddObject(mHumanPtr);
}

void StandingFitnessFunction::DestroyEnvironment()
{
	SimulationController::Instance()->RemoveAllObjects();
}

bool StandingFitnessFunction::EvaluatePopulation(std::list<NeuralNet*> brainList)
{
	bool returnValue; //return true if we should quit early
	std::list<NeuralNet*>::iterator iter;

	for (iter = brainList.begin(); iter != brainList.end(); iter++)
	{
		returnValue = EvaluateIndividual(*iter);

		if (true == returnValue)
		{
			return true;
		}
	}

	return false;
}

bool StandingFitnessFunction::EvaluateIndividual(NeuralNet* nn)
{
	assert(mHumanPtr);

	mHumanPtr->SetInitialPosition(initialPosition);
	mHumanPtr->SetBrain(nn);

	bool returnValue = false; //return true if we should quit early
	mTimeStepsRemaining = mMaxTimeSteps;
	float averageHeight = 0;
	float mTimeStepsUsed = 0;

	SimulationController::Instance()->ResetTimer();

	while (mTimeStepsRemaining > 0 && mHumanPtr->GetHeadPosition().y > mCutoffHeight)
	{
		double deltaTime = 0.0;
		float stepSize = SimulationController::Instance()->GetStepSize();

		if (true == GraphicsController::Instance()->GetVisualMode())
		{
			deltaTime = SimulationController::Instance()->GetElapsedSeconds();
		}
		else
		{
			deltaTime = SIMULATION_FRAME_TIME;
		}

		while (deltaTime >= stepSize)
		{
			SimulationController::Instance()->Step();
			mHumanPtr->UseBrain();
			deltaTime -= stepSize;

			averageHeight += mHumanPtr->GetHeadPosition().y;
			mTimeStepsUsed++;
			mTimeStepsRemaining--;
		}

		//The following call will check input and redraw only if visual mode
		//has been enabled.
		GraphicsController::Instance()->Update();

		//check if we should quit early
		if (true == GetStopRequested())
		{
			returnValue = true;
		}

		// Let the GUI update itself; this will make the GUI more responsive.
		wxThread* thread =  wxThread::This();
		if(NULL != thread)
		{
			thread->Yield();
		}
	}

	float fitness = averageHeight/mTimeStepsUsed;

	//penalty for sliding feet apart
	fitness -= mHumanPtr->ZDistanceBetweenFeet();

	//penalty for falling below threshold height; penalty is greater for falling sooner
	if (mTimeStepsRemaining > 0)
	{
		fitness = fitness / mTimeStepsRemaining;
	}

	nn->SetFitness(fitness);

	return returnValue;
}

//void StandingFitnessFunction::TestIndividual(NeuralNet* nn)
//{
//}
