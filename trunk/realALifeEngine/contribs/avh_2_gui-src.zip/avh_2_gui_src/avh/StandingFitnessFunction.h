#ifndef __AVH_STANDING_FITNESS_FUNCTION_H__
#define __AVH_STANDING_FITNESS_FUNCTION_H__

#include "SimulationController.h"
#include "FitnessFunction.h"
#include "../common/ODE/ODEHuman.h"

#define BODY_SIZE 1.3

//Description: StandingFitnessFunction is a FitnessFunction class used
//to evolve/test standing behavior.

class StandingFitnessFunction : public FitnessFunction
{
public:
	StandingFitnessFunction();
	~StandingFitnessFunction();
	virtual bool EvaluatePopulation(std::list<NeuralNet*> brainList);
	//virtual void TestIndividual(NeuralNet* nn);

protected:
	bool EvaluateIndividual(NeuralNet* nn);
	void SetupEnvironment();
	void DestroyEnvironment();

	ODEHuman* mHumanPtr;
	point3d initialPosition;
	long int mTimeStepsRemaining;
	float mCutoffHeight;
};

#endif
