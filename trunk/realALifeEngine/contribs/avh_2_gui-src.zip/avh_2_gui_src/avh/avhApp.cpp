// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#if wxUSE_STD_IOSTREAM
//Good.  This enables wxStreamToTextRedirector usage.
#else
#define wxUSE_STD_IOSTREAM 1
#endif

#include "avhApp.h"
#include "MainFrame.h"

/*********************Static Libraries***********************/
#ifdef WIN32

//#include <wx/msw/private.h> //required for wxGetInstance()

// This is a compiler directive that includes libraries (For Visual Studio)
//#pragma comment(lib, "odbc32.lib")
//#pragma comment(lib, "odbccp32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "wsock32.lib")
//#pragma comment(lib, "zlibd.lib")
//#pragma comment(lib, "regexd.lib")
//#pragma comment(lib, "pngd.lib")
//#pragma comment(lib, "jpegd.lib")
//#pragma comment(lib, "tiffd.lib")

#pragma comment(lib, "wxmswd.lib") //debug library

#pragma comment(lib, "SDL.lib")

//not needed since we're using wxWidgets' WinMain and calling SDL_SetModuleHandle(wxGetInstance());
//#pragma comment(lib, "SDLmain.lib") 

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "opcode.lib")
#pragma comment(lib, "ode.lib")
#pragma comment(lib, "corona.lib")

#endif
/************************************************************/

IMPLEMENT_APP(avhApp)
//IMPLEMENT_APP_NO_MAIN(avhApp)

bool avhApp::OnInit()
{
	//SDL_SetModuleHandle(wxGetInstance()); 
	SDL_SetModuleHandle(GetModuleHandle(NULL)); //not really necessary?

   mFrame = new MainFrame("Autonomous Virtual Humans", wxPoint(50,50), wxSize(500,600));
   mFrame->Show(true);
   SetTopWindow(mFrame);
   return true;
}
