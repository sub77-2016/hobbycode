#ifndef __AVH_APP_H__
#define __AVH_APP_H__

#include <wx/app.h>

class MainFrame;

//Description: avhApp is the main application class.  Note: the GUI classes
//(wxWidgets classes) should send messages to the EvolutionController, the
//SimulationController, and the GraphicsController.  The GUI shouldn't try 
//to make changes to these controllers directly because they run in a 
//separate thread.

class avhApp: public wxApp
{
public:
	//~avhApp();
	bool OnInit();

private:
	void EmergencyKillEvolutionThread();

	MainFrame *mFrame;
};

//Not needed: now using the Listener class instead.
//DECLARE_APP(avhApp); //Creates global access to the avhApp instance through wxGetApp();

#endif