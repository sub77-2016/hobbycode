//NNGeneString.h
//Author: Tyler Streeter

#ifndef __NNGENESTRING_H__
#define __NNGENESTRING_H__

#include "Neuron.h"
#include <stdlib.h>
#include <iostream>

#define FRAND (((float)rand()-(float)rand())/RAND_MAX) // returns a number ranging from -1.0 to 1.0
#define MUTATION_CHANCE 0.25 // 25/100 chance that each neuron is mutated
#define MUTATION_AMOUNT 0.1f //this value is added or subtracted to each weight when mutated

//the following returns a discrete (tenth) value between -1.0 and 1.0 (e.g. -1.0, -0.9 ... 0.8, 1.0)
//#define DISCRETE_FRAND (((float)((int)(FRAND*10.0)))/10.0)

//#define CONTINUOUS_WEIGHT_VALUES 0

class NNGeneString
{
public:
	NNGeneString(int numInputs, int numOutputs, int numHiddenLayers, 
						   int* hLayerSizes, Neuron*** listOfLayers);
	~NNGeneString();

	int numberOfInputs;
	int numberOfOutputs;
	int numberOfHiddenLayers;
	int* hiddenLayerSizes;
	float*** weights;
};

#endif
