//NeuralNet.h
//Author: Tyler Streeter

#ifndef __NEURALNET_H__
#define __NEURALNET_H__

#include "Neuron.h"
#include "NNGeneString.h"
#include <stdlib.h>
#include <time.h>

// returns a number ranging from -1.0 to 1.0
#define FRAND (((float)rand()-(float)rand())/RAND_MAX)

//struct NNGeneString
//{
//	int numberOfInputs;
//	int numberOfOutputs;
//	int numberOfHiddenLayers;
//	int* hiddenLayerSizes;
//	float*** weights;
//};

class NeuralNet
{
public:
	NeuralNet(int numInputs, int dimensions[], int numOutputs, int actFunction=0); //randomly created
	NeuralNet(NNGeneString* genes, int actFunction=0); //create from given genes
	NeuralNet(int numInputs, int brainSize[], int numOutputs, FILE* inputFile, int actFunction=0); //read from file
	~NeuralNet();

	void Compute(float inputs[], float outputs[]);
	double GetFitness();
	void SetFitness(double f);
	NNGeneString* GetGenes();
	void PrintGenesToFile(FILE* outputFile);

private:
	int activationFunction;
	int numHiddenLayers;
	int* hiddenLayerSizes;
	int numberOfInputs;
	int numberOfOutputs;
	Neuron*** listOfLayers; //includes all layers, including input layer
	NNGeneString* genes;
	double fitness;
public:
	void TestOutput();//use this to make sure each random brain is different

	friend void CrossoverAndMutation(NeuralNet* parent1, NeuralNet* parent2, NNGeneString* &child1, NNGeneString* &child2);
};

#endif
