//Neuron.h
//Author: Tyler Streeter

#ifndef __NEURON_H__
#define __NEURON_H__

#include <math.h>

class Neuron
{
public:
	//numInputs=0, prevLayer=null, and weights=null for input layer
	Neuron(int numInputs, Neuron* prevLayer[], float weights[], int actFunction=0);
	~Neuron();

	void CalculateOutput();
	float GetOutput();
	void SetOutput(float value); //used only for input layer
	float* GetInputWeights();

private:
	float ThresholdFunction(float input);
	float SigmoidFunction(float input);
	float SineFunction(float input);

	int activationFunction;
	int numberOfInputs;
	Neuron** inputList; //will remain null if within input layer
	float* inputWeights; //will remain null if within input layer
	float outputValue;
};

#endif
