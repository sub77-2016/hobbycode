// Base3DObject.h
// Base class for all 3D objects.

#ifndef __BASE_3D_OBJECT_H__
#define __BASE_3D_OBJECT_H__

#include "OBJModel.h"
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#include <ode/ode.h>

#define	RADTODEGREES 57.2957795130823208768f	//!< 180.0 / PI, convert radians to degrees
#define	DEGTORADIANS 0.01745329251994329577f	//!< PI / 180.0, convert degrees to radians

//The following define helps us determine when to build display lists.
#define USING_VR_JUGGLER 0

typedef struct point3d
{
	dReal x, y, z;
} point3d;

typedef struct vector3d
{
	dReal x, y, z;
} vector3d;

class Base3DObject
{
public:
	Base3DObject(bool ODEObject, bool model, std::string dir, std::string file, 
		dReal posx, dReal posy, dReal posz);
	virtual ~Base3DObject();
	virtual void SetPosition(point3d newposition);
	virtual point3d GetPosition();
	virtual void SetOrientation(int axis, dReal angle);
	//virtual point3d GetOrientation();
	virtual void Draw();
	bool IsODEObject();
	bool Has3DModel();
	virtual void MakeDisplayList();
	void SetTransparency(bool transparent);
	virtual bool Update(dReal deltaTime);

protected:
	point3d position;
	//point3d orientation; //Euler angles

	// Context-Specific Data -> handle differently in VRJuggler
#ifdef USING_VRJUGGLER //using Juggler's special context-specific data types
	vrj::GlContextData<GLuint> displayListNumber; //this model's display list ID
#else //using normal data types
	int displayListNumber; //this model's display list ID
#endif

	bool thisIsTransparent;
	bool isODEObject; //is an ODE object
	bool has3DModel; //load model from file
	std::string filename;
	std::string dirname;
	COBJModel* thisModel; //pointer to obj model data
	
	//bounding box extremes, center, dimensions
	point3d bboxMin;
	point3d bboxMax;
	point3d bboxCenter;
	point3d modelDimensions;
};

#endif
