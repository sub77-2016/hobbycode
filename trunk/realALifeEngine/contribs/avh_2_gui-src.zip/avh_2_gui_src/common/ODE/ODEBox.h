//ODEBox.h
//3D box class with ODE support
//Author: Tyler Streeter

#ifndef __ODEBOX_H__
#define __ODEBOX_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include <string>
#include <ode/ode.h>

class ODEBox : public ODEObject
{
public:
	ODEBox(ODEWorld* world, bool body, bool model, std::string dir, std::string file, 
			   dReal posx, dReal posy, dReal posz, dReal sizex, dReal sizey, dReal sizez);
	~ODEBox();

	void Draw();
	dReal GetXDimension();
	dReal GetYDimension();
	dReal GetZDimension();

private:
	dReal myDimensions[3];
	void DrawBox();
};

#endif
