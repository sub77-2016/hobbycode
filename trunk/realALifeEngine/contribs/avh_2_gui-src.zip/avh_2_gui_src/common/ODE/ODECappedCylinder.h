//ODECappedCylinder.h
//3D capped cylinder class with ODE support
//Author: Tyler Streeter

#ifndef __ODECAPPEDCYLINDER_H__
#define __ODECAPPEDCYLINDER_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include <string>
#include <ode/ode.h>

class ODECappedCylinder : public ODEObject
{
public:
	ODECappedCylinder(ODEWorld* world, bool body, bool model, std::string dir, std::string file,
					 dReal posx, dReal posy, dReal posz, dReal rad, dReal l);
	~ODECappedCylinder();

	void Draw();
	dReal GetRadius();
	dReal GetLength();

private:
	dReal radius;
	dReal length;
};

#endif
