//ODEHuman.h
//Author: Tyler Streeter

#ifndef __ODEHUMAN_H__
#define __ODEHUMAN_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include "ODESphere.h"
#include "ODEBox.h"
#include "../AI/NeuralNet.h"
#include <ode/ode.h>

#define NUM_BRAIN_INPUTS 15
#define NUM_BRAIN_OUTPUTS 11

//#define PI 3.1416
//#include "MathsStruct.h" //temporarily

class ODEHuman : public ODEObject
{
public:
	ODEHuman(ODEWorld* world, bool model, dReal posx, dReal posy, dReal posz, dReal size);
	~ODEHuman();

	void SetInitialPosition(point3d newposition);
	point3d GetPosition();
	void SetTotalVelocity(vector3d velocity);
	void UseBrain();
	void SetBrain(NeuralNet* newBrain);
	point3d GetHeadPosition();
	dReal ForwardDistanceOfFeet();
	float ZDistanceBetweenFeet();
	float CombinedFeetHeight();
	dReal LeftFootHeight();
	dReal RightFootHeight();
	bool RightFootMovingDownward();
	bool LeftFootMovingDownward();
	void Draw();
	void AddForce(dReal x, dReal y, dReal z);
	void SetFloats(bool doesFloat);
	void DampenVelocity(dReal dampingAmount);
	void MakeDisplayList();

private:
	//float HeadDistanceAheadOfTorso();
	//float maxHeadDistanceAheadOfTorso;
	float HeadHeightAboveFeet();
	//float maxHeadHeightAboveFeet;

	NeuralNet* brain;

	//quaternion to store initial body part orientations
	dQuaternion initialQuaternion;

	ODESphere* head;
	//ODEBox* head;
	ODEBox* torso;
	ODEBox* leftUpperArm;
	ODEBox* rightUpperArm;
	ODEBox* leftLowerArm;
	ODEBox* rightLowerArm;
	ODEBox* leftUpperLeg;
	ODEBox* rightUpperLeg;
	ODEBox* leftLowerLeg;
	ODEBox* rightLowerLeg;
	ODEBox* leftFoot;
	ODEBox* rightFoot;

	dJointID leftElbow;
	dJointID rightElbow;
	dJointID leftShoulder;
	dJointID rightShoulder;
	dJointID neck;
	dJointID leftHip;
	dJointID rightHip;
	dJointID leftKnee;
	dJointID rightKnee;
	dJointID leftAnkle;
	dJointID rightAnkle;

	//dSpaceID thisSpaceID;
};

#endif
