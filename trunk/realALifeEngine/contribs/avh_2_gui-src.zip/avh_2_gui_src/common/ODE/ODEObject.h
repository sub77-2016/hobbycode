//ODEObject.h
//Base 3D object class with ODE support
//Author: Tyler Streeter

#ifndef __ODE_OBJECT_H__
#define __ODE_OBJECT_H__

#include "Base3DObject.h"
#include <string>
#include <ode/ode.h>

#define PI 3.14159265358979323846f
#define	DEG2RAD(x) (((x)*PI)/180.0)
#define	RAD2DEG(x) (((x)*180.0)/PI)

#define MAX_MASS 100
#define MIN_MASS 0.5
#define AUTO_DISABLE_THRESHOLD (dReal)0.1 //used for motion damping

class ODEObject : public Base3DObject
{
public:
	//ODEObject();
	ODEObject(bool body, bool model, std::string dir, std::string file, 
					 dReal posx, dReal posy, dReal posz);
	virtual ~ODEObject();
	virtual void Draw();
	virtual bool Update(dReal deltaTime);
	void SetPosition(point3d newposition);
	point3d GetPosition();
	void SetOrientation(int axis, dReal angle); //crude for now
	//point3d GetOrientation();

	void SetVelocity(vector3d velocity);
	vector3d GetVelocity();
	point3d GetLastPosition();

	dBodyID GetBodyID();
	void SetBodyID(dBodyID newBodyID);
	dGeomID GetGeomID();
	void SetGeomID(dGeomID geomID);
	bool HasBody();
	virtual void MakeDisplayList();
	virtual void SetFloats(bool doesFloat);
	bool Floats();
	virtual void AddForce(dReal x, dReal y, dReal z);
	virtual void DampenVelocity(dReal dampingAmount);
	void SetMass(dReal newMass);

protected:

	// ODE stuff
	dBodyID thisBodyID;
	dGeomID thisGeomID;
	//vector3d velocity;
	bool hasBody;
	bool floats;
	point3d lastPosition;
};

#endif
