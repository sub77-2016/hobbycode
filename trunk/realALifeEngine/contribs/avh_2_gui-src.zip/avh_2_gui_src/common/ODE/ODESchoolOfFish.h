//ODESchoolOfFish.h
//Author: Tyler Streeter

#ifndef __ODESCHOOLOFFISH_H__
#define __ODESCHOOLOFFISH_H__

#include <list>
#include "ODEObject.h"
#include "ODEWorld.h"
#include "ODEBox.h"
#include <ode/ode.h>

#define FISH_MODELS_DIR "../data"
#define FISH_FILENAME "codfish.obj"
#define FISH_LENGTH 2
#define SWIMMING_STRENGTH 20
#define MAX_FISH_SPEED 15
#define UNDERWATER_DAMPING_FACTOR 1.03
#define WATER_LEVEL 0
#define SEPARATION_DISTANCE 7 //used for boids separation rule

class ODESchoolOfFish : public ODEObject
{
public:
	ODESchoolOfFish(ODEWorld* world, dReal posx, dReal posy, dReal posz, int numFish,
		std::list<Base3DObject*>* objectList);
	~ODESchoolOfFish();

	//void SetInitialPosition(point3d newposition);
	//point3d GetPosition();
	void Draw();
	void MakeDisplayList();
	bool Update(dReal deltaTime);
	//void AddFishToGlobalObjectList(std::list<Base3DObject*> objectList);

private:
	void UseBoidsRules(ODEBox* fish); //(http://www.red3d.com/cwr/boids/)
	void UpdateAverageHeading();
	void UpdateAveragePosition();
	vector3d UnifyVector(vector3d vec);
	dReal Distance3D(point3d point1, point3d point2);
	vector3d VectorCrossProduct(vector3d vec1, vector3d vec2);
	void VectorToAngles(vector3d a, vector3d &theta);
	int sign(float a);
	//bool VectorHasLengthZero(vector3d vec);

	std::list<ODEBox*> fishList;
	vector3d averageHeading;
	point3d averagePosition;
	int numberOfFish;
	dReal fishThinkingPeriod;
};

#endif
