//ODESphere.h
//3D sphere class with ODE support
//Author: Tyler Streeter

#ifndef __ODESPHERE_H__
#define __ODESPHERE_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include <string>
#include <ode/ode.h>

class ODESphere : public ODEObject
{
public:
	ODESphere(ODEWorld* world, bool body, bool model, std::string dir, std::string file,
					 dReal posx, dReal posy, dReal posz, dReal rad);
	~ODESphere();

	void Draw();
	dReal GetRadius();

private:
	dReal radius;

};

#endif
