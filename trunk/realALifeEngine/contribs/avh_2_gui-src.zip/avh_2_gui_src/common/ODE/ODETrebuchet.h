//ODETrebuchet.h
//Author: Tyler Streeter

#ifndef __ODETREBUCHET_H__
#define __ODETREBUCHET_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include "ODEBox.h"
#include <ode/ode.h>

#define TREBUCHET_MODELS_DIR "../data"
#define TREBUCHET_FRAME_FILENAME "trebuchet_frame.obj"
#define TREBUCHET_SHAFT_FILENAME "trebuchet_shaft.obj"
#define TREBUCHET_BALLAST_FILENAME "trebuchet_ballast.obj"
#define TREBUCHET_GUARD_FILENAME "trebuchet_guard.obj"

class ODETrebuchet : public ODEObject
{
public:
	ODETrebuchet(ODEWorld* world, dReal posx, dReal posy, dReal posz);
	~ODETrebuchet();

	//void SetInitialPosition(point3d newposition);
	//point3d GetPosition();
	void Draw();
	void MakeDisplayList();
	void Launch();
	void Reset();
	bool IsLaunched();

private:
	//quaternion to store initial part orientations
	//dQuaternion initialQuaternion;

	Base3DObject* frame;
	ODEBox* shaft;
	ODEBox* guard;
	ODEBox* ballast;

	dJointID shaftToFrame;
	dJointID shaftToBallast;
	dJointID shaftToGuard;

	bool launched; //keep track of what position it is in
};

#endif
