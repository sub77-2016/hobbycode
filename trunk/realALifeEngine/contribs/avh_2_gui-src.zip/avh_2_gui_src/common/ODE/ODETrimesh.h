//ODETrimesh.h
//3D Trimesh class with ODE support
//Author: Tyler Streeter

#ifndef __ODETRIMESH_H__
#define __ODETRIMESH_H__

#include "ODEObject.h"
#include "ODEWorld.h"
#include <string>
#include <ode/ode.h>

//struct StridedVertex {
//  dVector3 Vertex;  // 4th component can be left out, reducing memory usage
//  // Userdata
//};
//
//struct StridedTri {
//  int Indices[3];
//  // Userdata
//};

//typedef dReal dVector3R[3];

class ODETrimesh : public ODEObject
{
public:
	ODETrimesh(ODEWorld* world, dReal posx, dReal posy, dReal posz, 
					   std::string dirname, std::string filename);
	~ODETrimesh();

	void Draw();

private:
	dTriMeshDataID thisTrimeshDataID;

	//vertex data
	int numVertices;
	//dReal* vertexArray;
	dVector3* vertexArray;
	//StridedVertex* vertexArray;
	//dReal* vertexArray;

	//face data
	int numFaces;
	int* faceArray;
	//StridedTri* faceArray;
	//int** faceArray;
};

#endif
