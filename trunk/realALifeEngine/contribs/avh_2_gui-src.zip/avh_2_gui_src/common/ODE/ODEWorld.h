//ODEWorld.h
//ODE world class
//Author: Tyler Streeter

#ifndef __ODEWORLD_H__
#define __ODEWORLD_H__

#include <ode/ode.h>

#define MAX_CONTACT_POINTS 64
//#define TIME_MULTIPLIER 2 //don't go much above 5
#define STEP_ITERATIONS 3
//#define STEP_SIZE 0.03 //0.03 looks like real-time
#define AUTO_DISABLE_THRESHOLD (dReal)0.1

class ODEWorld
{
public:
	ODEWorld(dReal gravity, bool useFPSFriction);
	~ODEWorld();

	void StepPhysics(dReal stepSize);
	//void ResetTimer(); //use this for window resizes

	dWorldID GetWorldID();
	dSpaceID GetSpaceID();

	dReal GetRayIntersectionDepth();

private:
	dWorldID theDynamicsWorldID;
	dSpaceID theCollisionSpaceID;
	dJointGroupID theJointGroupID;
	dReal rayIntersectionDepth; //hack to keep track of ray penetration depth
};

//Helper function (this must not be a member of ODEWorld since we are passing its address as an argument)
void PotentialHitCallback(void *data, dGeomID o1, dGeomID o2);

#endif
