#include "Timer.h"
#include <iostream>

Timer::Timer()
{
	Reset();
}

void Timer::Reset()
{
   timeb timeBuffer;
   ftime(&timeBuffer);

	lastTime = timeBuffer.time;
	lastTime += timeBuffer.millitm*0.001;
}

double Timer::GetElapsedSeconds()
{
   timeb timeBuffer;
   ftime(&timeBuffer);

	double currentTime = timeBuffer.time;
	currentTime += timeBuffer.millitm*0.001;

	double elapsedSeconds = currentTime - lastTime;
	lastTime = currentTime;

	return elapsedSeconds;
}

//Old, less accurate way...
//float Timer::GetElapsedSeconds()
//{
//	clock_t currentTime = clock();
//	float elapsedMilliseconds = (float)((float)(currentTime-lastTime)/((float)CLOCKS_PER_SEC/1000.0));
//	lastTime = currentTime;
//	
//	//if (elapsedMilliseconds <= 0)
//	//{
//	//	elapsedMilliseconds = 1;
//	//}
//
//	return elapsedMilliseconds/1000;
//}
