#ifndef __TIMER_H__
#define __TIMER_H__

#include <sys/timeb.h>

class Timer 
{
public:
	Timer(); 
	void Reset();
	double GetElapsedSeconds();

private:
	double lastTime;
};

#endif
