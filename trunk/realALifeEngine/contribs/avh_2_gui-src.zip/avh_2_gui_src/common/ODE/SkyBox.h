// SkyBox.h

#ifndef __SKYBOX_H__
#define __SKYBOX_H__

#include "Base3DObject.h"
#include <corona.h>
#include <string>

/////////////////////////////////////////////////////////////////////////////////
//
// * QUICK NOTES * 
//
// This tutorial shows you how to create a sky box.  A sky box is just a box that
// has textures assigned to it which create an illusion that you are actually in
// a intricate world.  This is great because it it's fast to draw and looks cool in
// the background.  There are a lot of these textures all over the web.
// How this works is, we create a box, and then assign the top, bottom, left, right,
// back and front textures to each side of the box accordingly.  This will make it
// look like we are in a cool world, not an ugly box :).  I struggled with adding
// camera support to this tutorial, but eventually gave in.  Though it might complicate
// an easy tutorial I figured there is no way to really get the effect without being
// able to look around.  You can use the mouse to look around, and the arrow keys
// to move within the sky box.  This tutorial was taken partly from the RotateCube
// tutorial.  I grabbed the camera and texture code from the TextureMap and Camera3 tuts.
//
// One IMPORTANT thing when using textures for sky maps is that
// the default GL_TEXTURE_WRAP_S and ""_WRAP_T texture property is GL_REPEAT.
// We need to turn this to GL_CLAMP_TO_EDGE, otherwise it creates ugly seems
// in our sky box.  GL_CLAMP_TO_EDGE does not repeat when bound to an object.
// To set this texture property we added these 2 lines to CreateTexture();
//
// glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
// glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
//
//
// The textures used in this tutorial were created by Nick Coombe at
// http://www.planethalflife.com/crinity  | email: crinity@email.com.  I appreciate
// his artistic talent and for letting me use these for this tutorial and on our CD.
// Check out his site, it is REALLY cool.  There are tons more of these textures.
//
//
// Ben Humphrey (DigiBen)
// Game Programmer
// DigiBen@GameTutorials.com
// Co-Web Host of www.GameTutorials.com
// � 2000-2003 GameTutorials
//

/////////////////////////////////////////////////////////////////////////////////
//
// * QUICK NOTES * 
//	
// In this tutorial we added the CreateTexture() function from out texture
// map tutorial.  There were some things we changed to this function though.
// We turned GL_CLAMP_TO_EDGE on instead of the default texture property GL_REPEAT. 
// That way it doesn't give us those ugly artifacts in the corners of our
// sky map. 
//
// We also turned on texture mapping with glEnable(GL_TEXTURE_2D);
// Plus one last thing is we change gluPerspective() to 500 far distance
// instead of 150.  This is because our Sky Box is a lot larger than 150.
//
//
// Ben Humphrey (DigiBen)
// Game Programmer
// DigiBen@GameTutorials.com
// Co-Web Host of www.GameTutorials.com
//
// 

// This is a compiler directive that includes libraries (For Visual Studio)
//#pragma comment(lib, "glaux.lib") // Added for texture mapping

#define BACK_ID		0					// The texture ID for the back side of the cube
#define FRONT_ID	1					// The texture ID for the front side of the cube
#define BOTTOM_ID	2					// The texture ID for the bottom side of the cube
#define TOP_ID		3					// The texture ID for the top side of the cube
#define LEFT_ID		4					// The texture ID for the left side of the cube
#define RIGHT_ID	5					// The texture ID for the right side of the cube

#define MAX_TEXTURES 100				// The maximum amount of textures to load

// We need to define this for glTexParameteri()
#define GL_CLAMP_TO_EDGE	0x812F		// This is for our skybox textures

class SkyBox : public Base3DObject
{
public:
	SkyBox(dReal posx, dReal posy, dReal posz, dReal Width, dReal Height, dReal Length);
	~SkyBox();
	void Draw();
	bool Update(dReal deltaTime);

private:
	//void CreateTexture(UINT textureArray[], std::string strFileName, int textureID);
	GLuint CreateTexture(std::string filename);
	void MakeDisplayList();

	float x, y, z, width, height, length;

	// Context-Specific Data -> handle differently in VRJuggler
#ifdef USING_VRJUGGLER //using Juggler's special context-specific data types
	vrj::GlContextData<GLuint> g_Texture[MAX_TEXTURES]; //this model's texture IDs
#else //using normal data types
	GLuint g_Texture[MAX_TEXTURES];		// This holds the texture info, referenced by an ID
#endif

};

#endif
