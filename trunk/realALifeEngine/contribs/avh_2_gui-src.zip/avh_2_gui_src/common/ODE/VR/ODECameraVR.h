//ODECameraVR.h
//Camera with ODE support; for use in a VR environment.
//Author: Tyler Streeter

#ifndef __ODECAMERAVR_H__
#define __ODECAMERAVR_H__

#include "ODEObject.h"
#include "ODEWorld.h"
//#include "stdafx.h"
#include "ODESphere.h"
#include <ode/ode.h>

class ODECameraVR : public ODEObject
{
public:
	ODECameraVR(ODEWorld* world, dReal posx, dReal posy, dReal posz, dReal height);
	~ODECameraVR();

	void PlaceCamera();
	void Draw();
	//double GetRadius();
	//dReal GetHeight();
	void AddRotation(dReal xAxis, dReal yAxis);
	void SetLinearVelocity(dReal x, dReal y, dReal z);
	void MoveForward();
	void MoveBackward();
	void MoveLeft();
	void MoveRight();
	void Jump();
	void ZeroXZForces();
	void DampenXZVelocity(dReal dtime);
	void WaterDamping(dReal dtime);
	vector3d GetForwardVector();
	void SetForwardVector(vector3d forward);
	void UpdateCameraMovement(dReal dtime);

private:
	dReal radius; //radius of bounding sphere; eye level is center of sphere
	dReal pitch;
	dReal yaw;
	dReal dampingFactor;
	vector3d lookAt;
	vector3d forwardVector;
	vector3d upVector;
	dReal cameraSpeedScalar; //scalar used to adjust camera speed
	dReal maxCameraSpeed; //limit on camera speed
	dReal jumpingPowerScalar;
	bool underwaterfog; //used for fog color

	//ray used to test how high up the camera is above the ground
	dGeomID altitudeRayID;
	dReal maxImportantRayIntersectionLength;

	ODEWorld* theWorld;
};

vector3d UnifyVector(vector3d vec);
vector3d VectorCrossProduct(vector3d vec1, vector3d vec2);

#endif
