#include "TimerVR.h"
#include <iostream>

Timer::Timer(vpr::Interval currentTime)
{
	//std::cout << "Initializing Timer - CLOCKS_PER_SEC = " << CLOCKS_PER_SEC << std::endl << std::endl;
	Reset(currentTime);
}

void Timer::Reset(vpr::Interval currentTime)
{
	//startTime.setNow();
	lastTime = currentTime;
}

float Timer::GetElapsedSeconds(vpr::Interval currentTime)
{
//	vpr::Interval currentTime;
//	currentTime.setNowReal();

	vpr::Interval elapsedTime(currentTime - lastTime);
	lastTime = currentTime;

	return elapsedTime.secf();



//	float elapsedSeconds = currentTime.secf() - lastTime.secf();
//	lastTime = currentTime;
	
//	return elapsedSeconds;
}
