#ifndef __TIMER_H__
#define __TIMER_H__

#include <time.h>
#include <ode/timer.h>
#include <vrj/Draw/OGL/GlApp.h>

using namespace vrj;

class Timer 
{
public:
	Timer(vpr::Interval currentTime); 
	void Reset(vpr::Interval currentTime);
	float GetElapsedSeconds(vpr::Interval currentTime);

private:  
	//vpr::Interval startTime;
	vpr::Interval lastTime;
};

#endif
