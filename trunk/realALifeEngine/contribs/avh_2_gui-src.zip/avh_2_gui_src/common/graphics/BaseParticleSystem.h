//ParticleSystem.h
//Base Particle System class that contains the Particle struct
//Author: Matt Newcomb

#ifndef __PARTICLE_SYSTEM_H__
#define __PARTICLE_SYSTEM_H__

#if _MSC_VER > 1000
#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif // _MSC_VER > 1000

#ifdef VJ_API_OPENGL
#define USING_VRJUGGLER
#include <vrj/Draw/OGL/GlContextData.h>
#endif

#include <GL/gl.h>
//#include <GL/glu.h>
//#include <GL/glut.h>
#include "../ODE/Base3DObject.h"
#include <assert.h>

// We need to define this for glTexParameteri()
#define GL_CLAMP_TO_EDGE	0x812F		// This is for our skybox textures

// returns a number ranging from -1.0 to 1.0
#define FRAND (((float)rand()-(float)rand())/RAND_MAX) 

typedef struct  					// Create A Structure For Particle
{
	bool	active;					// Active (Yes/No)
	float	life;					// Particle Life
	float	fade;
	float	size;
	float   r,g,b;
	float   x,y,z;
	float	xi,yi,zi;

}particles;

class BaseParticleSystem : public Base3DObject
{
	public:
		//The size should be from 1-10
		BaseParticleSystem(dReal posx, dReal posy, dReal posz, int size, std::string file);
		~BaseParticleSystem();
		int maxParticles;	
		int magnitude;
		//float origin[3];
		particles* particleList;
		void KillSystem();
		bool SystemIsActive();
		GLuint CreateTexture(std::string file);
		void MakeDisplayList();

//	// Context-Specific Data -> handle differently in VRJuggler
//#ifdef USING_VRJUGGLER //using Juggler's special context-specific data types
//		vrj::GlContextData<GLuint> GetDisplayList();
//		void SetDisplayList(vrj::GlContextData<GLuint> newDisplayListID);
//#else //using normal data types
//		GLuint GetDisplayList();
//		void SetDisplayList(GLuint newDisplayListID);
//#endif

		// abstract functions
		virtual void Draw(){};
		virtual void InitializeSystem(){};
		virtual bool Update(dReal deltaTime){return true;};
		float force[3];
		//float slowdown;			// Slow Down Particles
		//float	zoom;			// Used To Zoom Out
		bool usingTexture;
		std::string imageFilename;

	// Context-Specific Data -> handle differently in VRJuggler
#ifdef USING_VRJUGGLER //using Juggler's special context-specific data types
		vrj::GlContextData<GLuint> displayListID; //the display list ID
		vrj::GlContextData<GLuint> textureID; //the texture ID
#else //using normal data types
		GLuint displayListID; //the display list ID
		GLuint textureID; //the texture ID
#endif
};

#endif
