//FireParticleSystem.h
//Fire Particle System class
//Author: Matt Newcomb

#ifndef __FIRE_PARTICLE_SYSTEM_H__
#define __FIRE_PARTICLE_SYSTEM_H__

#include <cstdlib>
#include "BaseParticleSystem.h"

class FireParticleSystem : public BaseParticleSystem
{
	public:
		//The size should be from 1-10
		FireParticleSystem(dReal posx, dReal posy, dReal posz, int size, 
			bool continuous, std::string filename);
		bool Update(dReal deltaTime);
		void Draw();
	protected:
		bool isContinuous;
};
#endif
