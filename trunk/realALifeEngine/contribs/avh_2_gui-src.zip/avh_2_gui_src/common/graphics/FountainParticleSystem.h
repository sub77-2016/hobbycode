//FountainParticleSystem.h
//Fountain Particle System class
//Author: Matt Newcomb

#ifndef __FOUNTAIN_PARTICLE_SYSTEM_H__
#define __FOUNTAIN_PARTICLE_SYSTEM_H__

#include <cstdlib>
#include "BaseParticleSystem.h"

class FountainParticleSystem : public BaseParticleSystem
{
	public:
		//The size should be from 1-10
		FountainParticleSystem(dReal posx, dReal posy, dReal posz, int size, std::string filename);
		bool Update(dReal deltaTime);
		void Draw();
	protected:
};
#endif
