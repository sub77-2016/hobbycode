//LightObject.cpp

#include "LightObject.h"

LightObject::LightObject(int lightNum, dReal posx, dReal posy, dReal posz)
: Base3DObject(false, false, "", "", posx, posy, posz)
{
	lightNumber = lightNum;

	GLfloat ambient[] =  {0.5, 0.5, 0.3, 1.0};
	GLfloat diffuse[] =  {0.9, 0.9, 0.9, 1.0};
	GLfloat specular[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat light_position[] = {position.x, position.y, position.z, 0.0};

	switch(lightNumber)
	{
		case 0:
			glEnable(GL_LIGHT0);
			glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			break;
		case 1:
			glEnable(GL_LIGHT1);
			glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT1, GL_POSITION, light_position);
			break;
		case 2:
			glEnable(GL_LIGHT2);
			glLightfv(GL_LIGHT2, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT2, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT2, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT2, GL_POSITION, light_position);
			break;
		case 3:
			glEnable(GL_LIGHT3);
			glLightfv(GL_LIGHT3, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT3, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT3, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT3, GL_POSITION, light_position);
			break;
		case 4:
			glEnable(GL_LIGHT4);
			glLightfv(GL_LIGHT4, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT4, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT4, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT4, GL_POSITION, light_position);
			break;
		case 5:
			glEnable(GL_LIGHT5);
			glLightfv(GL_LIGHT5, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT5, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT5, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT5, GL_POSITION, light_position);
			break;
		case 6:
			glEnable(GL_LIGHT6);
			glLightfv(GL_LIGHT6, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT6, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT6, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT6, GL_POSITION, light_position);
			break;
		case 7:
			glEnable(GL_LIGHT7);
			glLightfv(GL_LIGHT7, GL_AMBIENT, ambient);
			glLightfv(GL_LIGHT7, GL_DIFFUSE, diffuse);
			glLightfv(GL_LIGHT7, GL_SPECULAR, specular);
			glLightfv(GL_LIGHT7, GL_POSITION, light_position);
			break;
		default:
			break;
	}
}

LightObject::~LightObject()
{
}

void LightObject::SetPosition(point3d newposition)
{
	position = newposition;
	//GLfloat light_position[] = {position.x, position.y, position.z, 0.0};

	//switch(lightNumber)
	//{
	//	case 0:
	//		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	//		break;
	//	case 1:
	//		glLightfv(GL_LIGHT1, GL_POSITION, light_position);
	//		break;
	//	case 2:
	//		glLightfv(GL_LIGHT2, GL_POSITION, light_position);
	//		break;
	//	case 3:
	//		glLightfv(GL_LIGHT3, GL_POSITION, light_position);
	//		break;
	//	case 4:
	//		glLightfv(GL_LIGHT4, GL_POSITION, light_position);
	//		break;
	//	case 5:
	//		glLightfv(GL_LIGHT5, GL_POSITION, light_position);
	//		break;
	//	case 6:
	//		glLightfv(GL_LIGHT6, GL_POSITION, light_position);
	//		break;
	//	case 7:
	//		glLightfv(GL_LIGHT7, GL_POSITION, light_position);
	//		break;
	//	default:
	//		break;
	//}
}

void LightObject::Draw()
{
	glPushMatrix();

	GLfloat light_position[] = {position.x, position.y, position.z, 0.0};

	switch(lightNumber)
	{
		case 0:
			glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			break;
		case 1:
			glLightfv(GL_LIGHT1, GL_POSITION, light_position);
			break;
		case 2:
			glLightfv(GL_LIGHT2, GL_POSITION, light_position);
			break;
		case 3:
			glLightfv(GL_LIGHT3, GL_POSITION, light_position);
			break;
		case 4:
			glLightfv(GL_LIGHT4, GL_POSITION, light_position);
			break;
		case 5:
			glLightfv(GL_LIGHT5, GL_POSITION, light_position);
			break;
		case 6:
			glLightfv(GL_LIGHT6, GL_POSITION, light_position);
			break;
		case 7:
			glLightfv(GL_LIGHT7, GL_POSITION, light_position);
			break;
		default:
			break;
	}

	glPopMatrix();
}

bool LightObject::Update(dReal deltaTime)
{
	//do nothing

	return true;
}
