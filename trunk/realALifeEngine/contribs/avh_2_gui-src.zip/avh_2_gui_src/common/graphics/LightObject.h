//LightObject.h
//OpenGL light class
//Author: Tyler Streeter

#ifndef __LIGHT_OBJECT_H__
#define __LIGHT_OBJECT_H__

#include "../ODE/Base3DObject.h"

class LightObject : public Base3DObject
{
public:
	LightObject(int lightNum, dReal posx, dReal posy, dReal poxz);
	~LightObject();

	void SetPosition(point3d newposition);
	void Draw();
	bool Update(dReal deltaTime);

private:
	int lightNumber;
};

#endif
