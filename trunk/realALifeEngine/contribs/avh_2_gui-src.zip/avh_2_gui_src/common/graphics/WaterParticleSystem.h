//WaterParticleSystem.h
//Splash Particle System class
//Author: Matt Newcomb

#ifndef __WATER_PARTICLE_SYSTEM_H__
#define __WATER_PARTICLE_SYSTEM_H__

#include <cstdlib>
#include "BaseParticleSystem.h"

class WaterParticleSystem : public BaseParticleSystem
{
	public:
		//The size should be from 1-10
		WaterParticleSystem(dReal posx, dReal posy, dReal posz, int size, 
			bool continuous, std::string filename);
		bool Update(dReal deltaTime);
		void Draw();
	protected:
		bool isContinuous;
};
#endif
